<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://https://codepixelzmedia.com/
 * @since      1.0.0
 *
 * @package    Wooescrow
 * @subpackage Wooescrow/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Wooescrow
 * @subpackage Wooescrow/public
 * @author     Code Pixelz X Pwn Bot <dev@codepixelzmedia.com.np>
 */
class Wooescrow_Public
{

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of the plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version)
    {

        $this->plugin_name = $plugin_name;
        $this->version = $version;
        add_shortcode('wallet', array($this, 'wooescrow_walletrender_shortcode'));
        add_shortcode('wooescrow-wallet', array($this, 'render_wooescrow_wallet_pop_shortcode'));
    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_styles()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Wooescrow_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Wooescrow_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/wooescrow-public.css', array(), $this->version, 'all');
        wp_enqueue_style('wooescrow-fontawesome-all', plugin_dir_url(__FILE__) . 'assets/fontawesome/css/all.css', array(), $this->version, 'all');
    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Wooescrow_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Wooescrow_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/wooescrow-public.js', array('jquery'), $this->version, false);

        wp_enqueue_script('wooescrow-build-js', plugin_dir_url(__DIR__) . 'src/files/config.js', array('react', 'react-dom', 'wp-element'), rand(), true);
        // Get current user info
        $current_user = wp_get_current_user();
        $user_email = $current_user->user_email;

        wp_localize_script('wooescrow-build-js', 'WooEscrowCryptoWalletRest', array(
            'nonce' => wp_create_nonce('wp_rest'),
            'user_status_url' => rest_url('wooescrow-wallet/v1/user-status'),
            'update_user_meta_url' => rest_url('wooescrow-wallet/v1/update-user-meta'),
            'get_user_meta_url' => rest_url('wooescrow-wallet/v1/get-user-meta'),
            'generate_totp' => rest_url('wooescrow-wallet/v1/generate_totp_secret'),
            'verify_totp' => rest_url('wooescrow-wallet/v1/verify_totp'),
            'send_sms_otp' => rest_url('twilio/v1/send-otp'),
            'verify_sms_otp' => rest_url('twilio/v1/send-otp'),
            'user_email' => $user_email, // Add the user's email to the localized script
        ));
    }



    /* render shortcode to display component form react modal */

    /**
     * The function render_wooescrow_wallet_pop_shortcode returns a div element with the id
     * "wooescrow-wallet".
     * 
     * @return A div element with the id "wooescrow-wallet" is being returned.
     */

    public function render_wooescrow_wallet_pop_shortcode()
    {
        return '<div id="wooescrow-wallet"></div>';
    }


    public function wooescrow_walletrender_shortcode($atts, $content = null)
    {
        // Shortcode attributes with default values
        $atts = shortcode_atts(
            array(
                'attr1' => 'default1',
                'attr2' => 'default2',
            ),
            $atts,
            'wallet'
        );

        // Shortcode output
        ob_start();

?>
        <div class="wooescrow-section">
            <div class="wooescrow-wrapper">
                <!-- SETUP WOO ESCROW -->
                <div class="wooescrow-setup-section">
                    <div class="wooescrow-setup-wrapper">
                        <div class="wooescrow-container">
                            <div class="wooescrow-header-wrapper">
                                <div class="wooescrow-setup-text">
                                    <p class="wooescrow-text-para wooescrow-blue">Set up Woo Escrow</p>
                                </div>
                                <div class="wooescrow-header">
                                    <h1 class="wooescrow-title">Create new Wallet or import an existent wallet</h1>
                                </div>
                            </div>
                            <div class="wooescrow-setup-content-wrapper">
                                <button type="button" class="wooescrow-button wooescrow-create-new-wallet-button">
                                    <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/Raggruppa-2552.svg"
                                        alt="create wallet" />
                                    <span class="wooescrow-button-text">Create new wallet</span>
                                </button>
                                <button type="button" class="wooescrow-button wooescrow-create-import-wallet-button">
                                    <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/Raggruppa-2497.svg"
                                        alt="import wallet" />
                                    <span class="wooescrow-button-text">Import Wallet</span>
                                </button>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- SELECT WALLET CURRENCY -->
                <div class="wooescrow-wallet-currency-section">
                    <div class="wooescrow-wallet-currency-wrapper">
                        <div class="wooescrow-container">
                            <div class="wooescrow-header-wrapper">
                                <div class="wooescrow-wallet-currency-text">
                                    <p class="wooescrow-text-para wooescrow-blue">
                                        <span class="wooescrow-fa-icon"><i class="fa-solid fa-arrow-left"></i></span>back
                                    </p>
                                </div>
                                <div class="wooescrow-header">
                                    <h1 class="wooescrow-title">Select the wallet’s currency</h1>
                                </div>
                            </div>
                            <div class="wooescrow-wallet-currency-content-wrapper">
                                <div class="wooescrow-wallet-currency-cards wooescrow-wallet-currency-radio-cards">
                                    <!-- BTC -->
                                    <label class="wooescrow-wallet-currency-card wooescrow-wallet-currency-radio-box-group">
                                        <input type="radio" id="wooescrow-wallet-currency-radio-btc"
                                            name="wooescrow-wallet-currency-radio-box"
                                            class="wooescrow-wallet-currency-radio-box">
                                        <div id="wooescrow-wallet-currency-btc" class="wooescrow-wallet-currency-btn">
                                            <div class="wooescrow-wallet-currency-card-img">
                                                <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/b8db742e4fe59d65922ded2062acd9c2.png"
                                                    alt="import wallet" />
                                            </div>
                                            <div class="wooescrow-wallet-currency-card-body">
                                                <h5 class="wooescrow-title wooescrow-uppercase">btc</h5>
                                                <p class="wooescrow-text-para">Bitcoin</p>
                                            </div>
                                        </div>
                                    </label>
                                    <!-- ETH -->
                                    <label class="wooescrow-wallet-currency-card wooescrow-wallet-currency-radio-box-group">
                                        <input type="radio" id="wooescrow-wallet-currency-radio-eth"
                                            name="wooescrow-wallet-currency-radio-box"
                                            class="wooescrow-wallet-currency-radio-box">
                                        <div id="wooescrow-wallet-currency-eth" class="wooescrow-wallet-currency-btn">
                                            <div class="wooescrow-wallet-currency-card-img">
                                                <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/48cb3033c94b91a50b8c0989cc5e6cf3.png"
                                                    alt="import wallet" />
                                            </div>
                                            <div class="wooescrow-wallet-currency-card-body">
                                                <h5 class="wooescrow-title wooescrow-uppercase">eth</h5>
                                                <p class="wooescrow-text-para">Ethereum</p>
                                            </div>
                                        </div>
                                    </label>
                                    <!-- SOL -->
                                    <label class="wooescrow-wallet-currency-card wooescrow-wallet-currency-radio-box-group">
                                        <input type="radio" id="wooescrow-wallet-currency-radio-sol"
                                            name="wooescrow-wallet-currency-radio-box"
                                            class="wooescrow-wallet-currency-radio-box">
                                        <div id="wooescrow-wallet-currency-sol" class="wooescrow-wallet-currency-btn">
                                            <div class="wooescrow-wallet-currency-card-img">
                                                <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/3c96d20d4e8eb83f493f1b4a3b515815.png"
                                                    alt="import wallet" />
                                            </div>
                                            <div class="wooescrow-wallet-currency-card-body">
                                                <h5 class="wooescrow-title wooescrow-uppercase">sol</h5>
                                                <p class="wooescrow-text-para">Solana</p>
                                            </div>
                                        </div>
                                    </label>

                                </div>
                                <div class="wooescrow-wallet-currency-next-btn wooescrow-end">
                                    <button class="wooescrow-button">Next
                                        <span class="wooescrow-fa-icon"><i class="fa-solid fa-arrow-right-long"></i></span>
                                    </button>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- ADD YOUR EXISTING WALLET -->
                <div class="wooescrow-existing-wallet-section">
                    <div class="wooescrow-existing-wallet-wrapper">
                        <div class="wooescrow-container">
                            <div class="wooescrow-header-wrapper">
                                <div class="wooescrow-existing-wallet-text">
                                    <p class="wooescrow-text-para wooescrow-blue">
                                        <span class="wooescrow-fa-icon"><i class="fa-solid fa-arrow-left"></i></span>back
                                    </p>
                                </div>
                                <div class="wooescrow-header">
                                    <h1 class="wooescrow-title">Add your existing wallet</h1>
                                </div>
                                <p class="wooescrow-text-para">Import your wallet on WooEscrow with a recovery private key</p>
                            </div>
                            <div class="wooescrow-existing-wallet-content-wrapper">
                                <form action="" class="wooescrow-form wooescrow-existing-wallet-form">
                                    <div class="wooescrow-form-group wooescrow-existing-wallet-form-group">
                                        <label for="wooescrow-existing-wallet-private-key" class="wooescrow-label">
                                            <span class="wooescrow-label-text">Enter private key</span>
                                        </label>
                                        <input type="text" id="wooescrow-existing-wallet-private-key" class="wooescrow-input"
                                            name="">
                                    </div>
                                    <div
                                        class="wooescrow-form-group wooescrow-existing-wallet-form-group wooescrow-existing-wallet-button-group">
                                        <button id="wooescrow-existing-wallet-paste-key"
                                            class="wooescrow-button wooescrow-gray">Paste Key</button>
                                        <button id="wooescrow-existing-wallet-import" class="wooescrow-button">Import</button>
                                    </div>
                                </form>

                            </div>
                        </div>

                    </div>
                </div>

                <!-- CREATE A PASSWORD -->
                <div class="wooescrow-password-section">
                    <div class="wooescrow-password-wrapper">
                        <div class="wooescrow-container">
                            <div class="wooescrow-header-wrapper">
                                <div class="wooescrow-password-text">
                                    <p class="wooescrow-text-para wooescrow-blue">
                                        <span class="wooescrow-fa-icon"><i class="fa-solid fa-arrow-left"></i></span>back
                                    </p>
                                </div>
                                <div class="wooescrow-header">
                                    <h1 class="wooescrow-title">Create a Password</h1>
                                </div>
                            </div>
                            <div class="wooescrow-password-content-wrapper">
                                <form action="" class="wooescrow-form wooescrow-password-form">
                                    <div class="wooescrow-form-group wooescrow-password-form-group">
                                        <label for="wooescrow-new-password" class="wooescrow-label">
                                            <span class="wooescrow-label-text">New Password</span>
                                        </label>
                                        <input type="text" id="wooescrow-new-password" class="wooescrow-input" name="">
                                        <span id="wooescrow-togglePassword" class="wooescrow-eye">
                                            <img class="wooescrow-eye-img"
                                                src="/wp-content/plugins/wooescrow/wooescrow-public/img/eye.svg" alt="eye" />
                                            <img class="wooescrow-eye-crossed-img"
                                                src="/wp-content/plugins/wooescrow/wooescrow-public/img/eye-crossed.svg"
                                                alt="eye-crossed" />
                                        </span>
                                    </div>
                                    <div class="wooescrow-form-group wooescrow-password-form-group">
                                        <label for="wooescrow-confirm-password" class="wooescrow-label">
                                            <span class="wooescrow-label-text">Confirm Password</span>
                                        </label>
                                        <input type="text" id="wooescrow-confirm-password" class="wooescrow-input" name="">
                                        <span id="wooescrow-toggleConfirmPassword" class="wooescrow-eye">
                                            <img class="wooescrow-eye-img"
                                                src="/wp-content/plugins/wooescrow/wooescrow-public/img/eye.svg" alt="eye" />
                                            <img class="wooescrow-eye-crossed-img"
                                                src="/wp-content/plugins/wooescrow/wooescrow-public/img/eye-crossed.svg"
                                                alt="eye-crossed" />
                                        </span>
                                    </div>
                                    <div
                                        class="wooescrow-form-group wooescrow-password-form-group wooescrow-password-button-group wooescrow-end">
                                        <button id="wooescrow-password-continue" class="wooescrow-button">Continue
                                            <span class="wooescrow-fa-icon"><i class="fa-solid fa-arrow-right-long"></i></span>
                                        </button>
                                    </div>
                                </form>

                                <div class="wooescrow-term-conditions-text">
                                    <p class="wooescrow-text-para">By clicking on “continue” you agree the <a href="#"
                                            class="wooescrow-link">term and condition</a> of WooEscrow.</p>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <!-- SECURITY LEVEL -->
                <div class="wooescrow-security-level-section">
                    <div class="wooescrow-security-level-wrapper">
                        <div class="wooescrow-container">
                            <div class="wooescrow-header-wrapper">
                                <div class="wooescrow-security-level-text">
                                    <p class="wooescrow-text-para wooescrow-blue">
                                        <span class="wooescrow-fa-icon"><i class="fa-solid fa-arrow-left"></i></span>back
                                    </p>
                                </div>
                                <div class="wooescrow-header">
                                    <h1 class="wooescrow-title">Security level</h1>
                                </div>
                            </div>
                            <div class="wooescrow-security-level-content-wrapper">
                                <div class="wooescrow-security-level-radio-group">
                                    <label class="wooescrow-security-level-card wooescrow-security-level-radio-box-group">
                                        <input type="radio" id="wooescrow-no-security" name="wooescrow-security-level-radio-btn"
                                            class="wooescrow-security-level-radio-btn" checked>
                                        <div id="wooescrow-no-security-radio-box" class="wooescrow-security-level-radio-box">
                                            <div class="wooescrow-security-level-img-container">
                                                <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/shield-slash.svg"
                                                    alt="no-security">
                                            </div>
                                            <div class="wooescrow-security-level-card-body">
                                                <span class="wooescrow-card-text">No Security</span>
                                            </div>
                                        </div>
                                    </label>
                                    <label class="wooescrow-security-level-card wooescrow-security-level-radio-box-group">
                                        <input type="radio" id="wooescrow-sms-code" name="wooescrow-security-level-radio-btn"
                                            class="wooescrow-security-level-radio-btn">
                                        <div id="wooescrow-sms-code-radio-box" class="wooescrow-security-level-radio-box">
                                            <div class="wooescrow-security-level-img-container">
                                                <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/password-smartphone.svg"
                                                    alt="SMS Code">
                                            </div>
                                            <div class="wooescrow-security-level-card-body">
                                                <span class="wooescrow-card-text">SMS Code</span>
                                            </div>
                                        </div>
                                    </label>
                                    <label class="wooescrow-security-level-card wooescrow-security-level-radio-box-group">
                                        <input type="radio" id="wooescrow-google-auth" name="wooescrow-security-level-radio-btn"
                                            class="wooescrow-security-level-radio-btn">
                                        <div id="wooescrow-google-auth-radio-box" class="wooescrow-security-level-radio-box">
                                            <div class="wooescrow-security-level-img-container">
                                                <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/Google_Authenticator_(April_2023).svg"
                                                    alt="Google Auth">
                                            </div>
                                            <div class="wooescrow-security-level-card-body">
                                                <span class="wooescrow-card-text">Google Auth</span>
                                            </div>
                                        </div>
                                    </label>
                                    <label class="wooescrow-security-level-card wooescrow-security-level-radio-box-group">
                                        <input type="radio" id="wooescrow-multi-sig" name="wooescrow-security-level-radio-btn"
                                            class="wooescrow-security-level-radio-btn">
                                        <div id="wooescrow-multi-sig-radio-box" class="wooescrow-security-level-radio-box">
                                            <div class="wooescrow-security-level-img-container">
                                                <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/key-skeleton-left-right.svg"
                                                    alt="Multisig">
                                            </div>
                                            <div class="wooescrow-security-level-card-body">
                                                <span class="wooescrow-card-text">Multisig</span>
                                            </div>
                                        </div>
                                    </label>
                                </div>
                                <div class="wooescrow-security-confirm-btn wooescrow-end">
                                    <button id="wooescrow-secuity-confirm-button" class="wooescrow-button">Confirm
                                        <span class="wooescrow-fa-icon"><i class="fa-solid fa-arrow-right-long"></i></span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <!-- OVERVIEW -->
                <div id="wooescrow-overview-tab-content" class="wooescrow-tab-content">
                    <div class="wooescrow-tab-main-content wooescrow-tab-container">
                        <div class="wooescrow-tab-content-header">
                            <p class="wooescrow-text-para wooescrow-uppercase">MARKET PRICE</p>
                            <div class="wooescrow-radio-group">
                                <!-- hour -->
                                <input type="radio" name="date" value="hour" id="wooescrow-hour">
                                <label for="wooescrow-hour" class="wooescrow-radio-label">1h</label>
                                <!-- day -->
                                <input type="radio" name="date" value="day" id="wooescrow-day" checked>
                                <label for="wooescrow-day" class="wooescrow-radio-label">1d</label>
                                <!-- month -->
                                <input type="radio" name="date" value="month" id="wooescrow-month">
                                <label for="wooescrow-month" class="wooescrow-radio-label">1m</label>
                                <!-- year -->
                                <input type="radio" name="date" value="year" id="wooescrow-year">
                                <label for="wooescrow-year" class="wooescrow-radio-label">1y</label>
                                <!-- all -->
                                <input type="radio" name="date" value="all" id="wooescrow-all">
                                <label for="wooescrow-all" class="wooescrow-radio-label">all</label>
                            </div>
                        </div>
                        <div class="wooescrow-tab-content-body">
                            <div class="wooescrow-table-wrapper">
                                <table id="wooescrow-overview-table-full" class="wooescrow-table">
                                    <thead>
                                        <tr>
                                            <th>Bitcoin</th>
                                            <th>Last price</th>
                                            <th>Change</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="wooescrow-td-title-currency">
                                                <div class="wooescrow-td-currency-wrap">
                                                    <span class="wooescrow-td-image">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                            alt="eth" />
                                                    </span>
                                                    <div class="wooescrow-td-content">
                                                        <h5 class="wooescrow-td-name wooescrow-uppercase">eth
                                                        </h5>
                                                        <p class="wooescrow-td-currency">Ethereum</p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="wooescrow-td-last-price">€60,726.69</td>
                                            <td class="wooescrow-td-change wooescrow-up">+5.58%
                                            </td>
                                            <td class="wooescrow-td-action">
                                                <button id="wooescrow-secuity-buy-button" class="wooescrow-button">buy
                                                </button>
                                                <button id="wooescrow-secuity-swap-button" class="wooescrow-button">swap
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="wooescrow-td-title-currency">
                                                <div class="wooescrow-td-currency-wrap">
                                                    <span class="wooescrow-td-image">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                            alt="eth" />
                                                    </span>
                                                    <div class="wooescrow-td-content">
                                                        <h5 class="wooescrow-td-name wooescrow-uppercase">eth
                                                        </h5>
                                                        <p class="wooescrow-td-currency">Ethereum</p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="wooescrow-td-last-price">€60,726.69</td>
                                            <td class="wooescrow-td-change wooescrow-up">+5.58%
                                            </td>
                                            <td class="wooescrow-td-action">
                                                <button id="wooescrow-secuity-buy-button" class="wooescrow-button">buy
                                                </button>
                                                <button id="wooescrow-secuity-swap-button" class="wooescrow-button">swap
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="wooescrow-td-title-currency">
                                                <div class="wooescrow-td-currency-wrap">
                                                    <span class="wooescrow-td-image">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                            alt="eth" />
                                                    </span>
                                                    <div class="wooescrow-td-content">
                                                        <h5 class="wooescrow-td-name wooescrow-uppercase">eth
                                                        </h5>
                                                        <p class="wooescrow-td-currency">Ethereum</p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="wooescrow-td-last-price">€60,726.69</td>
                                            <td class="wooescrow-td-change wooescrow-down">-5.58%
                                            </td>
                                            <td class="wooescrow-td-action">
                                                <button id="wooescrow-secuity-buy-button" class="wooescrow-button">buy
                                                </button>
                                                <button id="wooescrow-secuity-swap-button" class="wooescrow-button">swap
                                                </button>
                                            </td>
                                        </tr>


                                    </tbody>
                                </table>
                                <div class="wooescrow-view-all wooescrow-center">
                                    <a class="wooescrow-link" href="#">View all</a>
                                </div>


                            </div>
                        </div>
                    </div>
                    <div class="wooescrow-tab-side-content">
                        <div class="wooescrow-total-balance wooescrow-tab-container">
                            <div class="wooescrow-total-balance-wrap">
                                <div class="wooescrow-total-balance-left">
                                    <h5 class="wooescrow-title wooescrow-uppercase">Total Balance</h5>
                                    <span class="wooescrow-total-price">€ 10.496,50</span>
                                </div>
                                <div class="wooescrow-total-balance-right">
                                    <div class="wooescrow-custom-select-container">
                                        <div class="wooescrow-custom-select-wrapper">
                                            <div class="wooescrow-custom-select">
                                                <div class="wooescrow-custom-select-trigger">
                                                    <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                        alt="eth" />ETH
                                                    <span class="wooescrow-icon">
                                                        <i class="fa-solid fa-chevron-down"></i>
                                                    </span>
                                                </div>
                                                <div class="wooescrow-custom-options">
                                                    <div class="wooescrow-custom-option selected" data-value="1"
                                                        data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                            alt="eth">eth
                                                    </div>
                                                    <div class="wooescrow-custom-option" data-value="2"
                                                        data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png"
                                                            alt="btc">btc
                                                    </div>
                                                    <div class="wooescrow-custom-option" data-value="3"
                                                        data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/sol-small.png">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/sol-small.png"
                                                            alt="sol">sol
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Hidden select element to store the value -->
                                            <select id="wooescrow-original-select">
                                                <option value="1"
                                                    data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png">
                                                    eth</option>
                                                <option value="2"
                                                    data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png">
                                                    btc</option>
                                                <option value="3"
                                                    data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/sol-small.png">
                                                    sol</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="wooescrow-wallet-address wooescrow-center">
                                        <div class="wooescrow-copy-container wooescrow-justify-center">
                                            <input type="text" value="0x6a7B88a3..." id="wooescrow-copyText" readonly="">
                                            <button id="wooescrow-copyButton">
                                                <span class="wooescrow-copy-icon">
                                                    <i class="fa-regular fa-copy"></i>
                                                </span>
                                            </button>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="wooescrow-currency-transactions">
                            <ul class="wooescrow-currency-transactions-list">
                                <li class="wooescrow-currency-transactions-list-item active">Buy</li>
                                <li class="wooescrow-currency-transactions-list-item">Sell</li>
                                <li class="wooescrow-currency-transactions-list-item">Exchange</li>
                            </ul>
                            <div id="wooescrow-buy" class="wooescrow-currency-transactions-list-content">
                                <div class="wooescrow-buy-content-wrap">
                                    <div class="wooescrow-buying-amount">
                                        <div class="wooescrow-currency-wrap">
                                            <span class="wooescrow-image">
                                                <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                    alt="eth" />
                                            </span>
                                            <div class="wooescrow-content">
                                                <h5 class="wooescrow-title wooescrow-uppercase">eth
                                                </h5>
                                                <p class="wooescrow-text-para wooescrow-currency">Ethereum</p>
                                            </div>
                                        </div>
                                        <div class="wooescrow-buying-amount-wrap">
                                            <span class="wooescrow-price">€ 3361,40</span>
                                        </div>
                                    </div>
                                    <div class="wooescrow-buying-amount-converted-wrap">
                                        <div class="wooescrow-buying-amount-converted wooescrow-blue wooescrow-center">
                                            0
                                            <span>$</span>
                                        </div>

                                    </div>
                                    <div class="wooescrow-converting-options">
                                        <ul class="wooescrow-coverting-list">
                                            <li class="wooescrow-converting-list-item">50 €</li>
                                            <li class="wooescrow-converting-list-item">100 €</li>
                                            <li class="wooescrow-converting-list-item">200 €</li>
                                            <li class="wooescrow-converting-list-item">500 €</li>
                                        </ul>
                                    </div>

                                </div>
                                <div class="wooescrow-buying-payment-option">
                                    <div class="wooescrow-buying-payment-option-wrap wooescrow-center">
                                        <div class="wooescrow-buying-payment-option-content">
                                            <svg id="Mastercard-logo" xmlns="http://www.w3.org/2000/svg" width="31.629"
                                                height="19.563" viewBox="0 0 31.629 19.563">
                                                <g id="Raggruppa_38" data-name="Raggruppa 38">
                                                    <rect id="rect19" width="8.559" height="15.378"
                                                        transform="translate(11.522 2.092)" fill="#ff5a00" />
                                                    <path id="XMLID_330_"
                                                        d="M12.092,9.781a9.809,9.809,0,0,1,3.723-7.689,9.778,9.778,0,1,0-6.033,17.47,9.729,9.729,0,0,0,6.033-2.092A9.762,9.762,0,0,1,12.092,9.781Z"
                                                        fill="#eb001b" />
                                                    <path id="path22"
                                                        d="M515.415,9.781A9.772,9.772,0,0,1,499.6,17.47a9.8,9.8,0,0,0,0-15.378,9.772,9.772,0,0,1,15.815,7.689Z"
                                                        transform="translate(-483.785)" fill="#f79e1b" />
                                                </g>
                                            </svg>
                                            <h5 class="wooescrow-title wooescrow-buying-payment-option-title">Mastercard</h5>
                                            <p class="wooescrow-text-para">****9876</p>
                                            <span class="wooescrow-icon">
                                                <i class="fa-solid fa-chevron-right"></i>
                                            </span>
                                        </div>
                                        <button class="wooescrow-button" id="wooescrow-buy-button">
                                            <svg width="20" height="20" viewBox="0 0 50 50" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M24.4141 4.36523C24.0039 4.54101 8.02735 13.8184 7.83203 14.0039C7.30469 14.4824 7.32422 13.9844 7.32422 24.4629C7.32422 34.9414 7.30469 34.4434 7.83203 34.9316C7.94922 35.0488 11.7285 37.2656 16.2109 39.8535C24.1602 44.4434 24.3848 44.5605 24.9609 44.6094C25.4004 44.6387 25.6445 44.6094 25.8887 44.4824C26.6602 44.082 41.6797 35.4004 41.9727 35.1758C42.1582 35.0488 42.3828 34.8047 42.4902 34.6289C42.666 34.3359 42.6758 34.0039 42.6758 24.5312C42.6758 13.9746 42.6953 14.4824 42.168 14.0039C42.0508 13.8867 38.2715 11.6699 33.7891 9.08203C26.0449 4.5996 25.6055 4.36523 25.0977 4.33593C24.8047 4.3164 24.4922 4.32617 24.4141 4.36523ZM32.2754 11.8555L39.502 15.9961L39.5312 24.4434L39.5508 32.8906L32.2852 37.0508L25.0098 41.2012L17.7344 37.0508L10.4492 32.8906V24.4629V16.0254L17.7051 11.875C21.6895 9.5996 24.9707 7.7246 25 7.7246C25.0293 7.7246 28.3008 9.58007 32.2754 11.8555Z"
                                                    fill="#fff" />
                                                <path
                                                    d="M24.3555 14.7363C24.1309 14.834 23.8477 15.0683 23.7207 15.2441L23.4863 15.5762L23.457 19.2578L23.4277 22.9492H19.8926C16.5332 22.9492 16.3379 22.959 16.0352 23.1445C15.0879 23.7305 15.0879 25.1953 16.0352 25.7812C16.3379 25.9668 16.5332 25.9765 19.8926 25.9765H23.4277L23.457 29.668L23.4863 33.3691L23.75 33.7109C24.4531 34.6289 25.8496 34.5117 26.3672 33.5058C26.5527 33.1348 26.5625 32.9394 26.5625 29.541V25.9668L30.1758 25.9765C34.2188 25.9961 34.1699 26.0058 34.6484 25.2832C34.9512 24.8535 34.9219 24.0234 34.5898 23.5644C34.1602 22.959 34.082 22.9492 30.1367 22.9492H26.5723L26.543 19.2578L26.5137 15.5762L26.2793 15.2441C26.0254 14.8926 25.4004 14.5508 25 14.5508C24.8633 14.5508 24.5801 14.6387 24.3555 14.7363Z"
                                                    fill="#fff" />
                                            </svg>
                                            <span class="wooescrow-button-text">Buy Ethereum</span>

                                        </button>
                                    </div>
                                </div>

                            </div>
                            <div id="wooescrow-sell" class="wooescrow-currency-transactions-list-content">

                            </div>
                            <div id="wooescrow-exchnage" class="wooescrow-currency-transactions-list-content">

                            </div>
                        </div>
                    </div>
                </div>

                <!-- EXCHNAGE -->
                <div id="wooescrow-exchange-tab-content" class="wooescrow-tab-content">
                    <div class="wooescrow-exchange-tab-content-wrap">
                        <div class="wooescrow-exchnage-amount-wrap">
                            <div class="wooescrow-exchange-amount wooescrow-amount-send">
                                <span class="wooescrow-send">Send</span>
                                <div class="wooescrow-amount-send-wrap">
                                    <div class="wooescrow-custom-select-container">
                                        <div class="wooescrow-custom-select-wrapper">
                                            <div class="wooescrow-custom-select">
                                                <div class="wooescrow-custom-select-trigger">
                                                    <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                        alt="eth" />ETH
                                                    <span class="wooescrow-icon">
                                                        <i class="fa-solid fa-chevron-down"></i>
                                                    </span>
                                                </div>
                                                <div class="wooescrow-custom-options">
                                                    <div class="wooescrow-custom-option selected" data-value="1"
                                                        data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                            alt="eth">eth
                                                    </div>
                                                    <div class="wooescrow-custom-option" data-value="2"
                                                        data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png"
                                                            alt="btc">btc
                                                    </div>
                                                    <div class="wooescrow-custom-option" data-value="3"
                                                        data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/sol-small.png">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/sol-small.png"
                                                            alt="sol">sol
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Hidden select element to store the value -->
                                            <select id="wooescrow-original-select">
                                                <option value="1"
                                                    data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png">
                                                    eth</option>
                                                <option value="2"
                                                    data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png">
                                                    btc</option>
                                                <option value="3"
                                                    data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/sol-small.png">
                                                    sol</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="wooescrow-amount-send-total">
                                        <span class="wooescrow-blue">150,000</span>
                                        <button id="wooescrow-all-amount" class="wooescrow-button">All amount</button>
                                    </div>
                                </div>
                            </div>
                            <div class="wooescrow-exchange-amount wooescrow-amount-receive">
                                <span class="wooescrow-receive">Receive</span>
                                <div class="wooescrow-amount-receive-wrap">
                                    <div class="wooescrow-custom-select-container">
                                        <div class="wooescrow-custom-select-wrapper">
                                            <div class="wooescrow-custom-select">
                                                <div class="wooescrow-custom-select-trigger">
                                                    <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                        alt="eth" />ETH
                                                    <span class="wooescrow-icon">
                                                        <i class="fa-solid fa-chevron-down"></i>
                                                    </span>
                                                </div>
                                                <div class="wooescrow-custom-options">
                                                    <div class="wooescrow-custom-option selected" data-value="1"
                                                        data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                            alt="eth">eth
                                                    </div>
                                                    <div class="wooescrow-custom-option" data-value="2"
                                                        data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png"
                                                            alt="btc">btc
                                                    </div>
                                                    <div class="wooescrow-custom-option" data-value="3"
                                                        data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/sol-small.png">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/sol-small.png"
                                                            alt="sol">sol
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Hidden select element to store the value -->
                                            <select id="wooescrow-original-select">
                                                <option value="1"
                                                    data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png">
                                                    eth</option>
                                                <option value="2"
                                                    data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png">
                                                    btc</option>
                                                <option value="3"
                                                    data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/sol-small.png">
                                                    sol</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="wooescrow-amount-receive-total">
                                        <span>ETH 52,456</span>
                                        <!-- <button class="wooescrow-button">All amount</button> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="wooescrow-rates-swap-wrap">
                            <table class="wooescrow-rates-table">
                                <tr class="wooescrow-available-amount">
                                    <th>Available Amount:</th>
                                    <td>ETH 52,456</td>
                                </tr>
                                <tr class="wooescrow-rate">
                                    <th>Rate:</th>
                                    <td>1 USDT = 0,045 ETH</td>
                                </tr>
                                <tr class="wooescrow-fee">
                                    <th>Fee:</th>
                                    <td>13,12 USD</td>
                                </tr>
                            </table>
                            <div class="wooescrow-currency-swap">
                                <button class="wooescrow-button" id="wooescrow-swap-button">
                                    <svg id="refresh" xmlns="http://www.w3.org/2000/svg" width="21.12" height="21.201"
                                        viewBox="0 0 21.12 21.201">
                                        <path id="Tracciato_22" data-name="Tracciato 22"
                                            d="M10.606,1.767A8.862,8.862,0,0,1,16.9,4.417H14.139a.883.883,0,0,0-.883.883h0a.883.883,0,0,0,.883.883H17.8a1.641,1.641,0,0,0,1.64-1.64V.883A.883.883,0,0,0,18.556,0h0a.883.883,0,0,0-.883.883V2.719A10.584,10.584,0,0,0,.049,9.628a.89.89,0,0,0,.883.972h0a.867.867,0,0,0,.874-.776,8.846,8.846,0,0,1,8.8-8.058Z"
                                            transform="translate(-0.046 0.001)" fill="#fff" />
                                        <path id="Tracciato_23" data-name="Tracciato 23"
                                            d="M20.507,12a.867.867,0,0,0-.874.776A8.821,8.821,0,0,1,4.542,18.183H7.3a.883.883,0,0,0,.883-.883h0a.883.883,0,0,0-.883-.883H3.64A1.64,1.64,0,0,0,2,18.057v3.66a.883.883,0,0,0,.883.883h0a.883.883,0,0,0,.883-.883V19.881a10.584,10.584,0,0,0,17.623-6.91A.89.89,0,0,0,20.506,12Z"
                                            transform="translate(-0.274 -1.399)" fill="#fff" />
                                    </svg>
                                    <span class="wooescrow-button-text">SWAP NOW</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- MY ASSETS -->
                <div id="wooescrow-my-assets-tab-content" class="wooescrow-tab-content">
                    <div class="wooescrow-my-assets-top-content">
                        <div class="wooescrow-tab-side-content">
                            <div class="wooescrow-total-balance wooescrow-tab-container">
                                <div class="wooescrow-total-balance-wrap">
                                    <div class="wooescrow-total-balance-left">
                                        <h5 class="wooescrow-title wooescrow-uppercase">Total Balance</h5>
                                        <span class="wooescrow-total-price">€ 10.496,50</span>
                                    </div>
                                    <div class="wooescrow-total-balance-right">
                                        <div class="wooescrow-custom-select-container">
                                            <div class="wooescrow-custom-select-wrapper">
                                                <div class="wooescrow-custom-select">
                                                    <div class="wooescrow-custom-select-trigger">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                            alt="eth" />ETH
                                                        <span class="wooescrow-icon">
                                                            <i class="fa-solid fa-chevron-down"></i>
                                                        </span>
                                                    </div>
                                                    <div class="wooescrow-custom-options">
                                                        <div class="wooescrow-custom-option selected" data-value="1"
                                                            data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png">
                                                            <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                                alt="eth">eth
                                                        </div>
                                                        <div class="wooescrow-custom-option" data-value="2"
                                                            data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png">
                                                            <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png"
                                                                alt="btc">btc
                                                        </div>
                                                        <div class="wooescrow-custom-option" data-value="3"
                                                            data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/sol-small.png">
                                                            <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/sol-small.png"
                                                                alt="sol">sol
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Hidden select element to store the value -->
                                                <select id="wooescrow-original-select">
                                                    <option value="1"
                                                        data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png">
                                                        eth</option>
                                                    <option value="2"
                                                        data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png">
                                                        btc</option>
                                                    <option value="3"
                                                        data-image="/wp-content/plugins/wooescrow/wooescrow-public/img/sol-small.png">
                                                        sol</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="wooescrow-wallet-address wooescrow-center">
                                            <div class="wooescrow-copy-container wooescrow-justify-center">
                                                <input type="text" value="0x6a7B88a3..." id="wooescrow-copyText" readonly="">
                                                <button id="wooescrow-copyButton">
                                                    <span class="wooescrow-copy-icon">
                                                        <i class="fa-regular fa-copy"></i>
                                                    </span>
                                                </button>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="wooescrow-total-balance-button-wrap">
                                    <button id="wooescrow-deposit-button" class="wooescrow-button">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="21.691" height="21.69"
                                            viewBox="0 0 21.691 21.69">
                                            <path id="bank"
                                                d="M21.689,20.785a.9.9,0,0,1-.9.9H.9a.9.9,0,1,1,0-1.807H20.785A.9.9,0,0,1,21.689,20.785ZM.263,7.728A2.208,2.208,0,0,1,.4,5.409,4.262,4.262,0,0,1,1.908,4.054L8.687.526A4.676,4.676,0,0,1,13,.526l6.778,3.531a4.262,4.262,0,0,1,1.507,1.356,2.208,2.208,0,0,1,.138,2.319,2.452,2.452,0,0,1-2.183,1.306h-.264v7.23h.9a.9.9,0,1,1,0,1.807H1.807a.9.9,0,1,1,0-1.807h.9V9.037H2.447A2.452,2.452,0,0,1,.263,7.728Zm4.256,8.538H7.229V9.037H4.518Zm4.519-7.23v7.23h3.615V9.037Zm8.133,0H14.459v7.23H17.17ZM1.864,6.891a.648.648,0,0,0,.583.339H19.241a.648.648,0,0,0,.583-.339.408.408,0,0,0-.022-.452,2.44,2.44,0,0,0-.858-.781L12.167,2.127a2.87,2.87,0,0,0-2.644,0L2.745,5.658a2.451,2.451,0,0,0-.858.782.408.408,0,0,0-.023.451Z"
                                                transform="translate(0.002 0.002)" fill="#fff" />
                                        </svg>
                                        <span class="wooescrow-button-text">Deposit</span>
                                    </button>
                                    <button id="wooescrow-withdraw-button" class="wooescrow-button">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="19.699" height="19.708"
                                            viewBox="0 0 19.699 19.708">
                                            <path id="money-from-bracket"
                                                d="M13.133,9.858A3.283,3.283,0,1,0,9.85,13.141,3.282,3.282,0,0,0,13.133,9.858ZM9.85,11.5a1.642,1.642,0,1,1,1.642-1.642A1.646,1.646,0,0,1,9.85,11.5ZM16.416,0H3.283A3.289,3.289,0,0,0,0,3.291v.821A3.288,3.288,0,0,0,3.283,7.4V15.6a4.106,4.106,0,0,0,4.1,4.1h4.925a4.106,4.106,0,0,0,4.1-4.1V7.4A3.282,3.282,0,0,0,19.7,4.112V3.291A3.289,3.289,0,0,0,16.416,0Zm1.642,4.1a1.646,1.646,0,0,1-1.642,1.642V4.1a.821.821,0,0,0-1.642,0V15.6a2.47,2.47,0,0,1-2.462,2.462H7.387A2.47,2.47,0,0,1,4.925,15.6V4.112a.821.821,0,0,0-1.642,0V5.754A1.646,1.646,0,0,1,1.642,4.112V3.291A1.646,1.646,0,0,1,3.283,1.65H16.416a1.646,1.646,0,0,1,1.642,1.642v.821Zm-4.1,11.9a1.231,1.231,0,1,1-1.231-1.231A1.23,1.23,0,0,1,13.954,16.006Zm-5.746,0a1.231,1.231,0,1,1-1.231-1.231A1.23,1.23,0,0,1,8.208,16.006Z"
                                                fill="#fff" />
                                        </svg>
                                        <span class="wooescrow-button-text">Withdraw</span>
                                    </button>
                                </div>
                            </div>

                        </div>
                        <div class="wooescrow-tab-main-content wooescrow-tab-container">
                            <div class="wooescrow-tab-content-header">
                                <p class="wooescrow-text-para wooescrow-uppercase">WALLETS</p>
                                <div class="wooescrow-radio-group">
                                    <!-- hour -->
                                    <input type="radio" name="date" value="hour" id="wooescrow-hour">
                                    <label for="wooescrow-hour" class="wooescrow-radio-label">1h</label>
                                    <!-- day -->
                                    <input type="radio" name="date" value="day" id="wooescrow-day" checked>
                                    <label for="wooescrow-day" class="wooescrow-radio-label">1d</label>
                                    <!-- month -->
                                    <input type="radio" name="date" value="month" id="wooescrow-month">
                                    <label for="wooescrow-month" class="wooescrow-radio-label">1m</label>
                                    <!-- year -->
                                    <input type="radio" name="date" value="year" id="wooescrow-year">
                                    <label for="wooescrow-year" class="wooescrow-radio-label">1y</label>
                                    <!-- all -->
                                    <input type="radio" name="date" value="all" id="wooescrow-all">
                                    <label for="wooescrow-all" class="wooescrow-radio-label">all</label>
                                </div>
                            </div>
                            <div class="wooescrow-tab-content-body">
                                <div class="wooescrow-table-wrapper">
                                    <table id="wooescrow-my-assets-table-full" class="wooescrow-table">
                                        <thead>
                                            <tr>
                                                <th>Bitcoin</th>
                                                <th>Total Balance</th>
                                                <th>Change</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="wooescrow-td-title-currency">
                                                    <div class="wooescrow-td-currency-wrap">
                                                        <span class="wooescrow-td-image">
                                                            <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                                alt="eth" />
                                                        </span>
                                                        <div class="wooescrow-td-content">
                                                            <h5 class="wooescrow-td-name wooescrow-uppercase">eth
                                                            </h5>
                                                            <p class="wooescrow-td-currency">Ethereum</p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="wooescrow-td-total-balance">€60,726.69
                                                    <span class="wooescrow-currency">0,254 BTC</span>
                                                </td>
                                                <td class="wooescrow-td-change">
                                                    <div class="wooescrow-td-change-wrap">
                                                        <span class="wooescrow-up">+5.58%</span>
                                                        <span class="wooescrow-td-graph">-</span>
                                                        <span class="wooescrow-td-change-info">
                                                            <div class="wooescrow-icon wooescrow-dot-trigger">
                                                                <svg id="Raggruppa_2480" data-name="Raggruppa 2480"
                                                                    xmlns="http://www.w3.org/2000/svg" width="4" height="20"
                                                                    viewBox="0 0 4 20">
                                                                    <circle id="Ellisse_4" data-name="Ellisse 4" cx="2" cy="2"
                                                                        r="2" fill="#5b616e" />
                                                                    <circle id="Ellisse_5" data-name="Ellisse 5" cx="2" cy="2"
                                                                        r="2" transform="translate(0 8)" fill="#5b616e" />
                                                                    <circle id="Ellisse_6" data-name="Ellisse 6" cx="2" cy="2"
                                                                        r="2" transform="translate(0 16)" fill="#5b616e" />
                                                                </svg>
                                                            </div>
                                                            <ul class="wooescrow-change-transaction-lists">
                                                                <li class="wooescrow-change-transaction-list-item">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="20.045"
                                                                        height="18.324" viewBox="0 0 20.045 18.324">
                                                                        <path id="plus-hexagon"
                                                                            d="M19.433,8.064l-2.915-5A4.18,4.18,0,0,0,12.921,1H7.032a4.179,4.179,0,0,0-3.6,2.067l-2.916,5a4.176,4.176,0,0,0,0,4.2l2.916,5a4.178,4.178,0,0,0,3.6,2.066H12.92a4.18,4.18,0,0,0,3.6-2.066l2.915-5a4.176,4.176,0,0,0,0-4.2Zm-1.44,3.358-2.915,5a2.508,2.508,0,0,1-2.159,1.239H7.032A2.507,2.507,0,0,1,4.873,16.42l-2.915-5a2.5,2.5,0,0,1,0-2.519l2.915-5a2.507,2.507,0,0,1,2.158-1.24H12.92a2.506,2.506,0,0,1,2.158,1.24l2.915,5A2.5,2.5,0,0,1,17.993,11.422Zm-3.841-1.259a.833.833,0,0,1-.833.833h-2.5v2.5a.833.833,0,1,1-1.666,0V11h-2.5a.833.833,0,1,1,0-1.666h2.5v-2.5a.833.833,0,1,1,1.666,0v2.5h2.5A.833.833,0,0,1,14.152,10.163Z"
                                                                            transform="translate(0.047 -1)" fill="#0047fa" />
                                                                    </svg> <span>Buy</span>
                                                                </li>
                                                                <li class="wooescrow-change-transaction-list-item">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="17.619"
                                                                        height="17.619" viewBox="0 0 17.619 17.619">
                                                                        <path id="coin-up-arrow"
                                                                            d="M12.113,0C8.975,0,6.607,1.263,6.607,2.937V6.043A6.61,6.61,0,0,1,10.54,8.682a10.485,10.485,0,0,0,1.573.128,8.361,8.361,0,0,0,4.038-.9v.9c0,.584-1.61,1.468-4.038,1.468-.266,0-.518-.015-.764-.035a6.54,6.54,0,0,1,.35,1.481c.139.005.271.022.413.022a8.361,8.361,0,0,0,4.038-.9v.9c0,.584-1.61,1.468-4.038,1.468-.142,0-.271-.012-.407-.018a6.547,6.547,0,0,1-.33,1.448c.244.016.482.039.737.039a8.361,8.361,0,0,0,4.038-.9v.72c0,.673-1.573,1.652-4.038,1.652a8.263,8.263,0,0,1-1.407-.123,6.615,6.615,0,0,1-1.065,1.278,9.478,9.478,0,0,0,2.471.313c3.138,0,5.506-1.341,5.506-3.12V2.937C17.619,1.263,15.251,0,12.113,0Zm0,1.468c2.428,0,4.038.884,4.038,1.468S14.541,4.4,12.113,4.4,8.076,3.521,8.076,2.937,9.686,1.468,12.113,1.468Zm0,5.873c-2.428,0-4.038-.884-4.038-1.468v-.9a8.385,8.385,0,0,0,4.038.9,8.385,8.385,0,0,0,4.038-.9v.9C16.151,6.458,14.541,7.341,12.113,7.341ZM7.658,12.48H5.873v2.2H4.4v-2.2H2.6l1.973-1.973a.784.784,0,0,1,1.109,0ZM5.139,7.341a5.139,5.139,0,1,0,5.139,5.139A5.145,5.145,0,0,0,5.139,7.341Zm0,8.81A3.671,3.671,0,1,1,8.81,12.48,3.675,3.675,0,0,1,5.139,16.151Z"
                                                                            fill="#0047fa" />
                                                                    </svg>
                                                                    <span>Sell</span>
                                                                </li>
                                                                <li class="wooescrow-change-transaction-list-item">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="17.619"
                                                                        height="17.687" viewBox="0 0 17.619 17.687">
                                                                        <path id="Unione_1" data-name="Unione 1"
                                                                            d="M2.914,15.418V16.95a.737.737,0,0,1-1.474,0V13.9a1.367,1.367,0,0,1,1.369-1.368H5.861a.737.737,0,1,1,0,1.473h-2.3A7.359,7.359,0,0,0,16.15,9.491a.724.724,0,0,1,.729-.647h0a.742.742,0,0,1,.737.811,8.829,8.829,0,0,1-14.7,5.764ZM.74,8.843A.742.742,0,0,1,0,8.033,8.829,8.829,0,0,1,14.7,2.269V.737a.737.737,0,0,1,1.473,0V3.791A1.369,1.369,0,0,1,14.81,5.159H11.757a.737.737,0,0,1,0-1.474h2.3A7.359,7.359,0,0,0,1.469,8.2a.724.724,0,0,1-.72.647Z"
                                                                            transform="translate(0)" fill="#0047fa" />
                                                                    </svg> <span>Exchange</span>
                                                                </li>
                                                                <li class="wooescrow-change-transaction-list-item">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="17.619"
                                                                        height="17.62" viewBox="0 0 17.619 17.62">
                                                                        <path id="paper-plane"
                                                                            d="M16.975.648A2.178,2.178,0,0,0,14.919.06L3.172,2.535A3.667,3.667,0,0,0,1.077,8.761l1.261,1.261a.734.734,0,0,1,.215.52v2.326a2.177,2.177,0,0,0,.22.943l-.006.005.019.019a2.2,2.2,0,0,0,1,1l.019.019.005-.006a2.177,2.177,0,0,0,.943.22H7.081a.734.734,0,0,1,.519.214L8.86,16.54a3.644,3.644,0,0,0,2.584,1.081,3.707,3.707,0,0,0,1.178-.194A3.622,3.622,0,0,0,15.078,14.5L17.556,2.728a2.184,2.184,0,0,0-.581-2.08ZM3.378,8.985,2.116,7.725a2.159,2.159,0,0,1-.53-2.257A2.186,2.186,0,0,1,3.421,3.98L15.052,1.532,4.02,12.565V10.542A2.186,2.186,0,0,0,3.378,8.985ZM13.636,14.25A2.2,2.2,0,0,1,9.9,15.507L8.636,14.244A2.186,2.186,0,0,0,7.081,13.6H5.058L16.091,2.57Z"
                                                                            transform="translate(-0.003 -0.001)"
                                                                            fill="#0047fa" />
                                                                    </svg> <span>Send</span>
                                                                </li>
                                                                <li class="wooescrow-change-transaction-list-item">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="19"
                                                                        height="19" viewBox="0 0 19 19">
                                                                        <path id="insert"
                                                                            d="M4.988,10.461A.792.792,0,0,1,6.1,9.33l2.613,2.56V.792a.792.792,0,1,1,1.583,0v11.09L12.9,9.331a.792.792,0,0,1,1.108,1.131l-3.4,3.331a1.568,1.568,0,0,1-1.111.458h0a1.58,1.58,0,0,1-1.118-.464L4.987,10.462Zm13.221,2.206H17.021a1.982,1.982,0,0,0-1.979,1.979v.792a1.982,1.982,0,0,1-1.979,1.979H5.938a1.982,1.982,0,0,1-1.979-1.979v-.792a1.982,1.982,0,0,0-1.979-1.979H.792a.792.792,0,1,0,0,1.583H1.979a.4.4,0,0,1,.4.4v.792A3.567,3.567,0,0,0,5.938,19h7.125a3.567,3.567,0,0,0,3.563-3.562v-.792a.4.4,0,0,1,.4-.4h1.188a.792.792,0,0,0,0-1.583Z"
                                                                            fill="#0047fa" />
                                                                    </svg>
                                                                    <span>Receive</span>
                                                                </li>
                                                            </ul>
                                                        </span>
                                                    </div>

                                                </td>

                                            </tr>
                                            <tr>
                                                <td class="wooescrow-td-title-currency">
                                                    <div class="wooescrow-td-currency-wrap">
                                                        <span class="wooescrow-td-image">
                                                            <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                                alt="eth" />
                                                        </span>
                                                        <div class="wooescrow-td-content">
                                                            <h5 class="wooescrow-td-name wooescrow-uppercase">eth
                                                            </h5>
                                                            <p class="wooescrow-td-currency">Ethereum</p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="wooescrow-td-total-balance">€60,726.69
                                                    <span class="wooescrow-currency">0,254 BTC</span>
                                                </td>
                                                <td class="wooescrow-td-change">
                                                    <div class="wooescrow-td-change-wrap">
                                                        <span class="wooescrow-up">+5.58%</span>
                                                        <span class="wooescrow-td-graph">-</span>
                                                        <span class="wooescrow-td-change-info">
                                                            <div class="wooescrow-icon wooescrow-dot-trigger">
                                                                <svg id="Raggruppa_2480" data-name="Raggruppa 2480"
                                                                    xmlns="http://www.w3.org/2000/svg" width="4" height="20"
                                                                    viewBox="0 0 4 20">
                                                                    <circle id="Ellisse_4" data-name="Ellisse 4" cx="2" cy="2"
                                                                        r="2" fill="#5b616e" />
                                                                    <circle id="Ellisse_5" data-name="Ellisse 5" cx="2" cy="2"
                                                                        r="2" transform="translate(0 8)" fill="#5b616e" />
                                                                    <circle id="Ellisse_6" data-name="Ellisse 6" cx="2" cy="2"
                                                                        r="2" transform="translate(0 16)" fill="#5b616e" />
                                                                </svg>
                                                            </div>
                                                            <ul class="wooescrow-change-transaction-lists">
                                                                <li class="wooescrow-change-transaction-list-item">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="20.045"
                                                                        height="18.324" viewBox="0 0 20.045 18.324">
                                                                        <path id="plus-hexagon"
                                                                            d="M19.433,8.064l-2.915-5A4.18,4.18,0,0,0,12.921,1H7.032a4.179,4.179,0,0,0-3.6,2.067l-2.916,5a4.176,4.176,0,0,0,0,4.2l2.916,5a4.178,4.178,0,0,0,3.6,2.066H12.92a4.18,4.18,0,0,0,3.6-2.066l2.915-5a4.176,4.176,0,0,0,0-4.2Zm-1.44,3.358-2.915,5a2.508,2.508,0,0,1-2.159,1.239H7.032A2.507,2.507,0,0,1,4.873,16.42l-2.915-5a2.5,2.5,0,0,1,0-2.519l2.915-5a2.507,2.507,0,0,1,2.158-1.24H12.92a2.506,2.506,0,0,1,2.158,1.24l2.915,5A2.5,2.5,0,0,1,17.993,11.422Zm-3.841-1.259a.833.833,0,0,1-.833.833h-2.5v2.5a.833.833,0,1,1-1.666,0V11h-2.5a.833.833,0,1,1,0-1.666h2.5v-2.5a.833.833,0,1,1,1.666,0v2.5h2.5A.833.833,0,0,1,14.152,10.163Z"
                                                                            transform="translate(0.047 -1)" fill="#0047fa" />
                                                                    </svg> <span>Buy</span>
                                                                </li>
                                                                <li class="wooescrow-change-transaction-list-item">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="17.619"
                                                                        height="17.619" viewBox="0 0 17.619 17.619">
                                                                        <path id="coin-up-arrow"
                                                                            d="M12.113,0C8.975,0,6.607,1.263,6.607,2.937V6.043A6.61,6.61,0,0,1,10.54,8.682a10.485,10.485,0,0,0,1.573.128,8.361,8.361,0,0,0,4.038-.9v.9c0,.584-1.61,1.468-4.038,1.468-.266,0-.518-.015-.764-.035a6.54,6.54,0,0,1,.35,1.481c.139.005.271.022.413.022a8.361,8.361,0,0,0,4.038-.9v.9c0,.584-1.61,1.468-4.038,1.468-.142,0-.271-.012-.407-.018a6.547,6.547,0,0,1-.33,1.448c.244.016.482.039.737.039a8.361,8.361,0,0,0,4.038-.9v.72c0,.673-1.573,1.652-4.038,1.652a8.263,8.263,0,0,1-1.407-.123,6.615,6.615,0,0,1-1.065,1.278,9.478,9.478,0,0,0,2.471.313c3.138,0,5.506-1.341,5.506-3.12V2.937C17.619,1.263,15.251,0,12.113,0Zm0,1.468c2.428,0,4.038.884,4.038,1.468S14.541,4.4,12.113,4.4,8.076,3.521,8.076,2.937,9.686,1.468,12.113,1.468Zm0,5.873c-2.428,0-4.038-.884-4.038-1.468v-.9a8.385,8.385,0,0,0,4.038.9,8.385,8.385,0,0,0,4.038-.9v.9C16.151,6.458,14.541,7.341,12.113,7.341ZM7.658,12.48H5.873v2.2H4.4v-2.2H2.6l1.973-1.973a.784.784,0,0,1,1.109,0ZM5.139,7.341a5.139,5.139,0,1,0,5.139,5.139A5.145,5.145,0,0,0,5.139,7.341Zm0,8.81A3.671,3.671,0,1,1,8.81,12.48,3.675,3.675,0,0,1,5.139,16.151Z"
                                                                            fill="#0047fa" />
                                                                    </svg>
                                                                    <span>Sell</span>
                                                                </li>
                                                                <li class="wooescrow-change-transaction-list-item">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="17.619"
                                                                        height="17.687" viewBox="0 0 17.619 17.687">
                                                                        <path id="Unione_1" data-name="Unione 1"
                                                                            d="M2.914,15.418V16.95a.737.737,0,0,1-1.474,0V13.9a1.367,1.367,0,0,1,1.369-1.368H5.861a.737.737,0,1,1,0,1.473h-2.3A7.359,7.359,0,0,0,16.15,9.491a.724.724,0,0,1,.729-.647h0a.742.742,0,0,1,.737.811,8.829,8.829,0,0,1-14.7,5.764ZM.74,8.843A.742.742,0,0,1,0,8.033,8.829,8.829,0,0,1,14.7,2.269V.737a.737.737,0,0,1,1.473,0V3.791A1.369,1.369,0,0,1,14.81,5.159H11.757a.737.737,0,0,1,0-1.474h2.3A7.359,7.359,0,0,0,1.469,8.2a.724.724,0,0,1-.72.647Z"
                                                                            transform="translate(0)" fill="#0047fa" />
                                                                    </svg> <span>Exchange</span>
                                                                </li>
                                                                <li class="wooescrow-change-transaction-list-item">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="17.619"
                                                                        height="17.62" viewBox="0 0 17.619 17.62">
                                                                        <path id="paper-plane"
                                                                            d="M16.975.648A2.178,2.178,0,0,0,14.919.06L3.172,2.535A3.667,3.667,0,0,0,1.077,8.761l1.261,1.261a.734.734,0,0,1,.215.52v2.326a2.177,2.177,0,0,0,.22.943l-.006.005.019.019a2.2,2.2,0,0,0,1,1l.019.019.005-.006a2.177,2.177,0,0,0,.943.22H7.081a.734.734,0,0,1,.519.214L8.86,16.54a3.644,3.644,0,0,0,2.584,1.081,3.707,3.707,0,0,0,1.178-.194A3.622,3.622,0,0,0,15.078,14.5L17.556,2.728a2.184,2.184,0,0,0-.581-2.08ZM3.378,8.985,2.116,7.725a2.159,2.159,0,0,1-.53-2.257A2.186,2.186,0,0,1,3.421,3.98L15.052,1.532,4.02,12.565V10.542A2.186,2.186,0,0,0,3.378,8.985ZM13.636,14.25A2.2,2.2,0,0,1,9.9,15.507L8.636,14.244A2.186,2.186,0,0,0,7.081,13.6H5.058L16.091,2.57Z"
                                                                            transform="translate(-0.003 -0.001)"
                                                                            fill="#0047fa" />
                                                                    </svg> <span>Send</span>
                                                                </li>
                                                                <li class="wooescrow-change-transaction-list-item">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="19"
                                                                        height="19" viewBox="0 0 19 19">
                                                                        <path id="insert"
                                                                            d="M4.988,10.461A.792.792,0,0,1,6.1,9.33l2.613,2.56V.792a.792.792,0,1,1,1.583,0v11.09L12.9,9.331a.792.792,0,0,1,1.108,1.131l-3.4,3.331a1.568,1.568,0,0,1-1.111.458h0a1.58,1.58,0,0,1-1.118-.464L4.987,10.462Zm13.221,2.206H17.021a1.982,1.982,0,0,0-1.979,1.979v.792a1.982,1.982,0,0,1-1.979,1.979H5.938a1.982,1.982,0,0,1-1.979-1.979v-.792a1.982,1.982,0,0,0-1.979-1.979H.792a.792.792,0,1,0,0,1.583H1.979a.4.4,0,0,1,.4.4v.792A3.567,3.567,0,0,0,5.938,19h7.125a3.567,3.567,0,0,0,3.563-3.562v-.792a.4.4,0,0,1,.4-.4h1.188a.792.792,0,0,0,0-1.583Z"
                                                                            fill="#0047fa" />
                                                                    </svg>
                                                                    <span>Receive</span>
                                                                </li>
                                                            </ul>
                                                        </span>
                                                    </div>

                                                </td>

                                            </tr>
                                            <tr>
                                                <td class="wooescrow-td-title-currency">
                                                    <div class="wooescrow-td-currency-wrap">
                                                        <span class="wooescrow-td-image">
                                                            <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                                alt="eth" />
                                                        </span>
                                                        <div class="wooescrow-td-content">
                                                            <h5 class="wooescrow-td-name wooescrow-uppercase">eth
                                                            </h5>
                                                            <p class="wooescrow-td-currency">Ethereum</p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="wooescrow-td-total-balance">€60,726.69
                                                    <span class="wooescrow-currency">0,254 BTC</span>
                                                </td>
                                                <td class="wooescrow-td-change">
                                                    <div class="wooescrow-td-change-wrap">
                                                        <span class="wooescrow-up">+5.58%</span>
                                                        <span class="wooescrow-td-graph">-</span>
                                                        <span class="wooescrow-td-change-info">
                                                            <div class="wooescrow-icon wooescrow-dot-trigger">
                                                                <svg id="Raggruppa_2480" data-name="Raggruppa 2480"
                                                                    xmlns="http://www.w3.org/2000/svg" width="4" height="20"
                                                                    viewBox="0 0 4 20">
                                                                    <circle id="Ellisse_4" data-name="Ellisse 4" cx="2" cy="2"
                                                                        r="2" fill="#5b616e" />
                                                                    <circle id="Ellisse_5" data-name="Ellisse 5" cx="2" cy="2"
                                                                        r="2" transform="translate(0 8)" fill="#5b616e" />
                                                                    <circle id="Ellisse_6" data-name="Ellisse 6" cx="2" cy="2"
                                                                        r="2" transform="translate(0 16)" fill="#5b616e" />
                                                                </svg>
                                                            </div>
                                                            <ul class="wooescrow-change-transaction-lists">
                                                                <li class="wooescrow-change-transaction-list-item">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="20.045"
                                                                        height="18.324" viewBox="0 0 20.045 18.324">
                                                                        <path id="plus-hexagon"
                                                                            d="M19.433,8.064l-2.915-5A4.18,4.18,0,0,0,12.921,1H7.032a4.179,4.179,0,0,0-3.6,2.067l-2.916,5a4.176,4.176,0,0,0,0,4.2l2.916,5a4.178,4.178,0,0,0,3.6,2.066H12.92a4.18,4.18,0,0,0,3.6-2.066l2.915-5a4.176,4.176,0,0,0,0-4.2Zm-1.44,3.358-2.915,5a2.508,2.508,0,0,1-2.159,1.239H7.032A2.507,2.507,0,0,1,4.873,16.42l-2.915-5a2.5,2.5,0,0,1,0-2.519l2.915-5a2.507,2.507,0,0,1,2.158-1.24H12.92a2.506,2.506,0,0,1,2.158,1.24l2.915,5A2.5,2.5,0,0,1,17.993,11.422Zm-3.841-1.259a.833.833,0,0,1-.833.833h-2.5v2.5a.833.833,0,1,1-1.666,0V11h-2.5a.833.833,0,1,1,0-1.666h2.5v-2.5a.833.833,0,1,1,1.666,0v2.5h2.5A.833.833,0,0,1,14.152,10.163Z"
                                                                            transform="translate(0.047 -1)" fill="#0047fa" />
                                                                    </svg> <span>Buy</span>
                                                                </li>
                                                                <li class="wooescrow-change-transaction-list-item">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="17.619"
                                                                        height="17.619" viewBox="0 0 17.619 17.619">
                                                                        <path id="coin-up-arrow"
                                                                            d="M12.113,0C8.975,0,6.607,1.263,6.607,2.937V6.043A6.61,6.61,0,0,1,10.54,8.682a10.485,10.485,0,0,0,1.573.128,8.361,8.361,0,0,0,4.038-.9v.9c0,.584-1.61,1.468-4.038,1.468-.266,0-.518-.015-.764-.035a6.54,6.54,0,0,1,.35,1.481c.139.005.271.022.413.022a8.361,8.361,0,0,0,4.038-.9v.9c0,.584-1.61,1.468-4.038,1.468-.142,0-.271-.012-.407-.018a6.547,6.547,0,0,1-.33,1.448c.244.016.482.039.737.039a8.361,8.361,0,0,0,4.038-.9v.72c0,.673-1.573,1.652-4.038,1.652a8.263,8.263,0,0,1-1.407-.123,6.615,6.615,0,0,1-1.065,1.278,9.478,9.478,0,0,0,2.471.313c3.138,0,5.506-1.341,5.506-3.12V2.937C17.619,1.263,15.251,0,12.113,0Zm0,1.468c2.428,0,4.038.884,4.038,1.468S14.541,4.4,12.113,4.4,8.076,3.521,8.076,2.937,9.686,1.468,12.113,1.468Zm0,5.873c-2.428,0-4.038-.884-4.038-1.468v-.9a8.385,8.385,0,0,0,4.038.9,8.385,8.385,0,0,0,4.038-.9v.9C16.151,6.458,14.541,7.341,12.113,7.341ZM7.658,12.48H5.873v2.2H4.4v-2.2H2.6l1.973-1.973a.784.784,0,0,1,1.109,0ZM5.139,7.341a5.139,5.139,0,1,0,5.139,5.139A5.145,5.145,0,0,0,5.139,7.341Zm0,8.81A3.671,3.671,0,1,1,8.81,12.48,3.675,3.675,0,0,1,5.139,16.151Z"
                                                                            fill="#0047fa" />
                                                                    </svg>
                                                                    <span>Sell</span>
                                                                </li>
                                                                <li class="wooescrow-change-transaction-list-item">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="17.619"
                                                                        height="17.687" viewBox="0 0 17.619 17.687">
                                                                        <path id="Unione_1" data-name="Unione 1"
                                                                            d="M2.914,15.418V16.95a.737.737,0,0,1-1.474,0V13.9a1.367,1.367,0,0,1,1.369-1.368H5.861a.737.737,0,1,1,0,1.473h-2.3A7.359,7.359,0,0,0,16.15,9.491a.724.724,0,0,1,.729-.647h0a.742.742,0,0,1,.737.811,8.829,8.829,0,0,1-14.7,5.764ZM.74,8.843A.742.742,0,0,1,0,8.033,8.829,8.829,0,0,1,14.7,2.269V.737a.737.737,0,0,1,1.473,0V3.791A1.369,1.369,0,0,1,14.81,5.159H11.757a.737.737,0,0,1,0-1.474h2.3A7.359,7.359,0,0,0,1.469,8.2a.724.724,0,0,1-.72.647Z"
                                                                            transform="translate(0)" fill="#0047fa" />
                                                                    </svg> <span>Exchange</span>
                                                                </li>
                                                                <li class="wooescrow-change-transaction-list-item">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="17.619"
                                                                        height="17.62" viewBox="0 0 17.619 17.62">
                                                                        <path id="paper-plane"
                                                                            d="M16.975.648A2.178,2.178,0,0,0,14.919.06L3.172,2.535A3.667,3.667,0,0,0,1.077,8.761l1.261,1.261a.734.734,0,0,1,.215.52v2.326a2.177,2.177,0,0,0,.22.943l-.006.005.019.019a2.2,2.2,0,0,0,1,1l.019.019.005-.006a2.177,2.177,0,0,0,.943.22H7.081a.734.734,0,0,1,.519.214L8.86,16.54a3.644,3.644,0,0,0,2.584,1.081,3.707,3.707,0,0,0,1.178-.194A3.622,3.622,0,0,0,15.078,14.5L17.556,2.728a2.184,2.184,0,0,0-.581-2.08ZM3.378,8.985,2.116,7.725a2.159,2.159,0,0,1-.53-2.257A2.186,2.186,0,0,1,3.421,3.98L15.052,1.532,4.02,12.565V10.542A2.186,2.186,0,0,0,3.378,8.985ZM13.636,14.25A2.2,2.2,0,0,1,9.9,15.507L8.636,14.244A2.186,2.186,0,0,0,7.081,13.6H5.058L16.091,2.57Z"
                                                                            transform="translate(-0.003 -0.001)"
                                                                            fill="#0047fa" />
                                                                    </svg> <span>Send</span>
                                                                </li>
                                                                <li class="wooescrow-change-transaction-list-item">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="19"
                                                                        height="19" viewBox="0 0 19 19">
                                                                        <path id="insert"
                                                                            d="M4.988,10.461A.792.792,0,0,1,6.1,9.33l2.613,2.56V.792a.792.792,0,1,1,1.583,0v11.09L12.9,9.331a.792.792,0,0,1,1.108,1.131l-3.4,3.331a1.568,1.568,0,0,1-1.111.458h0a1.58,1.58,0,0,1-1.118-.464L4.987,10.462Zm13.221,2.206H17.021a1.982,1.982,0,0,0-1.979,1.979v.792a1.982,1.982,0,0,1-1.979,1.979H5.938a1.982,1.982,0,0,1-1.979-1.979v-.792a1.982,1.982,0,0,0-1.979-1.979H.792a.792.792,0,1,0,0,1.583H1.979a.4.4,0,0,1,.4.4v.792A3.567,3.567,0,0,0,5.938,19h7.125a3.567,3.567,0,0,0,3.563-3.562v-.792a.4.4,0,0,1,.4-.4h1.188a.792.792,0,0,0,0-1.583Z"
                                                                            fill="#0047fa" />
                                                                    </svg>
                                                                    <span>Receive</span>
                                                                </li>
                                                            </ul>
                                                        </span>
                                                    </div>

                                                </td>

                                            </tr>



                                        </tbody>
                                    </table>
                                    <div class="wooescrow-view-all wooescrow-center">
                                        <a class="wooescrow-link" href="#">View all</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="wooescrow-my-assets-bottom-content">
                        <div class="wooescrow-my-assets-bottom-wrapper">
                            <div class="wooescrow-tab-content-header">
                                <p class="wooescrow-text-para wooescrow-uppercase">LATEST ACTIVITIES</p>
                            </div>
                            <div class="wooescrow-table-wrapper">
                                <table id="wooescrow-latest-activities-table-full" class="wooescrow-table">
                                    <thead>
                                        <tr>
                                            <th>#NUM</th>
                                            <th>Date</th>
                                            <th>Action</th>
                                            <th>Currency</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="wooescrow-td-num wooescrow-blue">#YK89</td>
                                            <td class="wooescrow-td-date">Apr 2 2024</td>
                                            <td class="wooescrow-td-action">
                                                <div class="wooescrow-td-action-wrap">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="21.691" height="21.69"
                                                        viewBox="0 0 21.691 21.69">
                                                        <path id="bank"
                                                            d="M21.689,20.785a.9.9,0,0,1-.9.9H.9a.9.9,0,1,1,0-1.807H20.785A.9.9,0,0,1,21.689,20.785ZM.263,7.728A2.208,2.208,0,0,1,.4,5.409,4.262,4.262,0,0,1,1.908,4.054L8.687.526A4.676,4.676,0,0,1,13,.526l6.778,3.531a4.262,4.262,0,0,1,1.507,1.356,2.208,2.208,0,0,1,.138,2.319,2.452,2.452,0,0,1-2.183,1.306h-.264v7.23h.9a.9.9,0,1,1,0,1.807H1.807a.9.9,0,1,1,0-1.807h.9V9.037H2.447A2.452,2.452,0,0,1,.263,7.728Zm4.256,8.538H7.229V9.037H4.518Zm4.519-7.23v7.23h3.615V9.037Zm8.133,0H14.459v7.23H17.17ZM1.864,6.891a.648.648,0,0,0,.583.339H19.241a.648.648,0,0,0,.583-.339.408.408,0,0,0-.022-.452,2.44,2.44,0,0,0-.858-.781L12.167,2.127a2.87,2.87,0,0,0-2.644,0L2.745,5.658a2.451,2.451,0,0,0-.858.782.408.408,0,0,0-.023.451Z"
                                                            transform="translate(0.002 0.002)" fill="#2f323b" />
                                                    </svg> <span>Deposit</span>
                                                </div>
                                            </td>
                                            <td class="wooescrow-td-title-currency">
                                                <div class="wooescrow-td-currency-wrap">
                                                    <span class="wooescrow-td-image">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                            alt="eth" />
                                                    </span>
                                                    <div class="wooescrow-td-content">
                                                        <h5 class="wooescrow-td-name wooescrow-uppercase">eth
                                                        </h5>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="wooescrow-td-amount">0,000325 ETH</td>
                                            <td class="wooescrow-td-status">
                                                <span class="wooescrow-up wooescrow-up-bg">Completed</span>
                                            </td>

                                        </tr>
                                        <tr>
                                            <td class="wooescrow-td-num wooescrow-blue">#YK89</td>
                                            <td class="wooescrow-td-date">Apr 2 2024</td>
                                            <td class="wooescrow-td-action">
                                                <div class="wooescrow-td-action-wrap">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="20.045" height="18.324"
                                                        viewBox="0 0 20.045 18.324">
                                                        <path id="plus-hexagon"
                                                            d="M19.433,8.064l-2.915-5A4.18,4.18,0,0,0,12.921,1H7.032a4.179,4.179,0,0,0-3.6,2.067l-2.916,5a4.176,4.176,0,0,0,0,4.2l2.916,5a4.178,4.178,0,0,0,3.6,2.066H12.92a4.18,4.18,0,0,0,3.6-2.066l2.915-5a4.176,4.176,0,0,0,0-4.2Zm-1.44,3.358-2.915,5a2.508,2.508,0,0,1-2.159,1.239H7.032A2.507,2.507,0,0,1,4.873,16.42l-2.915-5a2.5,2.5,0,0,1,0-2.519l2.915-5a2.507,2.507,0,0,1,2.158-1.24H12.92a2.506,2.506,0,0,1,2.158,1.24l2.915,5A2.5,2.5,0,0,1,17.993,11.422Zm-3.841-1.259a.833.833,0,0,1-.833.833h-2.5v2.5a.833.833,0,1,1-1.666,0V11h-2.5a.833.833,0,1,1,0-1.666h2.5v-2.5a.833.833,0,1,1,1.666,0v2.5h2.5A.833.833,0,0,1,14.152,10.163Z"
                                                            transform="translate(0.047 -1)" fill="#2F323B" />
                                                    </svg> <span>Buy</span>
                                                </div>
                                            </td>
                                            <td class="wooescrow-td-title-currency">
                                                <div class="wooescrow-td-currency-wrap">
                                                    <span class="wooescrow-td-image">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                            alt="eth" />
                                                    </span>
                                                    <div class="wooescrow-td-content">
                                                        <h5 class="wooescrow-td-name wooescrow-uppercase">eth
                                                        </h5>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="wooescrow-td-amount">0,000325 ETH</td>
                                            <td class="wooescrow-td-status">
                                                <span class="wooescrow-down wooescrow-down-bg">Rejected</span>
                                            </td>

                                        </tr>
                                        <tr>
                                            <td class="wooescrow-td-num wooescrow-blue">#YK89</td>
                                            <td class="wooescrow-td-date">Apr 2 2024</td>
                                            <td class="wooescrow-td-action">
                                                <div class="wooescrow-td-action-wrap">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="19.699" height="19.708"
                                                        viewBox="0 0 19.699 19.708">
                                                        <path id="money-from-bracket"
                                                            d="M13.133,9.858A3.283,3.283,0,1,0,9.85,13.141,3.282,3.282,0,0,0,13.133,9.858ZM9.85,11.5a1.642,1.642,0,1,1,1.642-1.642A1.646,1.646,0,0,1,9.85,11.5ZM16.416,0H3.283A3.289,3.289,0,0,0,0,3.291v.821A3.288,3.288,0,0,0,3.283,7.4V15.6a4.106,4.106,0,0,0,4.1,4.1h4.925a4.106,4.106,0,0,0,4.1-4.1V7.4A3.282,3.282,0,0,0,19.7,4.112V3.291A3.289,3.289,0,0,0,16.416,0Zm1.642,4.1a1.646,1.646,0,0,1-1.642,1.642V4.1a.821.821,0,0,0-1.642,0V15.6a2.47,2.47,0,0,1-2.462,2.462H7.387A2.47,2.47,0,0,1,4.925,15.6V4.112a.821.821,0,0,0-1.642,0V5.754A1.646,1.646,0,0,1,1.642,4.112V3.291A1.646,1.646,0,0,1,3.283,1.65H16.416a1.646,1.646,0,0,1,1.642,1.642v.821Zm-4.1,11.9a1.231,1.231,0,1,1-1.231-1.231A1.23,1.23,0,0,1,13.954,16.006Zm-5.746,0a1.231,1.231,0,1,1-1.231-1.231A1.23,1.23,0,0,1,8.208,16.006Z"
                                                            fill="#2F323B" />
                                                    </svg> <span>Withdraw</span>
                                                </div>
                                            </td>
                                            <td class="wooescrow-td-title-currency">
                                                <div class="wooescrow-td-currency-wrap wooescrow-td-multi-currency-wrap">
                                                    <span class="wooescrow-td-image">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png"
                                                            alt="btc" />
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                            alt="eth" />

                                                    </span>
                                                    <div class="wooescrow-td-content">
                                                        <h5 class="wooescrow-td-name wooescrow-uppercase">eth
                                                        </h5>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="wooescrow-td-amount">0,76 BTC - 0,000325 ETH</td>
                                            <td class="wooescrow-td-status">
                                                <span class="wooescrow-up wooescrow-up-bg">Completed</span>
                                            </td>
                                            </td>

                                        </tr>
                                        <tr>
                                            <td class="wooescrow-td-num wooescrow-blue">#YK89</td>
                                            <td class="wooescrow-td-date">Apr 2 2024</td>
                                            <td class="wooescrow-td-action">
                                                <div class="wooescrow-td-action-wrap">
                                                    <svg id="refresh" xmlns="http://www.w3.org/2000/svg" width="21.12"
                                                        height="21.201" viewBox="0 0 21.12 21.201">
                                                        <path id="Tracciato_22" data-name="Tracciato 22"
                                                            d="M10.606,1.767A8.862,8.862,0,0,1,16.9,4.417H14.139a.883.883,0,0,0-.883.883h0a.883.883,0,0,0,.883.883H17.8a1.641,1.641,0,0,0,1.64-1.64V.883A.883.883,0,0,0,18.556,0h0a.883.883,0,0,0-.883.883V2.719A10.584,10.584,0,0,0,.049,9.628a.89.89,0,0,0,.883.972h0a.867.867,0,0,0,.874-.776,8.846,8.846,0,0,1,8.8-8.058Z"
                                                            transform="translate(-0.046 0.001)" fill="#2f323b" />
                                                        <path id="Tracciato_23" data-name="Tracciato 23"
                                                            d="M20.507,12a.867.867,0,0,0-.874.776A8.821,8.821,0,0,1,4.542,18.183H7.3a.883.883,0,0,0,.883-.883h0a.883.883,0,0,0-.883-.883H3.64A1.64,1.64,0,0,0,2,18.057v3.66a.883.883,0,0,0,.883.883h0a.883.883,0,0,0,.883-.883V19.881a10.584,10.584,0,0,0,17.623-6.91A.89.89,0,0,0,20.506,12Z"
                                                            transform="translate(-0.274 -1.399)" fill="#2f323b" />
                                                    </svg> <span>Exchnage</span>
                                                </div>
                                            </td>
                                            <td class="wooescrow-td-title-currency">
                                                <div class="wooescrow-td-currency-wrap wooescrow-td-multi-currency-wrap">
                                                    <span class="wooescrow-td-image">
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png"
                                                            alt="btc" />
                                                        <img src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                                                            alt="eth" />

                                                    </span>
                                                    <div class="wooescrow-td-content">
                                                        <h5 class="wooescrow-td-name wooescrow-uppercase">eth
                                                        </h5>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="wooescrow-td-amount">0,76 BTC - 0,000325 ETH</td>
                                            <td class="wooescrow-td-status">
                                                <span class="wooescrow-pending wooescrow-pending-bg">Pending</span>
                                            </td>
                                            </td>

                                        </tr>



                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>



<?php
        return ob_get_clean();
    }
}
