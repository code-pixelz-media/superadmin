(function ($) {
  "use strict";

  /**
   * All of the code for your public-facing JavaScript source
   * should reside in this file.
   *
   * Note: It has been assumed you will write jQuery code here, so the
   * $ function reference has been prepared for usage within the scope
   * of this function.
   *
   * This enables you to define handlers, for when the DOM is ready:
   *
   * $(function() {
   *
   * });
   *
   * When the window is loaded:
   *
   * $( window ).load(function() {
   *
   * });
   *
   * ...and/or other possibilities.
   *
   * Ideally, it is not considered best practise to attach more than a
   * single DOM-ready or window-load handler for a particular page.
   * Although scripts in the WordPress core, Plugins and Themes may be
   * practising this, we should strive to set a better example in our own work.
   */

  // ---------------------------
  // SHOW PASSWORD
  // ---------------------------
  $(document).ready(function () {
    // Function to toggle password visibility
    function togglePasswordVisibility(toggleElement, passwordField) {
      var passwordFieldType = passwordField.attr("type");

      if (passwordFieldType === "password") {
        passwordField.attr("type", "text");
        toggleElement.find(".wooescrow-eye-crossed-img").hide();
        toggleElement.find(".wooescrow-eye-img").show();
      } else {
        passwordField.attr("type", "password");
        toggleElement.find(".wooescrow-eye-img").hide();
        toggleElement.find(".wooescrow-eye-crossed-img").show();
      }
    }

    // Event listener for New Password field
    $("#wooescrow-togglePassword").click(function () {
      togglePasswordVisibility($(this), $("#wooescrow-new-password"));
    });

    // Event listener for Confirm Password field
    $("#wooescrow-toggleConfirmPassword").click(function () {
      togglePasswordVisibility($(this), $("#wooescrow-confirm-password"));
    });
    // SELECT DROPDOWN
    var $selectWrapper = $(".wooescrow-custom-select");
    var $trigger = $selectWrapper.find(".wooescrow-custom-select-trigger");
    var $options = $selectWrapper.find(".wooescrow-custom-option");
    var $hiddenSelect = $("#wooescrow-original-select");

    // Toggle the dropdown
    $trigger.on("click", function () {
      // Close all other dropdowns
      $(".wooescrow-custom-select")
        .not($(this).closest(".wooescrow-custom-select"))
        .removeClass("open");

      // Toggle the current dropdown
      $(this).closest(".wooescrow-custom-select").toggleClass("open");
    });

    // Handle option selection
    $options.on("click", function () {
      var $currentWrapper = $(this).closest(".wooescrow-custom-select");

      // Remove 'selected' class from previously selected option
      $currentWrapper.find(".wooescrow-custom-option").removeClass("selected");

      // Add 'selected' class to clicked option
      $(this).addClass("selected");

      // Update the trigger content to show the selected option
      var newImage = $(this).data("image");
      var newText = $(this).text().trim();
      $currentWrapper
        .find(".wooescrow-custom-select-trigger")
        .html(
          `<img src="${newImage}" alt="${newText}"/>${newText} <span class="wooescrow-icon"><i class="fa-solid fa-chevron-down"></i></span>`
        );

      // Update the hidden select element
      $hiddenSelect.val($(this).data("value"));

      // Close the dropdown
      $currentWrapper.removeClass("open");
    });

    // Close dropdown if clicked outside
    $(document).on("click", function (e) {
      if (!$(e.target).closest(".wooescrow-custom-select").length) {
        $(".wooescrow-custom-select").removeClass("open");
      }
    });

    // WOOESCROW COPY
    $("#wooescrow-copyButton").click(function () {
      var copyText = $("#wooescrow-copyText");
      copyText.select();
      document.execCommand("copy");

      var button = $(this);
      button.find("i").removeClass("fa-copy").addClass("fa-circle-check");
      setTimeout(function () {
        button.find("i").removeClass("fa-circle-check").addClass("fa-copy");
      }, 2000);
    });
  });
})(jQuery);
