<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://https://codepixelzmedia.com/
 * @since            1.0.0
 * @package           Wooescrow
 *
 * @wordpress-plugin
 * Plugin Name:       WooEscrow
 * Plugin URI:        https://https://wooescrow.com/
 * Description:       Integrate secure cryptocurrency payments into your WooCommerce store. Accept Bitcoin, Ethereum, and more with easy setup, robust security, and real-time exchange rates. Enhance your store with flexible, efficient crypto transactions.
 * Version:           1.0.1
 * Author:            Code Pixelz X Pwn Bot
 * Author URI:        https://https://codepixelzmedia.com//
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wooescrow
 * Domain Path:       /languages
 * Requires Plugins: woocommerce
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define('WOOESCROW_VERSION', '1.0.1');

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wooescrow-activator.php
 */
function activate_wooescrow()
{
    require_once plugin_dir_path(__FILE__) . 'includes/class-wooescrow-activator.php';
    Wooescrow_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wooescrow-deactivator.php
 */
function deactivate_wooescrow()
{
    require_once plugin_dir_path(__FILE__) . 'includes/class-wooescrow-deactivator.php';
    Wooescrow_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_wooescrow');
register_deactivation_hook(__FILE__, 'deactivate_wooescrow');

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path(__FILE__) . 'includes/class-wooescrow.php';

/* The code `require plugin_dir_path(__FILE__) . 'includes/class-register-rest-routes.php';` is
including the file `class-register-rest-routes.php` which contains the class definition for
registering REST API routes. */
require plugin_dir_path(__FILE__) . 'includes/class-register-rest-routes.php';

//new Register_Rest_Routes();

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wooescrow()
{

    $plugin = new Wooescrow();
    $plugin->run();
}
run_wooescrow();

// Plugin update test


// Function to check for plugin update for 1.0.1

