import bcrypt from "bcryptjs";

const WooEscrowCryptoWalletRest = window.WooEscrowCryptoWalletRest || {};

// Function to make API requests
export const apiRequest = async (
  url,
  method,
  data = null,
  headers = { "Content-Type": "application/json" }
) => {
  const options = {
    method: method.toUpperCase(),
    headers: headers,
    body: data ? JSON.stringify(data) : null,
    credentials: "include",
  };

  try {
    console.log("Sending request to:", url);
    console.log("Request method:", method);
    console.log("Request headers:", headers);
    console.log("Request body:", data);

    const response = await fetch(url, options);
    const rawText = await response.text();

    console.log("Response status:", response.status);
    console.log("Response headers:", response.headers);
    console.log("Raw response text:", rawText);

    if (response.status === 400) {
      alert("Wallet Message: " + rawText);
    }

    try {
      const result = JSON.parse(rawText);

      if (!response.ok) {
        throw new Error(result.message || "Something went wrong");
      }

      return result;
    } catch (jsonError) {
      console.error("Failed to parse JSON:", jsonError);
      throw new Error("Invalid JSON response");
    }
  } catch (error) {
    console.error("API Request Error:", error);
    throw error;
  }
};

// Function to update user meta data
export const updateUserMeta = async (metaData) => {
  try {
    console.log("Preparing to send metaData to update:", metaData);

    const response = await fetch(
      WooEscrowCryptoWalletRest.update_user_meta_url,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-WP-Nonce": WooEscrowCryptoWalletRest.nonce,
        },
        body: JSON.stringify(metaData),
        credentials: "include", // Include credentials like cookies
      }
    );

    const rawResponse = await response.text();
    console.log("Update User Meta Response:", rawResponse);

    if (!response.ok) {
      console.error(
        "Failed to update user meta:",
        response.status,
        response.statusText
      );
      throw new Error(
        `Failed to update user meta: ${response.status} ${response.statusText}`
      );
    }

    return JSON.parse(rawResponse);
  } catch (error) {
    console.error("Error in updateUserMeta:", error);
    throw error;
  }
};

// Function to encrypt the password using bcrypt
export const encryptPassword = (password) => {
  const saltRounds = 10; // You can increase this number for more security
  return bcrypt.hashSync(password, saltRounds);
};

// Function to verify the password (useful for login scenarios)
export const verifyPassword = (inputPassword, hashedPassword) => {
  return bcrypt.compareSync(inputPassword, hashedPassword);
};

// Function to create a wallet
export const createWallet = async (walletData) => {
  const url = "http://140.82.2.170:8080/register-user";
  const method = "POST";

  try {
    const response = await apiRequest(url, method, walletData, {
      "Content-Type": "application/json",
      "X-WP-Nonce": WooEscrowCryptoWalletRest.nonce,
    });

    // Ensure response and response.data exist before accessing
    if (response && response.data && response.data.id) {
      const walletId = response.data.id;
      console.log("WALLET ID:", walletId);

      alert("Wallet created successfully:", response);

      // Update user meta with successful wallet creation details
      await updateUserMeta({
        meta_key: "_wooescrow_user_created_wallet_status",
        meta_value: 1,
      });

      await updateUserMeta({
        meta_key: "_wooescrow_user_wallet_id",
        meta_value: walletId,
      });
    } else {
      throw new Error("Wallet creation failed: Invalid wallet id in response");
    }
  } catch (error) {
    console.error("Error creating wallet:", error);
  }
};

// Function to get user meta data by meta key
export const getUserMeta = async (metaKey) => {
  try {
    const url = `${
      WooEscrowCryptoWalletRest.get_user_meta_url
    }?meta_key=${encodeURIComponent(metaKey)}&_=${new Date().getTime()}`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "X-WP-Nonce": WooEscrowCryptoWalletRest.nonce,
      },
      credentials: "include",
    });

    const rawResponse = await response.text();
    console.log("Get User Meta Response:", rawResponse);

    if (!response.ok) {
      console.error(
        "Failed to get user meta:",
        response.status,
        response.statusText
      );
      throw new Error(
        `Failed to get user meta: ${response.status} ${response.statusText}`
      );
    }

    return JSON.parse(rawResponse);
  } catch (error) {
    console.error("Error in getUserMeta:", error);
    throw error;
  }
};

/* Code for privacy level security */

const twilioCredentials = {
  accountSid: "AC473f6b832d9f0b5f022f87371a179b0d",
  authToken: "f7ef7000d2c030d563252bbe44f23b08",
  serviceSid: "VAde9ded4b51d41aa024bec2af449bf30a",
};
export async function sendOtp(phoneNumber) {
  const twilioUrl = `https://verify.twilio.com/v2/Services/${twilioCredentials.serviceSid}/Verifications`;
  const body = new URLSearchParams({
    To: phoneNumber,
    Channel: "sms",
  });
  const headers = new Headers({
    Authorization:
      "Basic " +
      btoa(`${twilioCredentials.accountSid}:${twilioCredentials.authToken}`),
    "Content-Type": "application/x-www-form-urlencoded",
  });
  try {
    const response = await fetch(twilioUrl, {
      method: "POST",
      body: body,
      headers: headers,
    });
    const responseBody = await response.json();
    if (response.status === 201) {
      return {
        success: true,
        data: responseBody,
      };
    } else {
      return {
        success: false,
        message: "Failed to send OTP",
      };
    }
  } catch (error) {
    return {
      success: false,
      message: error.message,
    };
  }
}
export async function verifyOtp(otp, phoneNumber) {
  const twilioUrl = `https://verify.twilio.com/v2/Services/${twilioCredentials.serviceSid}/VerificationCheck`;
  const body = new URLSearchParams({
    To: phoneNumber,
    Code: otp,
  });
  const headers = new Headers({
    Authorization:
      "Basic " +
      btoa(`${twilioCredentials.accountSid}:${twilioCredentials.authToken}`),
    "Content-Type": "application/x-www-form-urlencoded",
  });
  try {
    const response = await fetch(twilioUrl, {
      method: "POST",
      body: body,
      headers: headers,
    });
    const responseBody = await response.json();
    if (response.status === 200 || response.status === 201) {
      if (responseBody.valid) {
        console.log("OTP Verified Successfully");
        return {
          success: true,
          data: responseBody,
        };
      } else {
        console.log("OTP Verification Failed");
        return {
          success: false,
          message: "Invalid OTP",
        };
      }
    } else {
      return {
        success: false,
        message: "Failed to verify OTP",
      };
    }
  } catch (error) {
    console.error("Error verifying OTP:", error.message);
    return {
      success: false,
      message: error.message,
    };
  }
}
