import React, { useState } from "react";

const TwoFactorAuth = ({ authType, onOtpSubmit }) => {
  const [otp, setOtp] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    onOtpSubmit(otp);
  };

  return (
    <div className="wooescrow-dashboard-container">
      <div className="wooescrow-dashboard-content-section">
        <div className="wooescrow-header-wrapper">
          <div className="wooescrow-header">
            <h1 className="wooescrow-title">Two Factor Verification</h1>
          </div>
        </div>
        <form
          className="wooescrow-form wooescrow-2fa-form"
          onSubmit={handleSubmit}
        >
          {authType === "sms-code" && (
            <div className="wooescrow-form-group wooescrow-2fa-form-group">
              <label
                htmlFor="wooescrow-wallet-2fa-sms"
                className="wooescrow-label"
              >
                Enter the code sent to your phone
              </label>
              <input
                autoComplete="off"
                type="number"
                id="wooescrow-wallet-2fa-sms"
                className="wooescrow-input"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                required
              />
            </div>
          )}

          {authType === "google-auth" && (
            <div className="wooescrow-form-group wooescrow-2fa-form-group">
              <label
                htmlFor="wooescrow-wallet-2fa-google"
                className="wooescrow-label"
              >
                Enter the code from your Google Authenticator app
              </label>
              <input
                autoComplete="off"
                type="number"
                id="wooescrow-wallet-2fa-google"
                className="wooescrow-input"
                value={otp} // Bind the OTP state to input value
                onChange={(e) => setOtp(e.target.value)} // Update OTP state on input change
                required
              />
            </div>
          )}

          {authType === "multi-sig" && (
            <div className="wooescrow-form-group wooescrow-2fa-form-group">
              <label
                htmlFor="wooescrow-wallet-2fa-multisig"
                className="wooescrow-label"
              >
                Enter the multi-signature verification code
              </label>
              <input
                autoComplete="off"
                type="number"
                id="wooescrow-wallet-2fa-multisig"
                className="wooescrow-input"
                value={otp} // Bind the OTP state to input value
                onChange={(e) => setOtp(e.target.value)} // Update OTP state on input change
                required
              />
            </div>
          )}
          <div className="wooescrow-form-group wooescrow-password-form-group wooescrow-password-button-group wooescrow-end">
            <button
              id="wooescrow-login-continue"
              className="wooescrow-button"
              type="submit"
            >
              Continue
              <span className="wooescrow-fa-icon">
                <i className="fa-solid fa-arrow-right-long"></i>
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TwoFactorAuth;
