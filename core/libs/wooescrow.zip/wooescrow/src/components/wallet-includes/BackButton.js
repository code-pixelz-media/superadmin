import React from "react";

const BackButton = ({ onBack }) => {
  return (
    <p
      className="wooescrow-text-para wooescrow-back-button wooescrow-blue"
      onClick={onBack}
      style={{ cursor: "pointer" }}
    >
      <span className="wooescrow-fa-icon">
        <i className="fa-solid fa-arrow-left"></i>
      </span>
      Back
    </p>
  );
};

export default BackButton;
