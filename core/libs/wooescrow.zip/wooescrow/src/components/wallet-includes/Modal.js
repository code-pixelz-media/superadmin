import React from "react";

const Modal = ({ show, onClose, children }) => {
  if (!show) {
    return null;
  }

  return (
    <div className="wooescrow-modal-overlay">
      <div className="wooescrow-modal-content">
        <button className="wooescrow-close-btn" onClick={onClose}>
          <i class="fas fa-times"></i>
        </button>
        {children}
      </div>
    </div>
  );
};

export default Modal;
