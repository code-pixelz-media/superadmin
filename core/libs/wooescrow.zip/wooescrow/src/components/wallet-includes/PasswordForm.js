import React, { useState } from "react";

const PasswordForm = ({ onPasswordSubmit }) => {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setError("Passwords do not match");
    } else if (
      !/(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#$%^&*])/.test(password)
    ) {
      setError(
        "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character"
      );
    } else {
      setError("");
      onPasswordSubmit(password);
    }
  };

  return (
    <div className="wooescrow-password-section">
      <div className="wooescrow-password-wrapper">
        <div className="wooescrow-container">
          <div className="wooescrow-header-wrapper">
            <div className="wooescrow-header">
              <h1 className="wooescrow-title">Create a Password</h1>
            </div>
          </div>
          <div className="wooescrow-password-content-wrapper">
            <form
              className="wooescrow-form wooescrow-password-form"
              onSubmit={handleSubmit}
            >
              <div className="wooescrow-form-group wooescrow-password-form-group">
                <label
                  htmlFor="wooescrow-new-password"
                  className="wooescrow-label"
                >
                  New Password
                </label>
                <input
                  type={showPassword ? "text" : "password"}
                  id="wooescrow-new-password"
                  className="wooescrow-input"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  minLength="8"
                  required
                />
                <span
                  id="wooescrow-togglePassword"
                  className="wooescrow-eye"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  <img
                    className="wooescrow-eye-img"
                    src="/wp-content/plugins/wooescrow/wooescrow-public/img/eye.svg"
                    alt="eye"
                    style={{ display: showPassword ? "none" : "block" }}
                  />
                  <img
                    className="wooescrow-eye-crossed-img"
                    src="/wp-content/plugins/wooescrow/wooescrow-public/img/eye-crossed.svg"
                    alt="eye-crossed"
                    style={{ display: showPassword ? "block" : "none" }}
                  />
                </span>
              </div>

              <div className="wooescrow-form-group wooescrow-password-form-group">
                <label
                  htmlFor="wooescrow-confirm-password"
                  className="wooescrow-label"
                >
                  Confirm Password
                </label>
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  id="wooescrow-confirm-password"
                  className="wooescrow-input"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  minLength="8"
                  required
                />
                <span
                  id="wooescrow-toggleConfirmPassword"
                  className="wooescrow-eye"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  <img
                    className="wooescrow-eye-img"
                    src="/wp-content/plugins/wooescrow/wooescrow-public/img/eye.svg"
                    alt="eye"
                    style={{ display: showConfirmPassword ? "none" : "block" }}
                  />
                  <img
                    className="wooescrow-eye-crossed-img"
                    src="/wp-content/plugins/wooescrow/wooescrow-public/img/eye-crossed.svg"
                    alt="eye-crossed"
                    style={{ display: showConfirmPassword ? "block" : "none" }}
                  />
                </span>
              </div>

              {error && (
                <p className="wooescrow-error-message wooescrow-text-para">
                  {error}
                </p>
              )}

              <div className="wooescrow-form-group wooescrow-password-form-group wooescrow-password-button-group wooescrow-end">
                <button
                  id="wooescrow-password-continue"
                  className="wooescrow-button"
                  type="submit"
                >
                  Continue
                  <span className="wooescrow-fa-icon">
                    <i className="fa-solid fa-arrow-right-long"></i>
                  </span>
                </button>
              </div>
            </form>

            <div className="wooescrow-term-conditions-text">
              <p className="wooescrow-text-para">
                By clicking on “continue” you agree to the{" "}
                <a href="#" className="wooescrow-link">
                  term and condition
                </a>{" "}
                of WooEscrow.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PasswordForm;
