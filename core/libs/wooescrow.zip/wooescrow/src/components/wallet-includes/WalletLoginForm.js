import React, { useState } from "react";

const WalletLoginForm = ({ onWalletLoginSubmit }) => {
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!password) {
      setError("Password is required");
    } else {
      setError("");
      onWalletLoginSubmit(password);
    }
  };

  return (
    <div className="wooescrow-password-section">
      <div className="wooescrow-password-wrapper">
        <div className="wooescrow-container">
          <div className="wooescrow-header-wrapper">
            <div className="wooescrow-header">
              <h1 className="wooescrow-title">Login to Wallet</h1>
            </div>
          </div>
          <div className="wooescrow-password-content-wrapper">
            <form
              className="wooescrow-form wooescrow-password-form"
              onSubmit={handleSubmit}
            >
              <div className="wooescrow-form-group wooescrow-password-form-group">
                <label
                  htmlFor="wooescrow-wallet-password"
                  className="wooescrow-label"
                >
                  Enter Wallet Password
                </label>
                <input
                  type={showPassword ? "text" : "password"}
                  id="wooescrow-wallet-password"
                  className="wooescrow-input"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <span
                  id="wooescrow-togglePassword"
                  className="wooescrow-eye"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  <img
                    className="wooescrow-eye-img"
                    src="/wp-content/plugins/wooescrow/wooescrow-public/img/eye.svg"
                    alt="eye"
                    style={{ display: showPassword ? "none" : "block" }}
                  />
                  <img
                    className="wooescrow-eye-crossed-img"
                    src="/wp-content/plugins/wooescrow/wooescrow-public/img/eye-crossed.svg"
                    alt="eye-crossed"
                    style={{ display: showPassword ? "block" : "none" }}
                  />
                </span>
              </div>

              {error && (
                <p className="wooescrow-error-message wooescrow-text-para">
                  {error}
                </p>
              )}

              <div className="wooescrow-form-group wooescrow-password-form-group wooescrow-password-button-group wooescrow-end">
                <button
                  id="wooescrow-login-continue"
                  className="wooescrow-button"
                  type="submit"
                >
                  Login
                  <span className="wooescrow-fa-icon">
                    <i className="fa-solid fa-arrow-right-long"></i>
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WalletLoginForm;
