import React, { useState } from "react";
import Switch from "react-switch"; // Importing the react-switch component

const Notifications = () => {
  const [pushNotificationEnabled, setPushNotificationEnabled] = useState(false);
  const [sendReceiveNotificationEnabled, setSendReceiveNotificationEnabled] =
    useState(false);
  const [productAnnouncementsEnabled, setProductAnnouncementsEnabled] =
    useState(false);

  const handleTogglePushNotification = () => {
    setPushNotificationEnabled(!pushNotificationEnabled);
  };

  const handleToggleSendReceiveNotification = () => {
    setSendReceiveNotificationEnabled(!sendReceiveNotificationEnabled);
  };

  const handleToggleProductAnnouncements = () => {
    setProductAnnouncementsEnabled(!productAnnouncementsEnabled);
  };

  return (
    <div className="wooescrow-setting-section">
      <div className="wooescrow-dashboard-notification-section">
        <div className="wooescrow-notification-options">
          <h2 className="wooescrow-notification-options-title wooescrow-title">
            Notification Settings
          </h2>
          <p className="wooescrow-notification-options-subtitle wooescrow-text-para">
            Manage your notifications for Wooescrow
          </p>
        </div>

        <div className="wooescrow-notification-items">
          <div className="wooescrow-notification-toggle-option">
            <div className="wooescrow-notification-toggle-header">
              <div className="wooescrow-notification-title-container">
                <h4 className="wooescrow-title">Allow Push Notifications</h4>
                <i className="fa-solid fa-info-circle wooescrow-info-icon">
                  <span className="wooescrow-info-tooltip">
                    Push notifications will alert you when important activities
                    happen in your account.
                  </span>
                </i>
              </div>
              <Switch
                onChange={handleTogglePushNotification}
                checked={pushNotificationEnabled}
                offColor="#b7bcc8"
                onColor="#0047fa"
                className="wooescrow-switch"
                height={35}
                width={55}
                handleDiameter={35}
              />
            </div>
          </div>

          <div className="wooescrow-notification-toggle-option">
            <div className="wooescrow-notification-toggle-header">
              <div className="wooescrow-notification-title-container">
                <h4 className="wooescrow-title">
                  Send and Receive Notifications
                </h4>
                <i className="fa-solid fa-info-circle wooescrow-info-icon">
                  <span className="wooescrow-info-tooltip">
                    Receive notifications about your transactions (sending and
                    receiving payments).
                  </span>
                </i>
              </div>
              <Switch
                onChange={handleToggleSendReceiveNotification}
                checked={sendReceiveNotificationEnabled}
                offColor="#b7bcc8"
                onColor="#0047fa"
                className="wooescrow-switch"
                height={35}
                width={55}
                handleDiameter={35}
              />
            </div>
          </div>

          <div className="wooescrow-notification-toggle-option">
            <div className="wooescrow-notification-toggle-header">
              <div className="wooescrow-notification-title-container">
                <h4 className="wooescrow-title">Product Announcements</h4>
                <i className="fa-solid fa-info-circle wooescrow-info-icon">
                  <span className="wooescrow-info-tooltip">
                    Get updates on new product features and exclusive offers.
                  </span>
                </i>
              </div>
              <Switch
                onChange={handleToggleProductAnnouncements}
                checked={productAnnouncementsEnabled}
                offColor="#b7bcc8"
                onColor="#0047fa"
                className="wooescrow-switch"
                height={35}
                width={55}
                handleDiameter={35}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Notifications;
