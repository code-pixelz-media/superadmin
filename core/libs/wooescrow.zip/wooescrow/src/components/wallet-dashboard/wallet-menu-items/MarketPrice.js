import React from "react";

const MarketPrice = () => {
  return (
    <>
      <div className="wooescrow-tab-content-header">
        <p className="wooescrow-text-para wooescrow-uppercase">MARKET PRICE</p>
        <div className="wooescrow-radio-group">
          {/* Hour */}
          <input type="radio" name="date" value="hour" id="wooescrow-hour" />
          <label htmlFor="wooescrow-hour" className="wooescrow-radio-label">
            1h
          </label>
          {/* Day */}
          <input
            type="radio"
            name="date"
            value="day"
            id="wooescrow-day"
            defaultChecked
          />
          <label htmlFor="wooescrow-day" className="wooescrow-radio-label">
            1d
          </label>
          {/* Month */}
          <input type="radio" name="date" value="month" id="wooescrow-month" />
          <label htmlFor="wooescrow-month" className="wooescrow-radio-label">
            1m
          </label>
          {/* Year */}
          <input type="radio" name="date" value="year" id="wooescrow-year" />
          <label htmlFor="wooescrow-year" className="wooescrow-radio-label">
            1y
          </label>
          {/* All */}
          <input type="radio" name="date" value="all" id="wooescrow-all" />
          <label htmlFor="wooescrow-all" className="wooescrow-radio-label">
            all
          </label>
        </div>
      </div>
      <div className="wooescrow-tab-content-body">
        <div className="wooescrow-table-wrapper">
          <table id="wooescrow-overview-table-full" className="wooescrow-table">
            <thead>
              <tr>
                <th>Bitcoin</th>
                <th>Last price</th>
                <th>Change</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="wooescrow-td-title-currency">
                  <div className="wooescrow-td-currency-wrap">
                    <span className="wooescrow-td-image">
                      <img
                        src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                        alt="eth"
                      />
                    </span>
                    <div className="wooescrow-td-content">
                      <h5 className="wooescrow-td-name wooescrow-uppercase">
                        eth
                      </h5>
                      <p className="wooescrow-td-currency wooescrow-text-para">
                        Ethereum
                      </p>
                    </div>
                  </div>
                </td>
                <td className="wooescrow-td-last-price">€60,726.69</td>
                <td className="wooescrow-td-change wooescrow-up">+5.58%</td>
                <td className="wooescrow-td-action">
                  <button
                    id="wooescrow-secuity-buy-button"
                    className="wooescrow-button"
                  >
                    buy
                  </button>
                  <button
                    id="wooescrow-secuity-swap-button"
                    className="wooescrow-button"
                  >
                    swap
                  </button>
                </td>
              </tr>
              {/* Additional rows */}
              <tr>
                <td className="wooescrow-td-title-currency">
                  <div className="wooescrow-td-currency-wrap">
                    <span className="wooescrow-td-image">
                      <img
                        src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                        alt="eth"
                      />
                    </span>
                    <div className="wooescrow-td-content">
                      <h5 className="wooescrow-td-name wooescrow-uppercase">
                        eth
                      </h5>
                      <p className="wooescrow-td-currency wooescrow-text-para">
                        Ethereum
                      </p>
                    </div>
                  </div>
                </td>
                <td className="wooescrow-td-last-price">€60,726.69</td>
                <td className="wooescrow-td-change wooescrow-up">+5.58%</td>
                <td className="wooescrow-td-action">
                  <button
                    id="wooescrow-secuity-buy-button"
                    className="wooescrow-button"
                  >
                    buy
                  </button>
                  <button
                    id="wooescrow-secuity-swap-button"
                    className="wooescrow-button"
                  >
                    swap
                  </button>
                </td>
              </tr>
              <tr>
                <td className="wooescrow-td-title-currency">
                  <div className="wooescrow-td-currency-wrap">
                    <span className="wooescrow-td-image">
                      <img
                        src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                        alt="eth"
                      />
                    </span>
                    <div className="wooescrow-td-content">
                      <h5 className="wooescrow-td-name wooescrow-uppercase">
                        eth
                      </h5>
                      <p className="wooescrow-td-currency wooescrow-text-para">
                        Ethereum
                      </p>
                    </div>
                  </div>
                </td>
                <td className="wooescrow-td-last-price">€60,726.69</td>
                <td className="wooescrow-td-change wooescrow-down">-5.58%</td>
                <td className="wooescrow-td-action">
                  <button
                    id="wooescrow-secuity-buy-button"
                    className="wooescrow-button"
                  >
                    buy
                  </button>
                  <button
                    id="wooescrow-secuity-swap-button"
                    className="wooescrow-button"
                  >
                    swap
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
          <div className="wooescrow-view-all wooescrow-center">
            <a className="wooescrow-link" href="#">
              View all
            </a>
          </div>
        </div>
      </div>
    </>
  );
};

export default MarketPrice;
