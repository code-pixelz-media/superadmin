import React, { useEffect } from "react";
import { loadMoonPay } from "@moonpay/moonpay-js";

const MoonPay = ({ onClose }) => {
  useEffect(() => {
    const initializeMoonPay = async () => {
      try {
        const moonPay = await loadMoonPay();

        const widget = moonPay?.({
          flow: "buy",
          environment: "sandbox", // Use "production" for live
          params: {
            apiKey: "pk_test_MscSKdazk71mQ4ZRuitU4KKUT2wvg", // Replace with your actual API key
          },
          variant: "overlay",
          handlers: {
            async onTransactionCompleted(props) {
              console.log("Transaction completed:", props);
              // Add any additional logic you want to handle after transaction completion
            },
            onClose: () => {
              console.log("MoonPay widget closed");
              onClose(); // Call onClose to hide the widget
            },
            onError: (error) => {
              console.error("MoonPay Error:", error);
            },
          },
        });

        widget?.show();
      } catch (error) {
        console.error("Error loading MoonPay:", error);
      }
    };

    initializeMoonPay();

    // Clean up the widget on unmount
    return () => {
      // Any necessary cleanup
    };
  }, [onClose]);
};

export default MoonPay;
