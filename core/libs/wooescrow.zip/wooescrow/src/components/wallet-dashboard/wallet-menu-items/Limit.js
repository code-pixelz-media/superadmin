import React from "react";

const Limit = () => {
  return (
    <div className="wooescrow-setting-section">
      <div className="wooescrow-dashboard-limit-section">
        <h2 className="wooescrow-title">Limit</h2>
        <p className="wooescrow-text-para">Set and manage your limits here.</p>
        {/* Add functionality to set and manage limits */}
      </div>
    </div>
  );
};

export default Limit;
