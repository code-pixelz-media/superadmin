import React, { useEffect, useState } from "react";
import axios from "axios";
import BitcoinWalletGenerator from "../../create-wallet/BitcoinWalletGenerator";
import EthereumWalletGenerator from "../../create-wallet/EthereumWalletGenerator";
import SolanaWalletGenerator from "../../create-wallet/SolanaWalletGenerator";
import BackButton from "../../wallet-includes/BackButton";
import { getUserMeta } from "../../wallet-includes/api";
import AddWalletDetails from "./AddWalletDetails";

const AddWallet = ({ onBack }) => {
  const [step, setStep] = useState(1);
  const [selectedCurrency, setSelectedCurrency] = useState("");
  const [availableCurrencies, setAvailableCurrencies] = useState([]);
  const [allCurrenciesOwned, setAllCurrenciesOwned] = useState(false);
  const [walletData, setWalletData] = useState(null);

  const supportedCurrencies = [
    {
      code: "BTC",
      name: "Bitcoin",
      imgSrc:
        "/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png",
    },
    {
      code: "ETH",
      name: "Ethereum",
      imgSrc:
        "/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png",
    },
    {
      code: "SOL",
      name: "Solana",
      imgSrc:
        "/wp-content/plugins/wooescrow/wooescrow-public/img/sol-small.png",
    },
  ];

  useEffect(() => {
    const fetchUserCurrencies = async () => {
      try {
        const userId = await getUserMeta("_wooescrow_user_wallet_id");
        const response = await axios.get(
          `http://api.spitout.com:8080/users-detail/${userId.meta_value}`
        );

        // Ensure that 'wallet_addresses' exists and is an array
        const walletAddresses = response.data.wallet_addresses || [];

        // Extract network (currency) from wallet addresses
        const walletCurrencies = walletAddresses.map(
          (wallet) => wallet.network
        );

        // Filter out the currencies that the user already owns
        const filteredCurrencies = supportedCurrencies.filter(
          (currency) => !walletCurrencies.includes(currency.code)
        );

        setAvailableCurrencies(filteredCurrencies);
        setAllCurrenciesOwned(filteredCurrencies.length === 0);
      } catch (error) {
        console.error("Error fetching user wallet currencies:", error);
      }
    };

    fetchUserCurrencies();
  }, []);

  const handleCurrencyChange = (event) => {
    setSelectedCurrency(event.target.value);
  };

  const handleCreate = () => {
    if (selectedCurrency) {
      setStep(2);
    } else {
      console.error("No currency selected");
    }
  };

  const handleMnemonicGenerated = (mnemonic, data) => {
    setWalletData(data);
    setStep(3);
  };

  const renderCurrencySelection = () => (
    <div className="wooescrow-add-wallet-section">
      <div className="wooescrow-header-wrapper">
        <h1 className="wooescrow-title">Add Wallet</h1>
      </div>

      <div className="wooescrow-wallet-currency-section">
        <div className="wooescrow-wallet-currency-wrapper">
          <div className="wooescrow-container">
            <div className="wooescrow-header">
              <p className="wooescrow-text-para">
                Select the wallet’s currency
              </p>
            </div>

            {allCurrenciesOwned ? (
              <p className="wooescrow-text-para">
                Your wallet already has all available currencies.
              </p>
            ) : (
              <div className="wooescrow-wallet-currency-content-wrapper">
                <div className="wooescrow-wallet-currency-cards wooescrow-wallet-currency-radio-cards">
                  {availableCurrencies.map((currency) => (
                    <label
                      key={currency.code}
                      className="wooescrow-wallet-currency-card"
                    >
                      <input
                        className="wooescrow-wallet-currency-radio-box"
                        type="radio"
                        name="wooescrow-wallet-currency-radio-box"
                        value={currency.code}
                        onChange={handleCurrencyChange}
                      />
                      <div className="wooescrow-wallet-currency-btn">
                        <div className="wooescrow-wallet-currency-card-img">
                          <img src={currency.imgSrc} alt={currency.name} />
                        </div>
                        <div className="wooescrow-wallet-currency-card-body">
                          <h5 className="wooescrow-title wooescrow-uppercase">
                            {currency.code}
                          </h5>
                          <p className="wooescrow-text-para">{currency.name}</p>
                        </div>
                      </div>
                    </label>
                  ))}
                </div>

                <div className="wooescrow-wallet-currency-next-btn wooescrow-end">
                  <button
                    type="button"
                    className="wooescrow-button"
                    onClick={handleCreate}
                  >
                    Next
                    <span className="wooescrow-fa-icon">
                      <i className="fa-solid fa-arrow-right-long"></i>
                    </span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  const renderWalletGenerator = () => {
    switch (selectedCurrency) {
      case "BTC":
        return (
          <BitcoinWalletGenerator
            onMnemonicGenerated={handleMnemonicGenerated}
          />
        );
      case "ETH":
        return (
          <EthereumWalletGenerator
            onMnemonicGenerated={handleMnemonicGenerated}
          />
        );
      case "SOL":
        return (
          <SolanaWalletGenerator
            onMnemonicGenerated={handleMnemonicGenerated}
          />
        );
      default:
        return <div>No generator available for this currency.</div>;
    }
  };

  return (
    <>
      <BackButton onBack={onBack} />
      {step === 1 && renderCurrencySelection()}
      {step === 2 && renderWalletGenerator()}
      {step === 3 && walletData && (
        <AddWalletDetails
          selectedCurrency={selectedCurrency}
          walletData={walletData}
          onBack={() => setStep(2)}
        />
      )}
    </>
  );
};

export default AddWallet;
