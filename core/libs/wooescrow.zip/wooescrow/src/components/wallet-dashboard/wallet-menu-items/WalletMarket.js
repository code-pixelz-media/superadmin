// src/components/Wallet.js
import React from "react";

const WalletMarket = () => {
  return (
    <div className="wooescrow-tab-content-body">
      {/* Header Section with Radio Buttons */}
      <div className="wooescrow-tab-content-header">
        <p className="wooescrow-text-para wooescrow-uppercase">WALLETS</p>
        <div className="wooescrow-radio-group">
          <input type="radio" name="date" value="hour" id="wooescrow-hour" />
          <label htmlFor="wooescrow-hour" className="wooescrow-radio-label">
            1h
          </label>
          <input
            type="radio"
            name="date"
            value="day"
            id="wooescrow-day"
            defaultChecked
          />
          <label htmlFor="wooescrow-day" className="wooescrow-radio-label">
            1d
          </label>
          <input type="radio" name="date" value="month" id="wooescrow-month" />
          <label htmlFor="wooescrow-month" className="wooescrow-radio-label">
            1m
          </label>
          <input type="radio" name="date" value="year" id="wooescrow-year" />
          <label htmlFor="wooescrow-year" className="wooescrow-radio-label">
            1y
          </label>
          <input type="radio" name="date" value="all" id="wooescrow-all" />
          <label htmlFor="wooescrow-all" className="wooescrow-radio-label">
            all
          </label>
        </div>
      </div>

      {/* Table Section with Market Data */}
      <div className="wooescrow-tab-content-body">
        <div className="wooescrow-table-wrapper">
          <table
            id="wooescrow-my-assets-table-full"
            className="wooescrow-table"
          >
            <thead>
              <tr>
                <th>Bitcoin</th>
                <th>Total Balance</th>
                <th>Change</th>
              </tr>
            </thead>
            <tbody>
              {/* Repeat rows for each currency as needed */}
              <tr>
                <td className="wooescrow-td-title-currency">
                  <div className="wooescrow-td-currency-wrap">
                    <span className="wooescrow-td-image">
                      <img
                        src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                        alt="eth"
                      />
                    </span>
                    <div className="wooescrow-td-content">
                      <h5 className="wooescrow-td-name wooescrow-uppercase">
                        ETH
                      </h5>
                      <p className="wooescrow-td-currency">Ethereum</p>
                    </div>
                  </div>
                </td>
                <td className="wooescrow-td-total-balance">
                  €60,726.69{" "}
                  <span className="wooescrow-currency">0.254 BTC</span>
                </td>
                <td className="wooescrow-td-change">
                  <div className="wooescrow-td-change-wrap">
                    <span className="wooescrow-up">+5.58%</span>
                    <span className="wooescrow-td-graph">-</span>
                    <span className="wooescrow-td-change-info">
                      <div className="wooescrow-icon wooescrow-dot-trigger">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="4"
                          height="20"
                          viewBox="0 0 4 20"
                        >
                          <circle cx="2" cy="2" r="2" fill="#5b616e" />
                          <circle
                            cx="2"
                            cy="2"
                            r="2"
                            transform="translate(0 8)"
                            fill="#5b616e"
                          />
                          <circle
                            cx="2"
                            cy="2"
                            r="2"
                            transform="translate(0 16)"
                            fill="#5b616e"
                          />
                        </svg>
                      </div>
                      <ul className="wooescrow-change-transaction-lists">
                        <li className="wooescrow-change-transaction-list-item">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="20.045"
                            height="18.324"
                            viewBox="0 0 20.045 18.324"
                          >
                            {/* SVG Path */}
                          </svg>{" "}
                          <span>Buy</span>
                        </li>
                        {/* Add more items as needed */}
                      </ul>
                    </span>
                  </div>
                </td>
              </tr>
              {/* Add more rows as needed */}
            </tbody>
          </table>
          <div className="wooescrow-view-all wooescrow-center">
            <a className="wooescrow-link" href="#">
              View all
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WalletMarket;
