import React, { useState } from "react";
import BackButton from "../../wallet-includes/BackButton"; // Adjust the import path as necessary

const PaymentMethods = () => {
  const [addingPaymentMethod, setAddingPaymentMethod] = useState(false);

  const handleAddPaymentMethod = () => {
    setAddingPaymentMethod(true);
  };

  const handleBack = () => {
    setAddingPaymentMethod(false);
  };

  return (
    <div className="wooescrow-setting-section">
      <div className="wooescrow-dashboard-payment-section">
        {addingPaymentMethod ? (
          <div className="wooescrow-add-payment-method">
            <BackButton onBack={handleBack} />
            <h2 className="wooescrow-title">Add a Payment Method</h2>
            <div className="wooescrow-payment-method-option">
              <i className="fa-solid fa-credit-card wooescrow-payment-method-icon"></i>
              <div className="wooescrow-payment-options-body">
                <div className="wooescrow-payment-method-title">
                  Credit/Debit Card
                </div>
                <p className="wooescrow-text-para">
                  Use any Visa or MasterCard to make investments.
                </p>
              </div>
              <i className="fa-solid fa-chevron-right wooescrow-next-icon"></i>
            </div>

            <div className="wooescrow-payment-method-option">
              <i className="fa-brands fa-paypal wooescrow-payment-method-icon"></i>
              <div className="wooescrow-payment-options-body">
                <div className="wooescrow-payment-method-title">PayPal</div>
                <p className="wooescrow-text-para">
                  Use your PayPal account to instantly buy crypto or withdraw
                  funds.
                </p>
              </div>
              <i className="fa-solid fa-chevron-right wooescrow-next-icon"></i>
            </div>

            <div className="wooescrow-payment-method-option">
              <i className="fa-solid fa-university wooescrow-payment-method-icon"></i>
              <div className="wooescrow-payment-options-body">
                <div className="wooescrow-payment-method-title">
                  Bank Account
                </div>
                <p className="wooescrow-text-para">
                  Add any bank account that can make and accept transfers.
                </p>
              </div>
              <i className="fa-solid fa-chevron-right wooescrow-next-icon"></i>
            </div>
          </div>
        ) : (
          <div className="wooescrow-no-payment-methods">
            <h2 className="wooescrow-title">Payment Methods</h2>
            <p className="wooescrow-text-para">
              Link your bank account, cards...
            </p>
            <button
              className="wooescrow-button"
              onClick={handleAddPaymentMethod}
            >
              Add a payment method
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default PaymentMethods;
