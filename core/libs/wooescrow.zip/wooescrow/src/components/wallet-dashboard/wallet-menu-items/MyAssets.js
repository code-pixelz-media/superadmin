// src/components/MyAssetsTabContent.js
import React from "react";
import Balance from "./Balance"; // Import the Balance component
import WalletMarket from "./WalletMarket"; // Import the combined Wallet component
import WalletTransactions from "./WalletTransactions"; // Import the combined Wallet component

const MyAssetsTabContent = () => {
  return (
    <>
      <div className="wooescrow-my-assets-content">
        <div className="wooescrow-my-assets-top-content">
          <div className="wooescrow-tab-side-content">
            <Balance /> {/* Use the Balance component here */}
          </div>

          <div className="wooescrow-tab-main-content wooescrow-tab-container">
            <WalletMarket /> {/* Use the Wallet component here */}
          </div>
        </div>

        <div className="wooescrow-my-assets-bottom-content">
          <WalletTransactions /> {/* Use the Wallet component here */}
        </div>
      </div>
    </>
  );
};

export default MyAssetsTabContent;
