import React, { useState, useEffect } from "react";
import { updateUserMeta } from "../../wallet-includes/api";

const SmsAuthSetup = ({ phone: initialPhone, onComplete, onPhoneUpdate }) => {
  const [phone, setPhone] = useState(initialPhone || "");
  const [setupComplete, setSetupComplete] = useState(false);
  const [isPhoneSaved, setIsPhoneSaved] = useState(!!initialPhone);

  useEffect(() => {
    if (initialPhone) {
      setPhone(initialPhone);
      setIsPhoneSaved(true);
    }
  }, [initialPhone]);

  const handlePhoneSubmit = async () => {
    if (!phone) {
      alert("Please enter a valid phone number.");
      return;
    }

    const metaKey = "_wooescrow_user_phone_number";
    try {
      await updateUserMeta({
        meta_key: metaKey,
        meta_value: phone,
      });

      setIsPhoneSaved(true);
      onPhoneUpdate(phone);
      setSetupComplete(true);
    } catch (error) {
      console.error("Error saving phone number:", error);
      alert("There was an error saving your phone number.");
    }
  };

  return (
    <div className="wooescrow-sms-container">
      <h3 className="wooescrow-title">Set up SMS Authentication</h3>
      <div className="wooescrow-sms-content">
        <label>Phone Number:</label>
        <input
          type="tel"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          placeholder="+XXX-XXXXXXXXX"
          required="true"
        />
      </div>
      <div className="wooescrow-privacy-security-btn">
        <button className="wooescrow-button" onClick={handlePhoneSubmit}>
          {isPhoneSaved ? "Update Phone Number" : "Save Phone Number"}
        </button>
      </div>
    </div>
  );
};

export default SmsAuthSetup;
