import React from "react";

const Logout = ({ onLogout }) => {
  const handleLogout = () => {
    // Clear the session or token data
    localStorage.removeItem("walletLoggedIn");
    localStorage.removeItem("walletUserID");
    window.location.reload();

    // Call the onLogout prop to handle UI changes
    onLogout();

    // Reload the page to ensure the state is reset and login form is shown

    console.log("Logging out...");
  };

  return (
    <div className="wooescrow-setting-section">
      <div className="wooescrow-dashboard-logout-section">
        <h2 className="wooescrow-title">Ready to Log Out?</h2>
        <p className="wooescrow-text-para">
          You're about to log out from your account. Click the button below to
          securely end your session.
        </p>
        <button
          onClick={handleLogout}
          className="wooescrow-button wooescrow-rose"
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default Logout;
