import React, { useState } from "react";

const Exchange = () => {
  const [sendCurrency, setSendCurrency] = useState("eth");
  const [receiveCurrency, setReceiveCurrency] = useState("eth");
  const [isSendDropdownOpen, setIsSendDropdownOpen] = useState(false);
  const [isReceiveDropdownOpen, setIsReceiveDropdownOpen] = useState(false);

  const currencies = [
    {
      value: "eth",
      label: "ETH",
      image: "/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png",
    },
    {
      value: "btc",
      label: "BTC",
      image: "/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png",
    },
    {
      value: "sol",
      label: "SOL",
      image: "/wp-content/plugins/wooescrow/wooescrow-public/img/sol-small.png",
    },
  ];

  const handleSendCurrencyChange = (currency) => {
    setSendCurrency(currency);
    setIsSendDropdownOpen(false);
  };

  const handleReceiveCurrencyChange = (currency) => {
    setReceiveCurrency(currency);
    setIsReceiveDropdownOpen(false);
  };

  const getCurrencyData = (currency) => {
    return currencies.find((c) => c.value === currency) || currencies[0]; // Default to first currency if not found
  };

  return (
    <div id="wooescrow-exchange-tab-content" className="wooescrow-tab-content">
      <div className="wooescrow-exchange-tab-content-wrap">
        <div className="wooescrow-exchnage-amount-wrap">
          <div className="wooescrow-exchange-amount wooescrow-amount-send">
            <span className="wooescrow-send">Send</span>
            <div className="wooescrow-amount-send-wrap">
              <div className="wooescrow-custom-select-container">
                <div
                  className="wooescrow-custom-select-wrapper"
                  onClick={() => setIsSendDropdownOpen(!isSendDropdownOpen)}
                >
                  <div className="wooescrow-custom-select">
                    <div className="wooescrow-custom-select-trigger">
                      <img
                        src={getCurrencyData(sendCurrency).image}
                        alt={sendCurrency}
                      />
                      {getCurrencyData(sendCurrency).label}
                      <span className="wooescrow-icon">
                        <i className="fa-solid fa-chevron-down"></i>
                      </span>
                    </div>
                    {isSendDropdownOpen && (
                      <div className="wooescrow-custom-options">
                        {currencies.map((currency) => (
                          <div
                            key={currency.value}
                            className={`wooescrow-custom-option ${
                              currency.value === sendCurrency ? "selected" : ""
                            }`}
                            onClick={() =>
                              handleSendCurrencyChange(currency.value)
                            }
                          >
                            <img src={currency.image} alt={currency.label} />
                            {currency.label}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                <select
                  id="wooescrow-original-select"
                  value={sendCurrency}
                  onChange={(e) => handleSendCurrencyChange(e.target.value)}
                >
                  {currencies.map((currency) => (
                    <option key={currency.value} value={currency.value}>
                      {currency.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="wooescrow-amount-send-total">
                <span className="wooescrow-blue">150,000</span>
                <button id="wooescrow-all-amount" className="wooescrow-button">
                  All amount
                </button>
              </div>
            </div>
          </div>
          <div className="wooescrow-exchange-amount wooescrow-amount-receive">
            <span className="wooescrow-receive">Receive</span>
            <div className="wooescrow-amount-receive-wrap">
              <div
                className="wooescrow-custom-select-wrapper"
                onClick={() => setIsReceiveDropdownOpen(!isReceiveDropdownOpen)}
              >
                <div className="wooescrow-custom-select">
                  <div className="wooescrow-custom-select-trigger">
                    <img
                      src={getCurrencyData(receiveCurrency).image}
                      alt={receiveCurrency}
                    />
                    {getCurrencyData(receiveCurrency).label}
                    <span className="wooescrow-icon">
                      <i className="fa-solid fa-chevron-down"></i>
                    </span>
                  </div>
                  {isReceiveDropdownOpen && (
                    <div className="wooescrow-custom-options">
                      {currencies.map((currency) => (
                        <div
                          key={currency.value}
                          className={`wooescrow-custom-option ${
                            currency.value === receiveCurrency ? "selected" : ""
                          }`}
                          onClick={() =>
                            handleReceiveCurrencyChange(currency.value)
                          }
                        >
                          <img src={currency.image} alt={currency.label} />
                          {currency.label}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <select
                id="wooescrow-original-select"
                value={receiveCurrency}
                onChange={(e) => handleReceiveCurrencyChange(e.target.value)}
              >
                {currencies.map((currency) => (
                  <option key={currency.value} value={currency.value}>
                    {currency.label}
                  </option>
                ))}
              </select>
              <div className="wooescrow-amount-receive-total">
                <span>ETH 52,456</span>
              </div>
            </div>
          </div>
        </div>
        <div className="wooescrow-rates-swap-wrap">
          <table className="wooescrow-rates-table">
            <tr className="wooescrow-available-amount">
              <th>Available Amount:</th>
              <td>ETH 52,456</td>
            </tr>
            <tr className="wooescrow-rate">
              <th>Rate:</th>
              <td>1 USDT = 0,045 ETH</td>
            </tr>
            <tr className="wooescrow-fee">
              <th>Fee:</th>
              <td>13,12 USD</td>
            </tr>
          </table>
          <div className="wooescrow-currency-swap">
            <button className="wooescrow-button" id="wooescrow-swap-button">
              <svg
                id="refresh"
                xmlns="http://www.w3.org/2000/svg"
                width="21.12"
                height="21.201"
                viewBox="0 0 21.12 21.201"
              >
                <path
                  id="Tracciato_22"
                  d="M10.606,1.767A8.862,8.862,0,0,1,16.9,4.417H14.139a.883.883,0,0,0-.883.883h0a.883.883,0,0,0,.883.883H17.8a1.641,1.641,0,0,0,1.64-1.64V.883A.883.883,0,0,0,18.556,0h0a.883.883,0,0,0-.883.883V2.719A10.584,10.584,0,0,0,.049,9.628a.89.89,0,0,0,.883.972h0a.867.867,0,0,0,.874-.776,8.846,8.846,0,0,1,8.8-8.058Z"
                  transform="translate(-0.046 0.001)"
                  fill="#fff"
                />
                <path
                  id="Tracciato_23"
                  d="M20.507,12a.867.867,0,0,0-.874.776A8.821,8.821,0,0,1,4.542,18.183H7.3a.883.883,0,0,0,.883-.883h0a.883.883,0,0,0-.883-.883H3.64A1.64,1.64,0,0,0,2,18.057v3.66a.883.883,0,0,0,.883.883h0a.883.883,0,0,0,.883-.883V19.881a10.584,10.584,0,0,0,17.623-6.91A.89.89,0,0,0,20.506,12Z"
                  transform="translate(-0.274 -1.399)"
                  fill="#fff"
                />
              </svg>
              <span className="wooescrow-button-text">SWAP NOW</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Exchange;
