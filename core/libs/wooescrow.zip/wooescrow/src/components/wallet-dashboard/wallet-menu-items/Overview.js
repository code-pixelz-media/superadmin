import React from "react";
import Balance from "./Balance"; // Import the Balance component
import MarketPrice from "./MarketPrice";

const OverviewTabContent = () => {
  return (
    <div id="wooescrow-overview-tab-content" className="wooescrow-tab-content">
      <div className="wooescrow-tab-main-content wooescrow-tab-container">
        {/* Content related to the overview and market price */}
        <MarketPrice />
      </div>
      <div className="wooescrow-tab-side-content">
        <Balance /> {/* Use the Balance component here */}
        {/* <div className="wooescrow-currency-transactions">
          <ul className="wooescrow-currency-transactions-list">
            <li className="wooescrow-currency-transactions-list-item active">
              Buy
            </li>
            <li className="wooescrow-currency-transactions-list-item">Sell</li>
            <li className="wooescrow-currency-transactions-list-item">Send</li>
            <li className="wooescrow-currency-transactions-list-item">
              Receive
            </li>
          </ul>
        </div> */}
      </div>
    </div>
  );
};

export default OverviewTabContent;
