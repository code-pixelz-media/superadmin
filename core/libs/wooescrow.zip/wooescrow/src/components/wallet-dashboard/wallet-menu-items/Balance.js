import React, { useState, useEffect, useRef } from "react";
import { JsonRpcProvider, formatEther } from "ethers";
import axios from "axios";
import Clipboard from "clipboard";
import { getUserMeta } from "../../wallet-includes/api";
import MoonPay from "./MoonPay"; // Import the MoonPay component

const Balance = () => {
  const [balance, setBalance] = useState("Loading...");
  const [currency, setCurrency] = useState("");
  const [walletAddress, setWalletAddress] = useState("");
  const [loading, setLoading] = useState(true);
  const [copyMessage, setCopyMessage] = useState("");
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [walletAddresses, setWalletAddresses] = useState([]);
  const [showMoonPay, setShowMoonPay] = useState(false);
  const [widgetKey, setWidgetKey] = useState(0); // Key to force re-mount

  const dropdownRef = useRef(null);
  const triggerRef = useRef(null);

  const rpcUrls = {
    ETH: "https://mainnet.infura.io/v3/1ec3c4ba4c3242228ffe0c4cbcede2a8",
    BTC: "https://api.blockcypher.com/v1/btc/main",
    SOL: "https://api.devnet.solana.com",
  };

  const [provider, setProvider] = useState(null);

  // Function to format wallet address
  const formatWalletAddress = (address) => {
    if (!address) return "";
    return `${address.slice(0, 7)}...${address.slice(-5)}`; // Format to 0xaE5...55f
  };

  // Fetch wallet data from the external API
  const fetchWalletData = async () => {
    try {
      // Get the access token from local storage
      const accessToken = localStorage.getItem("accessToken");

      // Fetch user ID
      const userId = await getUserMeta("_wooescrow_user_wallet_id");

      // Make the API request with the Authorization header
      const response = await axios.get(
        `http://api.spitout.com:8080/api/users-detail/${userId.meta_value}`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`, // Pass the access token as Bearer token
          },
        }
      );

      if (response.data && response.data.status === 200) {
        const walletData = response.data.data.wallet_addresses;

        // Set wallet addresses and network from API
        const addresses = walletData.map((wallet) => ({
          address: wallet.address,
          network: wallet.network,
        }));

        setWalletAddresses(addresses);
        setCurrency(addresses[0]?.network); // Default to the first network if available
        setWalletAddress(addresses[0]?.address); // Default to the first wallet address if available
      } else {
        console.error("Error fetching wallet data:", response.data.message);
        setLoading(false);
      }
    } catch (error) {
      console.error("Error fetching wallet data:", error);
      setLoading(false);
    }
  };

  const fetchBalance = async () => {
    if (!walletAddress || !provider) return;
    try {
      let balance;

      if (currency === "ETH") {
        balance = await provider.getBalance(walletAddress);
        const etherString = formatEther(balance);
        setBalance(`${etherString} ETH`);
      } else if (currency === "BTC") {
        const response = await axios.get(
          `https://api.blockcypher.com/v1/btc/main/addrs/${walletAddress}/balance`
        );
        balance = response.data.balance / 1e8;
        setBalance(`${balance} BTC`);
      } else if (currency === "SOL") {
        const response = await axios.post(rpcUrls.SOL, {
          jsonrpc: "2.0",
          id: 1,
          method: "getBalance",
          params: [walletAddress],
        });

        balance = response.data.result.value / 1e9;
        setBalance(`${balance} SOL`);
      }
    } catch (error) {
      console.error("Error fetching balance:", error);
      setBalance("Error fetching balance");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWalletData();
  }, []);

  useEffect(() => {
    if (currency) {
      setProvider(new JsonRpcProvider(rpcUrls[currency]));
    }
  }, [currency]);

  useEffect(() => {
    fetchBalance();
  }, [walletAddress, provider, currency]);

  useEffect(() => {
    const clipboard = new Clipboard("#wooescrow-copyButton", {
      text: () => walletAddress,
    });

    clipboard.on("success", () => {
      setCopyMessage("Copied!");
      // Hide wallet address on copy success
      setWalletAddress(""); // Temporarily hide the wallet address
      setTimeout(() => {
        setCopyMessage("");
        setWalletAddress(walletAddress); // Show wallet address again after message disappears
      }, 2000);
    });

    clipboard.on("error", (err) => {
      console.error("Failed to copy text:", err);
      alert("Failed to copy text");
    });

    return () => clipboard.destroy();
  }, [walletAddress]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target) &&
        !triggerRef.current.contains(event.target)
      ) {
        setDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleCurrencyChange = (newCurrency, address) => {
    setCurrency(newCurrency);
    setWalletAddress(address);
    setDropdownOpen(false);
  };

  const handleDepositClick = () => {
    setShowMoonPay(true); // Show the MoonPay widget
    setWidgetKey((prev) => prev + 1); // Increment key to re-mount the widget
  };

  const handleCloseMoonPay = () => {
    setShowMoonPay(false); // Hide the MoonPay widget
  };
  return (
    <div className="wooescrow-total-balance wooescrow-tab-container">
      <div className="wooescrow-total-balance-wrap">
        <div className="wooescrow-total-balance-left">
          <h5 className="wooescrow-title wooescrow-uppercase">Total Balance</h5>
          <span className="wooescrow-loading">
            {loading
              ? "Loading..."
              : balance.startsWith("Error")
              ? balance
              : null}
          </span>
          <span className="wooescrow-total-price">
            {!loading && !balance.startsWith("Error") ? balance : null}
          </span>
        </div>

        <div className="wooescrow-total-balance-right">
          <div className="wooescrow-custom-select-container">
            <div className="wooescrow-custom-select-wrapper" ref={dropdownRef}>
              <div
                className="wooescrow-custom-select"
                onClick={() => setDropdownOpen(!dropdownOpen)}
                ref={triggerRef}
                style={{
                  cursor: walletAddresses.length > 1 ? "pointer" : "default",
                }}
              >
                <div className="wooescrow-custom-select-trigger">
                  <img
                    src={`/wp-content/plugins/wooescrow/wooescrow-public/img/${currency.toLowerCase()}-small.png`}
                    alt={currency.toLowerCase()}
                  />{" "}
                  {currency}
                  {walletAddresses.length > 1 && (
                    <span className="wooescrow-icon">
                      <i className="fa-solid fa-chevron-down"></i>
                    </span>
                  )}
                </div>
                {dropdownOpen && walletAddresses.length > 1 && (
                  <div className="wooescrow-custom-options">
                    {walletAddresses.map(({ network, address }) => (
                      <div
                        key={network}
                        className={`wooescrow-custom-option ${
                          currency === network ? "selected" : ""
                        }`}
                        onClick={() => handleCurrencyChange(network, address)}
                      >
                        <img
                          src={`/wp-content/plugins/wooescrow/wooescrow-public/img/${network.toLowerCase()}-small.png`}
                          alt={network.toLowerCase()}
                        />{" "}
                        {network.toLowerCase()}
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <select id="wooescrow-original-select">
                {walletAddresses.map(({ network }) => (
                  <option key={network} value={network}>
                    {network.toLowerCase()}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="wooescrow-wallet-address wooescrow-center">
            <div className="wooescrow-copy-container wooescrow-justify-center">
              <span className="wooescrow-shortened-address">
                {loading ? "Loading..." : formatWalletAddress(walletAddress)}
              </span>
              <button
                id="wooescrow-copyButton"
                style={{ visibility: copyMessage ? "hidden" : "visible" }}
              >
                <i className="fa-regular fa-copy"></i>
              </button>
              {copyMessage && (
                <span className="copy-message">{copyMessage}</span>
              )}
            </div>
          </div>
        </div>
      </div>
      <div className="wooescrow-total-balance-button-wrap">
        <button
          id="wooescrow-deposit-button"
          className="wooescrow-button"
          onClick={handleDepositClick}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="21.691"
            height="21.69"
            viewBox="0 0 21.691 21.69"
          >
            <path
              id="bank"
              d="M21.689,20.785a.9.9,0,0,1-.9.9H.9a.9.9,0,1,1,0-1.807H20.785A.9.9,0,0,1,21.689,20.785ZM.263,7.728A2.208,2.208,0,0,1,.4,5.409,4.262,4.262,0,0,1,1.908,4.054L8.687.526A4.676,4.676,0,0,1,13,.526l6.778,3.531a4.262,4.262,0,0,1,1.507,1.356,2.208,2.208,0,0,1,.138,2.319,2.452,2.452,0,0,1-2.183,1.306h-.264v7.23h.9a.9.9,0,1,1,0,1.807H1.807a.9.9,0,1,1,0-1.807h.9V9.037H2.447A2.452,2.452,0,0,1,.263,7.728Zm4.256,8.538H7.229V9.037H4.518Zm4.519-7.23v7.23h3.615V9.037Zm8.133,0H14.459v7.23H17.17ZM1.864,6.891a.648.648,0,0,0,.583.339H19.241a.648.648,0,0,0,.583-.339.408.408,0,0,0-.022-.452,2.44,2.44,0,0,0-.858-.781L12.167,2.127a2.87,2.87,0,0,0-2.644,0L2.745,5.658a2.451,2.451,0,0,0-.858.782.408.408,0,0,0-.023.451Z"
              transform="translate(0.002 0.002)"
              fill="#fff"
            />
          </svg>
          <span className="wooescrow-button-text">Deposit</span>
        </button>
        {showMoonPay && (
          <MoonPay
            key={widgetKey} // Add key to force re-initialization
            onClose={handleCloseMoonPay}
          />
        )}
        {/* Render MoonPay component when toggled */}
        <button id="wooescrow-withdraw-button" className="wooescrow-button">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="19.699"
            height="19.708"
            viewBox="0 0 19.699 19.708"
          >
            <path
              id="money-from-bracket"
              d="M13.133,9.858A3.283,3.283,0,1,0,9.85,13.141,3.282,3.282,0,0,0,13.133,9.858ZM9.85,11.5a1.642,1.642,0,1,1,1.642-1.642A1.646,1.646,0,0,1,9.85,11.5ZM16.416,0H3.283A3.289,3.289,0,0,0,0,3.291v.821A3.288,3.288,0,0,0,3.283,7.4V15.6a4.106,4.106,0,0,0,4.1,4.1h4.925a4.106,4.106,0,0,0,4.1-4.1V7.4A3.282,3.282,0,0,0,19.7,4.112V3.291A3.289,3.289,0,0,0,16.416,0Zm1.642,4.1a1.646,1.646,0,0,1-1.642,1.642V4.1a.821.821,0,0,0-1.642,0V15.6a2.47,2.47,0,0,1-2.462,2.462H7.387A2.47,2.47,0,0,1,4.925,15.6V4.112a.821.821,0,0,0-1.642,0V5.754A1.646,1.646,0,0,1,1.642,4.112V3.291A1.646,1.646,0,0,1,3.283,1.65H16.416a1.646,1.646,0,0,1,1.642,1.642v.821Zm-4.1,11.9a1.231,1.231,0,1,1-1.231-1.231A1.23,1.23,0,0,1,13.954,16.006Zm-5.746,0a1.231,1.231,0,1,1-1.231-1.231A1.23,1.23,0,0,1,8.208,16.006Z"
              fill="#fff"
            />
          </svg>
          <span className="wooescrow-button-text">Withdraw</span>
        </button>
      </div>
    </div>
  );
};

export default Balance;
