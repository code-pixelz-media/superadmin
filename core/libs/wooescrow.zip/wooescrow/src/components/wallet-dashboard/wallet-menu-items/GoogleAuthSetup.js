import React, { useState, useEffect } from "react";
import { QRCodeSVG } from "qrcode.react";
import { authenticator } from "otplib";
import { updateUserMeta } from "../../wallet-includes/api";

const GoogleAuthSetup = ({ secret: initialSecret, onSecretUpdate }) => {
  const [secret, setSecret] = useState(initialSecret || "");
  const [qrCodeUrl, setQrCodeUrl] = useState("");
  const [setupComplete, setSetupComplete] = useState(false);
  const WooEscrowCryptoWalletRest = window.WooEscrowCryptoWalletRest || {};

  useEffect(() => {
    const initializeTotp = async () => {
      if (!initialSecret) {
        await generateNewTotpSecret();
      } else {
        await generateTotpQrCode(initialSecret);
      }
    };
    initializeTotp();
  }, [initialSecret]);

  const generateNewTotpSecret = async () => {
    try {
      const newSecret = authenticator.generateSecret();
      setSecret(newSecret);
      onSecretUpdate(newSecret); // Notify parent about the new secret

      await updateUserMeta({
        meta_key: "_wooescrow_user_totp_secret",
        meta_value: newSecret,
      });

      await generateTotpQrCode(newSecret);
    } catch (error) {
      console.error("Error generating new TOTP secret:", error);
    }
  };

  const generateTotpQrCode = async (secret) => {
    try {
      const response = await fetch(WooEscrowCryptoWalletRest.generate_totp, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-WP-Nonce": WooEscrowCryptoWalletRest.nonce,
        },
        body: JSON.stringify({
          secret_key: secret,
        }),
      });

      const data = await response.json();
      console.log(data);
      if (data.qr_code_url) {
        setQrCodeUrl(data.qr_code_url);
        setSecret(secret);
      } else {
        console.error("Failed to generate QR code URL.");
      }
    } catch (error) {
      console.error("Error generating QR code:", error);
    }
  };

  const resetGoogleAuth = () => {
    generateNewTotpSecret();
  };

  if (setupComplete) {
    return <div>Google Authenticator setup complete!</div>;
  }

  return (
    <div className="wooescrow-googleauth-setup">
      <h3 className="wooescrow-title">Set up Google Authenticator</h3>
      {qrCodeUrl && (
        <div className="wooescrow-google-auth-scan">
          <p className="wooescrow-text-para">
            Scan this QR code with your Google Authenticator app:
          </p>
          <QRCodeSVG value={qrCodeUrl} />
          <p className="wooescrow-text-para">
            Or manually enter this secret key in your authenticator app:{" "}
            <strong>{secret}</strong>
          </p>
        </div>
      )}
      <div className="wooescrow-privacy-security-btn">
        <button className="wooescrow-button" onClick={resetGoogleAuth}>
          Reset
        </button>
      </div>
    </div>
  );
};

export default GoogleAuthSetup;
