import React, { useState } from "react";
import SecurityLevel from "./SecurityLevel"; // Import the SecurityLevel component
import Switch from "react-switch"; // Importing the react-switch component

const Privacy = () => {
  const [showSecurityLevel, setShowSecurityLevel] = useState(false);
  const [loremIpsumEnabled, setLoremIpsumEnabled] = useState(false);
  const [hideTextEnabled, setHideTextEnabled] = useState(false);

  const handleToggleLoremIpsum = () => {
    setLoremIpsumEnabled(!loremIpsumEnabled);
  };

  const handleToggleHideText = () => {
    setHideTextEnabled(!hideTextEnabled);
  };

  const handleBack = () => {
    setShowSecurityLevel(false);
  };

  const handleSecurityLevelClick = () => {
    setShowSecurityLevel(true);
  };

  if (showSecurityLevel) {
    return <SecurityLevel onBack={handleBack} />;
  }

  return (
    <div className="wooescrow-setting-section">
      <div className="wooescrow-dashboard-privacy-section">
        <div className="wooescrow-privacy-options">
          <h2 className="wooescrow-title">Privacy Options</h2>
          <p className="wooescrow-privacy-options-subtitle wooescrow-text-para">
            Control what you share on Wooescrow
          </p>
        </div>

        <div className="wooescrow-privacy-toggle-option">
          <div className="wooescrow-privacy-toggle-header">
            <div>
              <h4 className="wooescrow-title">Lorem Ipsum</h4>
              <p className="wooescrow-privacy-toggle-subtitle wooescrow-text-para">
                Lorem ipsum dolor sit amet.
              </p>
            </div>
            <Switch
              onChange={handleToggleLoremIpsum}
              checked={loremIpsumEnabled}
              offColor="#b7bcc8"
              onColor="#0047fa"
              className="wooescrow-switch"
              height={35} // Set your desired height here
              width={55} // Set your desired width here
              handleDiameter={35}
            />
          </div>
        </div>

        <div className="wooescrow-privacy-toggle-option">
          <div className="wooescrow-privacy-toggle-header">
            <div>
              <h4 className="wooescrow-title">Hide Text</h4>
              <p className="wooescrow-privacy-toggle-subtitle wooescrow-text-para">
                Hide this from other users.
              </p>
            </div>
            <Switch
              onChange={handleToggleHideText}
              checked={hideTextEnabled}
              offColor="#b7bcc8"
              onColor="#0047fa"
              className="wooescrow-switch"
              height={35} // Set your desired height here
              width={55} // Set your desired width here
              handleDiameter={35}
            />
          </div>
        </div>
        <div
          className="wooescrow-privacy-option wooescrow-security-level"
          onClick={handleSecurityLevelClick}
        >
          <div className="wooescrow-privacy-header">
            <h4 className="wooescrow-title">Security Level</h4>
            <i className="fa-solid fa-chevron-right wooescrow-next-icon"></i>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Privacy;
