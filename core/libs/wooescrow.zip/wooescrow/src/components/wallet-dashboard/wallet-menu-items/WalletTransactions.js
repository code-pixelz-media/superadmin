// src/components/WalletTransactions.js
import React from "react";

const WalletTransactions = () => {
  return (
    <div className="wooescrow-my-assets-bottom-wrapper">
      <div className="wooescrow-tab-content-header">
        <p className="wooescrow-text-para wooescrow-uppercase">
          LATEST ACTIVITIES
        </p>
      </div>
      <div className="wooescrow-table-wrapper">
        <table
          id="wooescrow-latest-activities-table-full"
          className="wooescrow-table"
        >
          <thead>
            <tr>
              <th>#NUM</th>
              <th>Date</th>
              <th>Action</th>
              <th>Currency</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="wooescrow-td-num wooescrow-blue">#YK89</td>
              <td className="wooescrow-td-date">Apr 2 2024</td>
              <td className="wooescrow-td-action">
                <div className="wooescrow-td-action-wrap">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="21.691"
                    height="21.69"
                    viewBox="0 0 21.691 21.69"
                  >
                    <path
                      id="bank"
                      d="M21.689,20.785a.9.9,0,0,1-.9.9H.9a.9.9,0,1,1,0-1.807H20.785A.9.9,0,0,1,21.689,20.785ZM.263,7.728A2.208,2.208,0,0,1,.4,5.409,4.262,4.262,0,0,1,1.908,4.054L8.687.526A4.676,4.676,0,0,1,13,.526l6.778,3.531a4.262,4.262,0,0,1,1.507,1.356,2.208,2.208,0,0,1,.138,2.319,2.452,2.452,0,0,1-2.183,1.306h-.264v7.23h.9a.9.9,0,1,1,0,1.807H1.807a.9.9,0,1,1,0-1.807h.9V9.037H2.447A2.452,2.452,0,0,1,.263,7.728Zm4.256,8.538H7.229V9.037H4.518Zm4.519-7.23v7.23h3.615V9.037Zm8.133,0H14.459v7.23H17.17ZM1.864,6.891a.648.648,0,0,0,.583.339H19.241a.648.648,0,0,0,.583-.339.408.408,0,0,0-.022-.452,2.44,2.44,0,0,0-.858-.781L12.167,2.127a2.87,2.87,0,0,0-2.644,0L2.745,5.658a2.451,2.451,0,0,0-.858.782.408.408,0,0,0-.023.451Z"
                      transform="translate(0.002 0.002)"
                      fill="#2f323b"
                    />
                  </svg>
                  <span>Deposit</span>
                </div>
              </td>
              <td className="wooescrow-td-title-currency">
                <div className="wooescrow-td-currency-wrap">
                  <span className="wooescrow-td-image">
                    <img
                      src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                      alt="eth"
                    />
                  </span>
                  <div className="wooescrow-td-content">
                    <h5 className="wooescrow-td-name wooescrow-uppercase">
                      ETH
                    </h5>
                  </div>
                </div>
              </td>
              <td className="wooescrow-td-amount">0.000325 ETH</td>
              <td className="wooescrow-td-status">
                <span className="wooescrow-up wooescrow-up-bg">Completed</span>
              </td>
            </tr>
            <tr>
              <td className="wooescrow-td-num wooescrow-blue">#YK90</td>
              <td className="wooescrow-td-date">Apr 3 2024</td>
              <td className="wooescrow-td-action">
                <div className="wooescrow-td-action-wrap">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20.045"
                    height="18.324"
                    viewBox="0 0 20.045 18.324"
                  >
                    <path
                      id="plus-hexagon"
                      d="M19.433,8.064l-2.915-5A4.18,4.18,0,0,0,12.921,1H7.032a4.179,4.179,0,0,0-3.6,2.067l-2.916,5a4.176,4.176,0,0,0,0,4.2l2.916,5a4.178,4.178,0,0,0,3.6,2.066H12.92a4.18,4.18,0,0,0,3.6-2.066l2.915-5a4.176,4.176,0,0,0,0-4.2Zm-1.44,3.358-2.915,5a2.508,2.508,0,0,1-2.159,1.239H7.032A2.507,2.507,0,0,1,4.873,16.42l-2.915-5a2.5,2.5,0,0,1,0-2.519l2.915-5a2.507,2.507,0,0,1,2.158-1.24H12.92a2.506,2.506,0,0,1,2.158,1.24l2.915,5A2.5,2.5,0,0,1,17.993,11.422Zm-3.841-1.259a.833.833,0,0,1-.833.833h-2.5v2.5a.833.833,0,1,1-1.666,0V11h-2.5a.833.833,0,1,1,0-1.666h2.5v-2.5a.833.833,0,1,1,1.666,0v2.5h2.5A.833.833,0,0,1,14.152,10.163Z"
                      transform="translate(0.047 -1)"
                      fill="#2F323B"
                    />
                  </svg>{" "}
                  <span>Buy</span>
                </div>
              </td>
              <td className="wooescrow-td-title-currency">
                <div className="wooescrow-td-currency-wrap">
                  <span className="wooescrow-td-image">
                    <img
                      src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                      alt="eth"
                    />
                  </span>
                  <div className="wooescrow-td-content">
                    <h5 className="wooescrow-td-name wooescrow-uppercase">
                      ETH
                    </h5>
                  </div>
                </div>
              </td>
              <td className="wooescrow-td-amount">0.000325 ETH</td>
              <td className="wooescrow-td-status">
                <span className="wooescrow-down wooescrow-down-bg">
                  Rejected
                </span>
              </td>
            </tr>
            <tr>
              <td className="wooescrow-td-num wooescrow-blue">#YK91</td>
              <td className="wooescrow-td-date">Apr 4 2024</td>
              <td className="wooescrow-td-action">
                <div className="wooescrow-td-action-wrap">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="19.699"
                    height="19.708"
                    viewBox="0 0 19.699 19.708"
                  >
                    <path
                      id="money-from-bracket"
                      d="M13.133,9.858A3.283,3.283,0,1,0,9.85,13.141,3.282,3.282,0,0,0,13.133,9.858ZM9.85,11.5a1.642,1.642,0,1,1,1.642-1.642A1.646,1.646,0,0,1,9.85,11.5ZM16.416,0H3.283A3.289,3.289,0,0,0,0,3.291v.821A3.288,3.288,0,0,0,3.283,7.4V15.6a4.106,4.106,0,0,0,4.1,4.1h4.925a4.106,4.106,0,0,0,4.1-4.1V7.4A3.282,3.282,0,0,0,19.7,4.112V3.291A3.289,3.289,0,0,0,16.416,0Zm1.642,4.1a1.646,1.646,0,0,1-1.642,1.642V4.1a.821.821,0,0,0-1.642,0V15.6a2.47,2.47,0,0,1-2.462,2.462H7.387A2.47,2.47,0,0,1,4.925,15.6V4.112a.821.821,0,0,0-1.642,0V5.754A1.646,1.646,0,0,1,1.642,4.112V3.291A1.646,1.646,0,0,1,3.283,1.65H16.416a1.646,1.646,0,0,1,1.642,1.642v.821Zm-4.1,11.9a1.231,1.231,0,1,1-1.231-1.231A1.23,1.23,0,0,1,13.954,16.006Zm-5.746,0a1.231,1.231,0,1,1-1.231-1.231A1.23,1.23,0,0,1,8.208,16.006Z"
                      fill="#2F323B"
                    />
                  </svg>{" "}
                  <span>Withdraw</span>
                </div>
              </td>
              <td className="wooescrow-td-title-currency">
                <div className="wooescrow-td-currency-wrap">
                  <span className="wooescrow-td-image">
                    <img
                      src="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png"
                      alt="btc"
                    />
                    <img
                      src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                      alt="eth"
                    />
                  </span>
                  <div className="wooescrow-td-content">
                    <h5 className="wooescrow-td-name wooescrow-uppercase">
                      ETH
                    </h5>
                  </div>
                </div>
              </td>
              <td className="wooescrow-td-amount">0,76 BTC - 0,000325 ETH</td>
              <td className="wooescrow-td-status">
                <span className="wooescrow-up wooescrow-up-bg">Completed</span>
              </td>
            </tr>
            <tr>
              <td className="wooescrow-td-num wooescrow-blue">#YK89</td>
              <td className="wooescrow-td-date">Apr 2 2024</td>
              <td className="wooescrow-td-action">
                <div className="wooescrow-td-action-wrap">
                  <svg
                    id="refresh"
                    xmlns="http://www.w3.org/2000/svg"
                    width="21.12"
                    height="21.201"
                    viewBox="0 0 21.12 21.201"
                  >
                    <path
                      id="Tracciato_22"
                      data-name="Tracciato 22"
                      d="M10.606,1.767A8.862,8.862,0,0,1,16.9,4.417H14.139a.883.883,0,0,0-.883.883h0a.883.883,0,0,0,.883.883H17.8a1.641,1.641,0,0,0,1.64-1.64V.883A.883.883,0,0,0,18.556,0h0a.883.883,0,0,0-.883.883V2.719A10.584,10.584,0,0,0,.049,9.628a.89.89,0,0,0,.883.972h0a.867.867,0,0,0,.874-.776,8.846,8.846,0,0,1,8.8-8.058Z"
                      transform="translate(-0.046 0.001)"
                      fill="#2f323b"
                    />
                    <path
                      id="Tracciato_23"
                      data-name="Tracciato 23"
                      d="M20.507,12a.867.867,0,0,0-.874.776A8.821,8.821,0,0,1,4.542,18.183H7.3a.883.883,0,0,0,.883-.883h0a.883.883,0,0,0-.883-.883H3.64A1.64,1.64,0,0,0,2,18.057v3.66a.883.883,0,0,0,.883.883h0a.883.883,0,0,0,.883-.883V19.881a10.584,10.584,0,0,0,17.623-6.91A.89.89,0,0,0,20.506,12Z"
                      transform="translate(-0.274 -1.399)"
                      fill="#2f323b"
                    />
                  </svg>
                  <span>Exchange</span>
                </div>
              </td>
              <td className="wooescrow-td-title-currency">
                <div className="wooescrow-td-currency-wrap wooescrow-td-multi-currency-wrap">
                  <span className="wooescrow-td-image">
                    <img
                      src="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png"
                      alt="btc"
                    />
                    <img
                      src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                      alt="eth"
                    />
                  </span>
                  <div className="wooescrow-td-content">
                    <h5 className="wooescrow-td-name wooescrow-uppercase">
                      eth
                    </h5>
                  </div>
                </div>
              </td>
              <td className="wooescrow-td-amount">0,76 BTC - 0,000325 ETH</td>
              <td className="wooescrow-td-status">
                <span className="wooescrow-pending wooescrow-pending-bg">
                  Pending
                </span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default WalletTransactions;
