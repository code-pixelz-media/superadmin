import React, { useState, useEffect } from "react";
import Clipboard from "clipboard";
import { getUserMeta } from "../../wallet-includes/api"; // Adjust import as needed

const AddWalletDetails = ({ selectedCurrency, walletData, onBack }) => {
  const [copyMessage, setCopyMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  // Function to handle API request
  const handleAddWallet = async () => {
    try {
      // Fetch user ID from meta and ensure it's a number
      const userMeta = await getUserMeta("_wooescrow_user_wallet_id");
      const userId = Number(userMeta.meta_value);

      // Prepare data for API request
      const data = {
        address: walletData.address,
        network: selectedCurrency,
        user_id: userId,
      };

      console.log(data);

      // Send API request
      const response = await fetch(
        "http://api.spitout.com:8080/add-wallet-address",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        }
      );

      const result = await response.json();

      if (response.ok) {
        setSuccessMessage("Wallet added successfully!");
        setErrorMessage("");
      } else {
        setErrorMessage(result.message || "Failed to add wallet.");
        setSuccessMessage("");
      }
    } catch (error) {
      console.error("Error adding wallet:", error);
      setErrorMessage("An error occurred. Please try again.");
      setSuccessMessage("");
    }
  };

  // Initialize Clipboard.js for copying private key
  useEffect(() => {
    const clipboard = new Clipboard("#copy-private-key-button", {
      text: () => walletData.privateKey,
    });

    clipboard.on("success", () => {
      setCopyMessage("Private key copied!");
      setTimeout(() => setCopyMessage(""), 2000);
    });

    clipboard.on("error", (err) => {
      console.error("Failed to copy text:", err);
      alert("Failed to copy text");
    });

    return () => clipboard.destroy(); // Clean up Clipboard.js instance
  }, [walletData.privateKey]);

  if (!walletData) {
    return <div>Loading...</div>;
  }

  return (
    <div className="wooescrow-add-wallet-details">
      <div className="wooescrow-header-wrapper">
        <h1 className="wooescrow-title">Wallet Details</h1>
      </div>
      <div className="wooescrow-wallet-details-content">
        <p className="wooescrow-text-para">
          <strong>Currency:</strong> {selectedCurrency}
        </p>
        <p className="wooescrow-text-para">
          <strong>Address:</strong> {walletData.address}
        </p>
        <p className="wooescrow-text-para">
          <strong>Private Key:</strong> {walletData.privateKey}
        </p>
      </div>
      <button id="copy-private-key-button" className="wooescrow-button">
        Copy
      </button>
      {copyMessage && <span className="copy-message">{copyMessage}</span>}
      <button
        onClick={handleAddWallet}
        className="next-button wooescrow-button"
      >
        Add Wallet
      </button>
      {successMessage && (
        <div className="wooescrow-success-message">{successMessage}</div>
      )}
      {errorMessage && (
        <p className="wooescrow-error-message">{errorMessage}</p>
      )}
    </div>
  );
};

export default AddWalletDetails;
