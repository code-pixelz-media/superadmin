import React, { useState, useEffect } from "react";
import { updateUserMeta, getUserMeta } from "../../wallet-includes/api";
import BackButton from "../../wallet-includes/BackButton";
import GoogleAuthSetup from "./GoogleAuthSetup";
import SmsAuthSetup from "./SmsAuthSetup";
import Modal from "../../wallet-includes/Modal";

const SecurityLevel = ({ onBack }) => {
  const WooEscrowCryptoWalletRest = window.WooEscrowCryptoWalletRest || {};
  const [currentAuth, setCurrentAuth] = useState("");
  const [googleAuthSecret, setGoogleAuthSecret] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [showGoogleAuthSetup, setShowGoogleAuthSetup] = useState(false);
  const [showSmsAuthSetup, setShowSmsAuthSetup] = useState(false);
  const [allAuthenticators, setAllAuthenticators] = useState([
    {
      key: "no-security",
      enabled: false,
      title: "No Security",
      icon: "/wp-content/plugins/wooescrow/wooescrow-public/img/shield-slash.svg",
    },
    {
      key: "sms-code",
      enabled: false,
      title: "SMS Code",
      icon: "/wp-content/plugins/wooescrow/wooescrow-public/img/password-smartphone.svg",
    },
    {
      key: "google-auth",
      enabled: false,
      title: "Google Auth",
      icon: "/wp-content/plugins/wooescrow/wooescrow-public/img/Google_Authenticator_(April_2023).svg",
    },
    {
      key: "multi-sig",
      enabled: false,
      title: "Multisig",
      icon: "/wp-content/plugins/wooescrow/wooescrow-public/img/key-skeleton-left-right.svg",
    },
  ]);

  const [isFirstLoad, setIsFirstLoad] = useState(true);

  useEffect(() => {
    checkUserMeta();
  }, []);

  const checkUserMeta = async () => {
    try {
      const response = await getUserMeta("_wooescrow_user_enabled_auth");
      if (response.meta_value === "") {
        handleAuthenticatorsClick("no-security");
        setCurrentAuth("no-security");
      } else {
        handleAuthenticatorsClick(response.meta_value);
      }

      const googleSecretResponse = await getUserMeta(
        "_wooescrow_user_totp_secret"
      );
      if (googleSecretResponse.meta_value) {
        setGoogleAuthSecret(googleSecretResponse.meta_value);
      }

      const phoneNumberResponse = await getUserMeta(
        "_wooescrow_user_phone_number"
      );
      if (phoneNumberResponse.meta_value) {
        setPhoneNumber(phoneNumberResponse.meta_value);
        console.log(phoneNumberResponse);
      }
    } catch (error) {
      console.error("Error fetching user meta:", error);
    }
  };

  const updateAuthToUserMeta = async (authKey) => {
    const metaData = {
      meta_key: "_wooescrow_user_enabled_auth",
      meta_value: authKey,
    };
    await updateUserMeta(metaData);
    console.log("Updating " + authKey);
  };

  const authenticatorElement = (authenticator) => {
    const commonAttr = "wooescrow-" + authenticator.key;
    const innerContainer = commonAttr + "-radio-box";
    return (
      <label
        key={authenticator.key}
        className="wooescrow-security-level-card wooescrow-security-level-radio-box-group"
      >
        <input
          type="radio"
          id={commonAttr}
          name="wooescrow-security-level-radio-btn"
          className="wooescrow-security-level-radio-btn"
        />
        <div
          id={innerContainer}
          className="wooescrow-security-level-radio-box"
          onClick={() => handleAuthenticatorsClick(authenticator.key)}
          style={{
            border:
              "2px solid " + (authenticator.enabled ? "#31bd65" : "#ebeef1"),
          }}
        >
          <div className="wooescrow-security-level-img-container">
            <img src={authenticator.icon} alt={authenticator.title} />
          </div>
          <div className="wooescrow-security-level-card-body">
            <span className="wooescrow-card-text">{authenticator.title}</span>
          </div>
        </div>
      </label>
    );
  };

  const handleAuthenticatorsClick = (key) => {
    setAllAuthenticators((prevAuthenticators) =>
      prevAuthenticators.map((authenticator) =>
        authenticator.key === key
          ? { ...authenticator, enabled: true }
          : { ...authenticator, enabled: false }
      )
    );

    setShowGoogleAuthSetup(false);
    setShowSmsAuthSetup(false);

    if (key === "google-auth" && !isFirstLoad) {
      setShowGoogleAuthSetup(true);
    }

    if (key === "sms-code" && !isFirstLoad) {
      setShowSmsAuthSetup(true);
    }

    setIsFirstLoad(false);
  };

  const saveAuthenticatorData = () => {
    allAuthenticators.forEach((authenticator) => {
      if (authenticator.enabled) {
        setCurrentAuth(authenticator.key);
        updateAuthToUserMeta(authenticator.key);
      }
    });
    setShowGoogleAuthSetup(false);
    setShowSmsAuthSetup(false);
  };

  const handleGoogleAuthComplete = () => {
    setShowGoogleAuthSetup(false);
    checkUserMeta();
  };

  const handleSmsAuthComplete = () => {
    setShowSmsAuthSetup(true);
    checkUserMeta();
  };

  const handleSecretUpdate = (newSecret) => {
    setGoogleAuthSecret(newSecret);
  };

  const handlePhoneUpdate = (newPhone) => {
    setPhoneNumber(newPhone);
  };

  return (
    <div className="wooescrow-security-level-section">
      <div className="wooescrow-security-level-wrapper">
        <div className="wooescrow-container">
          <div className="wooescrow-header-wrapper">
            <div className="wooescrow-security-level-text">
              <BackButton onBack={onBack} />
            </div>
            <div className="wooescrow-header">
              <h1 className="wooescrow-title">Security Level</h1>
            </div>
          </div>
          <div className="wooescrow-security-level-content-wrapper">
            <div
              className="wooescrow-security-level-radio-group"
              style={{ cursor: "pointer" }}
            >
              {allAuthenticators.map((authenticator) =>
                authenticatorElement(authenticator)
              )}
            </div>
            <div className="wooescrow-security-confirm-btn wooescrow-end">
              <button
                id="wooescrow-secuity-confirm-button"
                className="wooescrow-button"
                onClick={() => saveAuthenticatorData()}
              >
                Confirm
                <span className="wooescrow-fa-icon">
                  <i className="fa-solid fa-arrow-right-long"></i>
                </span>
              </button>
            </div>

            {/* Google Authenticator setup modal */}
            <Modal
              show={showGoogleAuthSetup}
              onClose={() => setShowGoogleAuthSetup(false)}
            >
              <GoogleAuthSetup
                secret={googleAuthSecret}
                onComplete={handleGoogleAuthComplete}
                onSecretUpdate={handleSecretUpdate}
              />
            </Modal>

            {/* SMS Authentication setup modal */}
            <Modal
              show={showSmsAuthSetup}
              onClose={() => setShowSmsAuthSetup(false)}
            >
              <SmsAuthSetup
                phone={phoneNumber}
                onComplete={handleSmsAuthComplete}
                onPhoneUpdate={handlePhoneUpdate}
              />
            </Modal>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityLevel;
