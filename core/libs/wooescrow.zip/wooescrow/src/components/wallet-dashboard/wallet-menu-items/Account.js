import React, { useEffect, useState } from "react";
import { getUserMeta } from "../../wallet-includes/api";
import AddWallet from "./AddWallet"; // Import the AddWallet component
import axios from "axios";

const Account = () => {
  const [accountDetails, setAccountDetails] = useState({
    walletId: "",
    walletAddresses: [], // Multiple wallet addresses from external API
  });

  const [isAddingWallet, setIsAddingWallet] = useState(false); // State to toggle between Account and Add Wallet UI

  // Function to fetch and update account details
  const fetchMetaKeys = async () => {
    try {
      const walletId = await getUserMeta("_wooescrow_user_wallet_id");
      const accessToken = localStorage.getItem("accessToken");

      // Fetch user wallet data from external API

      const response = await axios.get(
        `http://api.spitout.com:8080/api/users-detail/${walletId.meta_value}`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`, // Pass the access token as Bearer token
          },
        }
      );

      if (response.data && response.data.status === 200) {
        const walletData = response.data.data.wallet_addresses;

        setAccountDetails({
          walletId: walletId.meta_value,
          walletAddresses: walletData, // Set wallet addresses array
        });
      } else {
        console.error(
          "Error fetching wallet data from API:",
          response.data.message
        );
      }
    } catch (error) {
      console.error("Error fetching user meta keys or wallet data:", error);
    }
  };

  useEffect(() => {
    fetchMetaKeys();
  }, []);

  const handleAddNewWallet = () => {
    // Toggle to add wallet UI
    setIsAddingWallet(true);
  };

  const handleBack = () => {
    setIsAddingWallet(false); // Go back to Account component
  };

  if (isAddingWallet) {
    return <AddWallet onBack={handleBack} />; // Pass handleBack to AddWallet
  }

  return (
    <div className="wooescrow-setting-section">
      {isAddingWallet ? (
        <AddWallet /> // Render AddWallet UI if isAddingWallet is true
      ) : (
        <div className="wooescrow-dashboard-account-section">
          <h2 className="wooescrow-title">Account</h2>
          <div className="wooescrow-account-details">
            <div className="wooescrow-account-row">
              <span className="wooescrow-account-label">Wallet ID:</span>
              <span className="wooescrow-account-data">
                {accountDetails.walletId}
              </span>
            </div>

            {/* Display wallet networks and addresses */}
            {accountDetails.walletAddresses.length > 0 ? (
              accountDetails.walletAddresses.map((wallet, index) => (
                <div key={index} className="wooescrow-account-row">
                  <span className="wooescrow-account-label">
                    {wallet.network} Address:
                  </span>
                  <span className="wooescrow-account-data">
                    {wallet.address}
                  </span>
                </div>
              ))
            ) : (
              <div className="wooescrow-account-row">
                <span className="wooescrow-account-label">
                  No wallets available.
                </span>
              </div>
            )}
          </div>
          <div className="wooescrow-account-create">
            <button className="wooescrow-button" onClick={handleAddNewWallet}>
              Add New Wallet
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Account;
