import React, { useState } from "react";
import classNames from "classnames";
import Account from "./Account";
import Notifications from "./Notifications";
import PaymentMethods from "./PaymentMethods";
import Limit from "./Limit";
import Privacy from "./Privacy";
import Logout from "./Logout";

const sidebarMenuItems = [
  { name: "account", label: "Account", component: Account },
  { name: "notifications", label: "Notifications", component: Notifications },
  {
    name: "payment-methods",
    label: "Payment Methods",
    component: PaymentMethods,
  },
  { name: "limit", label: "Limit", component: Limit },
  { name: "privacy", label: "Privacy", component: Privacy },
  { name: "logout", label: "Logout", component: Logout },
];

const Settings = () => {
  const [activeSection, setActiveMenu] = useState("account");

  const renderSettingsSection = () => {
    const activeItem = sidebarMenuItems.find(
      (item) => item.name === activeSection
    );
    const ActiveComponent = activeItem?.component || Account;
    return <ActiveComponent />;
  };

  return (
    <>
      <div className="wooescrow-dashboard-sidebar">
        <ul className="wooescrow-dashboard-menu">
          {sidebarMenuItems.map((item) => (
            <li
              key={item.name}
              className={classNames(
                "wooescrow-menu-item",
                `wooescrow-menu-${item.name}`,
                { active: activeSection === item.name }
              )}
              onClick={() => setActiveMenu(item.name)}
            >
              <img
                src={`/wp-content/plugins/wooescrow/wooescrow-public/img/${item.name}.svg`}
                alt={item.name}
              />
              {item.label}
            </li>
          ))}
        </ul>
      </div>
      <div className="wooescrow-dashboard-content">
        {/* Render the appropriate section based on activeSection */}
        {renderSettingsSection()}
      </div>
    </>
  );
};

export default Settings;
