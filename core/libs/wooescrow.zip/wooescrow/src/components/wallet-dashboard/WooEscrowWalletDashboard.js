import React, { useState } from "react";
import WalletMenu from "./wallet-menu-items/wallet-dashboard-menus/WalletMenu";
import Overview from "./wallet-menu-items/Overview";
import MyAssets from "./wallet-menu-items/MyAssets";
import Exchange from "./wallet-menu-items/Exchange";
import Settings from "./wallet-menu-items/Settings";

const WooEscrowWalletDashboard = () => {
  const [activeMenu, setActiveMenu] = useState("overview");

  const renderMenuContent = () => {
    switch (activeMenu) {
      case "overview":
        return <Overview />;
      case "my-assets":
        return <MyAssets />;
      case "exchange":
        return <Exchange />;
      case "settings":
        return <Settings />;
      default:
        return <Overview />;
    }
  };

  return (
    <div className="wooescrow-wallet-dashboard">
      <WalletMenu activeMenu={activeMenu} setActiveMenu={setActiveMenu} />
      <div className="wooescrow-dashboard-container">{renderMenuContent()}</div>
    </div>
  );
};

export default WooEscrowWalletDashboard;
