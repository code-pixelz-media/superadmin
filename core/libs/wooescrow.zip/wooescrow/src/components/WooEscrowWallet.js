import React, { useState, useEffect } from "react";
import CreateWallet from "./create-wallet/CreateWallet";
import ImportWallet from "./import-wallet/ImportWallet";
import WooEscrowInitialSetupUI from "./WooEscrowInitialSetupUI";
import WalletLoginForm from "./wallet-includes/WalletLoginForm";
import WooEscrowWalletDashboard from "./wallet-dashboard/WooEscrowWalletDashboard";
import jwt from "jsonwebtoken";
import {
  createWallet,
  updateUserMeta,
  getUserMeta,
  sendOtp,
  verifyOtp,
} from "./wallet-includes/api";
import TwoFactorAuth from "./wallet-includes/TwoFactorAuth";
import { authenticator } from "otplib";

const WooEscrowCryptoWalletRest = window.WooEscrowCryptoWalletRest || {};
const userEmail = WooEscrowCryptoWalletRest.user_email;

const WooEscrowWalletMainComponent = () => {
  const [userStatus, setUserStatus] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [walletCreated, setWalletCreated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [apiFailed, setApiFailed] = useState(false); // New state to track API status
  const [showImportWallet, setShowImportWallet] = useState(false);
  const [showCreateWallet, setShowCreateWallet] = useState(false);
  const [showWalletLoginForm, setShowWalletLoginForm] = useState(false);
  const [dashboardVisible, setDashboardVisible] = useState(false);
  const [walletCreationStatus, setWalletCreationStatus] = useState({
    mnemonic: "",
    address: "",
    publicKey: "",
    privateKey: "",
    currency: "",
  });

  const [otpVerified, setOtpVerified] = useState(false);
  const [showOtpInput, setShowOtpInput] = useState(false);
  const [authType, setAuthType] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("+9779849158973");

  const handleSuccessfulOtpVerification = () => {
    localStorage.setItem("walletUserID", userStatus.ID);
    localStorage.setItem("walletLoggedIn", "true");
    localStorage.setItem("otpVerified", "true");
    setOtpVerified(true);
    setDashboardVisible(true);
    setShowWalletLoginForm(false);
  };

  const onOtpSubmit = async (inputOtp) => {
    try {
      // Handle Google Authenticator OTP
      if (authType === "google-auth") {
        const metaKey = "_wooescrow_user_totp_secret";
        const response = await getUserMeta(metaKey);
        console.log(response);
        if (response.meta_value) {
          authenticator.options = {
            step: 30,
            window: 2,
          };
          const isValid = authenticator.check(inputOtp, response.meta_value);
          // console.log("Input OTP:", inputOtp);
          // console.log("Secret (meta_value):", response.meta_value);
          // console.log("Is Valid OTP:", isValid);

          if (isValid) {
            handleSuccessfulOtpVerification();
          } else {
            alert("Incorrect Google Authenticator OTP. Please try again.");
          }
        } else {
          alert("No OTP secret found. Please try again.");
        }
      }
      // Handle hardcoded OTP for other 2FA types (e.g., SMS, email)
      else if (authType === "sms-code" || authType === "email-otp") {
        const result = await verifyOtp(inputOtp, phoneNumber);
        if (result.success) {
          alert("verified");
          handleSuccessfulOtpVerification();
        } else {
          alert("Incorrect OTP. Please try again.");
        }
      } else {
        alert("Unknown 2FA method. Please try again.");
      }
    } catch (error) {
      console.error("OTP Verification Error:", error);
    }
  };

  const [errorMessage, setErrorMessage] = useState(""); // Add error message state

  useEffect(() => {
    const checkUserStatus = async () => {
      try {
        const apiUrl = `http://api.spitout.com:8080/users-detail-by-email/${userEmail}`;

        const userResponse = await fetch(apiUrl, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        if (!userResponse.ok) {
          throw new Error("Failed to fetch user data");
        } else {
          const userData = await userResponse.json();
          console.log(userData, userEmail);

          if (userData.data && userData.data.id) {
            setUserStatus(userData.data);
            setIsLoggedIn(true);
            setWalletCreated(true); // User has a wallet, show login form
            setShowWalletLoginForm(true);
          } else {
            setWalletCreated(false); // No wallet found, show create wallet form
          }
        }
      } catch (error) {
        console.error("Error fetching user status:", error);
        //setApiFailed(true); // Set API failed state
        setIsLoggedIn(true);
        setUserStatus({ isLoggedIn: false, email: "" });
      } finally {
        setLoading(false);
      }
    };

    checkUserStatus();
  }, []);

  const handleCreateWallet = () => {
    setShowCreateWallet(true);
  };

  const handleImportWallet = () => {
    setShowImportWallet(true);
  };

  const handleBackFromImportWallet = () => {
    setShowImportWallet(false);
  };

  const handleBackFromCreateWallet = () => {
    setShowCreateWallet(false);
  };

  const handleMnemonicGenerated = (mnemonic, walletData) => {
    setWalletCreationStatus({
      mnemonic,
      address: walletData.address,
      publicKey: walletData.publicKey,
      privateKey: walletData.privateKey,
      currency: walletData.currency,
    });
    setShowCreateWallet(true);
  };

  const handleWalletLogin = async (password) => {
    try {
      const email = userStatus?.email;

      console.log(email);

      if (!email) {
        throw new Error("User email not found.");
      }

      const response = await fetch("http://api.spitout.com:8080/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email,
          password: password,
        }),
      });

      if (!response.ok) {
        throw new Error("Login failed. Please check your email and password.");
      }

      const data = await response.json();
      console.log(data);

      const { access_token } = data.data; // Extract access token from

      if (access_token) {
        // Verify the token (if needed, depending on your security requirements)
        // If you're doing this on the frontend, make sure you don't expose your secret key
        // const decoded = jwt.decode(access_token); // Decode without verification (frontend only)

        // For security, token verification should be done on the backend
        // Example: await fetch("http://api.yourbackend.com/verify", { method: "POST", headers: { "Authorization": `Bearer ${access_token}` } });

        // Store the token and user ID in localStorage
        localStorage.setItem("accessToken", access_token); // Save the access token
        localStorage.setItem("walletID", data.id); // Store user ID
        // localStorage.setItem("walletLoggedIn", "true");

        try {
          const authResponse = await getUserMeta(
            "_wooescrow_user_enabled_auth"
          );
          const preferredAuth = authResponse.meta_value;
          if (
            !preferredAuth ||
            preferredAuth === "no-security" ||
            preferredAuth === "multi-sig"
          ) {
            // Proceed to dashboard directly if no 2FA or multi-sig
            localStorage.setItem("walletUserID", userStatus.ID);
            localStorage.setItem("walletLoggedIn", "true");
            setDashboardVisible(true);
            setShowWalletLoginForm(false);
          } else {
            setAuthType(preferredAuth);
            setShowOtpInput(true);

            if (preferredAuth == "sms-code") {
              const sendOtps = await sendOtp(phoneNumber);
              if (sendOtps.success) {
                alert("otp send");
              } else {
                alert("cannot send otp");
              }
            }
          }
        } catch (error) {
          console.error("Error fetching user 2FA meta:", error);
          alert("Failed to fetch 2FA settings. Please try again.");
        }

        // Show the dashboard
        // setDashboardVisible(true);
        setErrorMessage(""); // Clear any error message on success
      } else {
        setErrorMessage("Login failed. Please try again.");
      }
    } catch (error) {
      console.error("Failed to login with wallet:", error);
      setErrorMessage(error.message || "An error occurred during login.");
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  // if (apiFailed) {
  //   return (
  //     <div className="wooescrow-error">
  //       <h3 className="wooescrow-title">
  //         We are currently experiencing issues loading your data.
  //       </h3>
  //       <p className="wooescrow-text-para">
  //         Please try refreshing the page. If the problem persists, it might be a
  //         temporary server issue. You can try again later or contact our support
  //         team for assistance.
  //       </p>
  //     </div>
  //   );
  // }

  if (!isLoggedIn) {
    return (
      <div className="wooescrow-wallet-container-cw">
        <div className="wooescrow-wallet-popup-wrapper cw-without-popup">
          <div
            className="wooescrow-wallet-popup-container"
            id="cw-not-logged-in"
          >
            <div className="wooescrow-wallet-popup">
              <div className="wooescrow-wallet-popup-content">
                <div className="wooescrow-wallet-popup-content-inner">
                  <h3>Please log in to access your wallet</h3>
                  <button
                    className="wooescrow-wallet-btn-login"
                    id="wc-crypto-login"
                  >
                    Login
                    <i className="fa-solid fa-arrow-right"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (showOtpInput && !otpVerified) {
    return <TwoFactorAuth authType={authType} onOtpSubmit={onOtpSubmit} />;
  }

  if (dashboardVisible) {
    return (
      <div className="wooescrow-section">
        <WooEscrowWalletDashboard />
      </div>
    );
  }

  if (walletCreated && showWalletLoginForm) {
    return (
      <div className="wooescrow-section">
        <div className="wooescrow-wrapper">
          <WalletLoginForm
            userEmail={userStatus.email}
            walletData={walletCreationStatus}
            onWalletLoginSubmit={handleWalletLogin}
          />
          {errorMessage && (
            <p className="wooescrow-error wooescrow-text-para">
              {errorMessage}
            </p>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="wooescrow-section">
      <div className="wooescrow-wrapper">
        {!showCreateWallet && !showImportWallet ? (
          <WooEscrowInitialSetupUI
            onCreateWallet={handleCreateWallet}
            onImportWallet={handleImportWallet}
            walletCreated={walletCreated}
          />
        ) : showImportWallet ? (
          <ImportWallet
            onBack={handleBackFromImportWallet}
            userEmail={userStatus.email}
          />
        ) : showCreateWallet ? (
          <CreateWallet
            userStatus={userStatus}
            onBack={handleBackFromCreateWallet}
            onMnemonicGenerated={handleMnemonicGenerated}
          />
        ) : null}
      </div>
    </div>
  );
};

export default WooEscrowWalletMainComponent;
