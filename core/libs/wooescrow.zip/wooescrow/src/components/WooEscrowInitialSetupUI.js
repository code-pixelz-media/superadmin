import React from "react";

const WooEscrowInitialSetupUI = ({ onCreateWallet, onImportWallet }) => {
  return (
    <div className="wooescrow-setup-section">
      <div className="wooescrow-setup-wrapper">
        <div className="wooescrow-container">
          <div className="wooescrow-header-wrapper">
            <div className="wooescrow-setup-text">
              <p className="wooescrow-text-para wooescrow-blue">
                Set up Woo Escrow
              </p>
            </div>
            <div className="wooescrow-header">
              <h1 className="wooescrow-title">
                Create new Wallet or import an existing wallet
              </h1>
            </div>
          </div>
          <div className="wooescrow-setup-content-wrapper">
            <button
              type="button"
              className="wooescrow-button wooescrow-create-new-wallet-button"
              onClick={onCreateWallet}
            >
              <img
                src="/wp-content/plugins/wooescrow/wooescrow-public/img/Raggruppa-2552.svg"
                alt="create wallet"
              />
              <span className="wooescrow-button-text">Create new wallet</span>
            </button>
            <button
              type="button"
              className="wooescrow-button wooescrow-create-import-wallet-button"
              onClick={onImportWallet}
            >
              <img
                src="/wp-content/plugins/wooescrow/wooescrow-public/img/Raggruppa-2497.svg"
                alt="import wallet"
              />
              <span className="wooescrow-button-text">Import Wallet</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WooEscrowInitialSetupUI;
