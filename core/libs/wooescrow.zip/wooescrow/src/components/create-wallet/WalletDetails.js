import React, { useEffect } from "react";
import Clipboard from "clipboard";
import PasswordForm from "../wallet-includes/PasswordForm";

const WalletDetails = ({
  selectedCurrency,
  address,
  privateKey,
  copyMessage,
  privateKeyCopied,
  showPasswordForm,
  setShowPasswordForm,
  handlePasswordSubmit,
  setCopyMessage,
  setPrivateKeyCopied,
}) => {
  useEffect(() => {
    // Initialize Clipboard.js for copying private key
    const clipboard = new Clipboard("#copy-private-key-button", {
      text: () => privateKey,
    });

    clipboard.on("success", () => {
      setCopyMessage("Private key copied!");
      setPrivateKeyCopied(true);
      setTimeout(() => {
        setCopyMessage("");
        setPrivateKeyCopied(false);
      }, 2000);
    });

    clipboard.on("error", (err) => {
      console.error("Failed to copy text:", err);
      alert("Failed to copy text");
    });

    return () => clipboard.destroy(); // Clean up Clipboard.js instance
  }, [privateKey, setCopyMessage, setPrivateKeyCopied]);

  return (
    <div className="wooescrow-wallet-details">
      {showPasswordForm ? (
        <PasswordForm onPasswordSubmit={handlePasswordSubmit} />
      ) : (
        <>
          <h1 className="wooescrow-title">Wallet Details</h1>
          <p className="wooescrow-text-para">
            <strong>Currency:</strong> {selectedCurrency}
          </p>
          <p className="wooescrow-text-para">
            <strong>Address:</strong> {address}
          </p>
          <p className="wooescrow-text-para">
            <strong>Private Key:</strong> {privateKey}
          </p>
          <button id="copy-private-key-button" className="wooescrow-button">
            Copy
          </button>
          {copyMessage && <span className="copy-message">{copyMessage}</span>}
          <button
            onClick={() => setShowPasswordForm(true)}
            className="next-button wooescrow-button"
          >
            Next
          </button>
        </>
      )}
    </div>
  );
};

export default WalletDetails;
