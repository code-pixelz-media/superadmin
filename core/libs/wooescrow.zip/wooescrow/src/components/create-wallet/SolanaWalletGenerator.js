import React, { useEffect, useState } from "react";
import * as bip39 from "bip39";
import { Keypair } from "@solana/web3.js";
import bs58 from "bs58"; // Base58 library for encoding
import * as ed25519HdKey from "ed25519-hd-key"; // Import ed25519-hd-key

const SolanaWalletGenerator = ({ onMnemonicGenerated }) => {
  const [mnemonic, setMnemonic] = useState("");
  const [privateKey, setPrivateKey] = useState("");
  const [address, setAddress] = useState("");

  useEffect(() => {
    generateWallet();
  }, []);

  const generateWallet = async () => {
    try {
      // Generate a new mnemonic
      const newMnemonic = bip39.generateMnemonic();
      setMnemonic(newMnemonic);

      // Convert the mnemonic to a seed
      const seed = await bip39.mnemonicToSeed(newMnemonic);

      // Derive the keypair using a specific derivation path
      const derivationPath = "m/44'/501'/0'/0'"; // Solana derivation path
      const { key } = ed25519HdKey.derivePath(
        derivationPath,
        seed.toString("hex")
      );

      // Generate the keypair from the derived key
      const keypair = Keypair.fromSeed(key);

      // Encode the private key as Base58
      const newPrivateKey = bs58.encode(keypair.secretKey);
      const newAddress = keypair.publicKey.toBase58();

      // Set state with the generated values
      setPrivateKey(newPrivateKey);
      setAddress(newAddress);

      // Call the callback with the generated values
      onMnemonicGenerated(newMnemonic, {
        privateKey: newPrivateKey,
        address: newAddress,
        publicKey: newAddress, // In Solana, publicKey is the same as the address
      });

      console.log("Generated Mnemonic:", newMnemonic);
      console.log("Generated Private Key:", newPrivateKey);
      console.log("Generated Address:", newAddress);
    } catch (error) {
      console.error("Error generating wallet:", error);
    }
  };

  return null; // This component does not render anything itself
};

export default SolanaWalletGenerator;
