import React, { useState } from "react";
const CurrencySelection = ({ onCurrencySelected, onBack }) => {
  const [selectedCurrency, setSelectedCurrency] = useState("");

  const handleCurrencyChange = (event) => {
    setSelectedCurrency(event.target.value);
  };

  const handleCreate = () => {
    if (onCurrencySelected) {
      onCurrencySelected(selectedCurrency);
    } else {
      console.error("onCurrencySelected is not a function");
    }
  };

  return (
    <div className="wooescrow-wallet-currency-section">
      <div className="wooescrow-wallet-currency-wrapper">
        <div className="wooescrow-container">
          <div className="wooescrow-header-wrapper">
            <div className="wooescrow-wallet-currency-text"></div>
            <div className="wooescrow-header">
              <h1 className="wooescrow-title">Select the wallet’s currency</h1>
            </div>
          </div>

          <div className="wooescrow-wallet-currency-content-wrapper">
            <div className="wooescrow-wallet-currency-cards wooescrow-wallet-currency-radio-cards">
              {/* BTC */}
              <label className="wooescrow-wallet-currency-card wooescrow-wallet-currency-radio-box-group">
                <input
                  type="radio"
                  id="wooescrow-wallet-currency-radio-btc"
                  name="wooescrow-wallet-currency-radio-box"
                  className="wooescrow-wallet-currency-radio-box"
                  value="BTC"
                  onChange={handleCurrencyChange}
                />
                <div
                  id="wooescrow-wallet-currency-btc"
                  className="wooescrow-wallet-currency-btn"
                >
                  <div className="wooescrow-wallet-currency-card-img">
                    <img
                      src="/wp-content/plugins/wooescrow/wooescrow-public/img/btc-small.png"
                      alt="Bitcoin"
                    />
                  </div>
                  <div className="wooescrow-wallet-currency-card-body">
                    <h5 className="wooescrow-title wooescrow-uppercase">BTC</h5>
                    <p className="wooescrow-text-para">Bitcoin</p>
                  </div>
                </div>
              </label>
              {/* ETH */}
              <label className="wooescrow-wallet-currency-card wooescrow-wallet-currency-radio-box-group">
                <input
                  type="radio"
                  id="wooescrow-wallet-currency-radio-eth"
                  name="wooescrow-wallet-currency-radio-box"
                  className="wooescrow-wallet-currency-radio-box"
                  value="ETH"
                  onChange={handleCurrencyChange}
                />
                <div
                  id="wooescrow-wallet-currency-eth"
                  className="wooescrow-wallet-currency-btn"
                >
                  <div className="wooescrow-wallet-currency-card-img">
                    <img
                      src="/wp-content/plugins/wooescrow/wooescrow-public/img/eth-small.png"
                      alt="Ethereum"
                    />
                  </div>
                  <div className="wooescrow-wallet-currency-card-body">
                    <h5 className="wooescrow-title wooescrow-uppercase">ETH</h5>
                    <p className="wooescrow-text-para">Ethereum</p>
                  </div>
                </div>
              </label>
              {/* SOL */}
              <label className="wooescrow-wallet-currency-card wooescrow-wallet-currency-radio-box-group">
                <input
                  type="radio"
                  id="wooescrow-wallet-currency-radio-sol"
                  name="wooescrow-wallet-currency-radio-box"
                  className="wooescrow-wallet-currency-radio-box"
                  value="SOL"
                  onChange={handleCurrencyChange}
                />
                <div
                  id="wooescrow-wallet-currency-sol"
                  className="wooescrow-wallet-currency-btn"
                >
                  <div className="wooescrow-wallet-currency-card-img">
                    <img
                      src="/wp-content/plugins/wooescrow/wooescrow-public/img/sol-small.png"
                      alt="Solana"
                    />
                  </div>
                  <div className="wooescrow-wallet-currency-card-body">
                    <h5 className="wooescrow-title wooescrow-uppercase">SOL</h5>
                    <p className="wooescrow-text-para">Solana</p>
                  </div>
                </div>
              </label>
            </div>
            <div className="wooescrow-wallet-currency-next-btn wooescrow-end">
              <button
                type="button"
                className="wooescrow-button"
                onClick={handleCreate}
              >
                Next
                <span className="wooescrow-fa-icon">
                  <i className="fa-solid fa-arrow-right-long"></i>
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CurrencySelection;
