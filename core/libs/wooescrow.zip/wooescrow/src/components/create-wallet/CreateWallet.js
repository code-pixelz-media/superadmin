import React, { useState, useEffect } from "react";
import CurrencySelection from "./CurrencySelection";
import SolanaWalletGenerator from "./SolanaWalletGenerator";
import EthereumWalletGenerator from "./EthereumWalletGenerator";
import BitcoinWalletGenerator from "./BitcoinWalletGenerator";
import RecoveryPhrase from "./RecoveryPhrase";
import PasswordForm from "../wallet-includes/PasswordForm";
import WalletDetails from "./WalletDetails";
import BackButton from "../wallet-includes/BackButton";
import * as bip39 from "bip39";
import { createWallet, updateUserMeta } from "../wallet-includes/api";
const WooEscrowCryptoWalletRest = window.WooEscrowCryptoWalletRest || {};
const userEmail = WooEscrowCryptoWalletRest.user_email;

const CreateWallet = ({ userStatus, onBack }) => {
  const [view, setView] = useState("recoveryPhrase"); // Set initial view to recoveryPhrase
  const [mnemonic, setMnemonic] = useState("");
  const [selectedCurrency, setSelectedCurrency] = useState("");
  const [address, setAddress] = useState("");
  const [publicKey, setPublicKey] = useState("");
  const [privateKey, setPrivateKey] = useState("");
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [copyMessage, setCopyMessage] = useState("");
  const [privateKeyCopied, setPrivateKeyCopied] = useState(false);

  useEffect(() => {
    // Generate recovery phrase when component mounts
    const generateRecoveryPhrase = () => {
      const newMnemonic = bip39.generateMnemonic();
      setMnemonic(newMnemonic);
    };

    generateRecoveryPhrase();
  }, []);

  const handleProceedToCurrencySelection = () => {
    setView("currencySelection");
  };

  const handleCurrencySelected = (currency) => {
    setSelectedCurrency(currency);
    setView("walletDetails");
  };

  const handleMnemonicGenerated = (newMnemonic, walletData) => {
    setMnemonic(newMnemonic);
    setAddress(walletData.address);
    setPublicKey(walletData.publicKey);
    setPrivateKey(walletData.privateKey);
  };

  const handlePasswordSubmit = async (password) => {
    const walletData = {
      email: userEmail,
      password: password,
      wallet_address: address,
      currency: selectedCurrency,
    };

    try {
      // Attempt to create the wallet
      await createWallet(walletData);

      console.log("Wallet created and user meta updated successfully");
      window.location.reload();
    } catch (error) {
      console.error("Error during wallet creation or meta update:", error);
    }
  };

  const handleBack = () => {
    if (view === "currencySelection" || view === "walletDetails") {
      setView("recoveryPhrase"); // Go back to Recovery Phrase UI
    } else {
      onBack(); // Call parent back function if in Recovery Phrase UI
    }
  };

  return (
    <>
      <BackButton onBack={handleBack} />
      {/* Always show BackButton */}

      {view === "recoveryPhrase" && (
        <RecoveryPhrase
          currency={selectedCurrency}
          mnemonic={mnemonic}
          address={address}
          publicKey={publicKey}
          privateKey={privateKey}
          onProceedToNextStep={handleProceedToCurrencySelection}
        />
      )}

      {view === "currencySelection" && (
        <CurrencySelection onCurrencySelected={handleCurrencySelected} />
      )}

      {view === "walletDetails" && (
        <>
          {selectedCurrency === "SOL" && (
            <SolanaWalletGenerator
              onMnemonicGenerated={handleMnemonicGenerated}
            />
          )}
          {selectedCurrency === "ETH" && (
            <EthereumWalletGenerator
              mnemonic={mnemonic}
              onMnemonicGenerated={handleMnemonicGenerated}
            />
          )}
          {selectedCurrency === "BTC" && (
            <BitcoinWalletGenerator
              mnemonic={mnemonic}
              onMnemonicGenerated={handleMnemonicGenerated}
            />
          )}
          {!showPasswordForm && address && privateKey && (
            <WalletDetails
              selectedCurrency={selectedCurrency}
              address={address}
              privateKey={privateKey}
              copyMessage={copyMessage}
              privateKeyCopied={privateKeyCopied}
              showPasswordForm={showPasswordForm}
              setShowPasswordForm={setShowPasswordForm}
              handlePasswordSubmit={handlePasswordSubmit}
              setCopyMessage={setCopyMessage}
              setPrivateKeyCopied={setPrivateKeyCopied}
            />
          )}
          {showPasswordForm && (
            <PasswordForm onPasswordSubmit={handlePasswordSubmit} />
          )}
        </>
      )}
    </>
  );
};

export default CreateWallet;
