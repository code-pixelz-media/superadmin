import React, { useEffect, useState } from "react";
import { ethers } from "ethers";
import * as bip39 from "bip39";
import { HDNode } from "@ethersproject/hdnode";

const EthereumWalletGenerator = ({ onMnemonicGenerated }) => {
  const [mnemonic, setMnemonic] = useState("");
  const [privateKey, setPrivateKey] = useState("");
  const [address, setAddress] = useState("");

  useEffect(() => {
    generateWallet();
  }, []);

  const generateWallet = async () => {
    try {
      // Generate a new mnemonic
      const newMnemonic = bip39.generateMnemonic();
      setMnemonic(newMnemonic);

      // Convert the mnemonic to a seed
      const seed = await bip39.mnemonicToSeed(newMnemonic);

      // Create an HDNode from the seed using @ethersproject/hdnode
      const hdNode = HDNode.fromSeed(seed);

      // Derive the account from the HDNode
      const account = hdNode.derivePath("m/44'/60'/0'/0/0");

      // Create an ethers Wallet instance
      const wallet = new ethers.Wallet(account.privateKey);
      const newAddress = wallet.address;

      // Set state with the generated values
      setPrivateKey(account.privateKey);
      setAddress(newAddress);

      // Call the callback with the generated values
      onMnemonicGenerated(newMnemonic, {
        privateKey: account.privateKey,
        address: newAddress,
      });

      console.log("Generated Mnemonic:", newMnemonic);
      console.log("Generated Private Key:", account.privateKey);
      console.log("Generated Address:", newAddress);
    } catch (error) {
      console.error("Error generating wallet:", error);
    }
  };

  return null; // This component does not render anything itself
};

export default EthereumWalletGenerator;
