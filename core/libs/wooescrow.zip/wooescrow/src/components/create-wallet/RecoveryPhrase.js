import React, { useState, useEffect } from "react";
import Clipboard from "clipboard";

const RecoveryPhrase = ({
  currency,
  mnemonic,
  address,
  publicKey,
  privateKey,
  onProceedToNextStep,
}) => {
  const [copyMessage, setCopyMessage] = useState("");
  const [downloaded, setDownloaded] = useState(false);

  useEffect(() => {
    // Initialize Clipboard.js
    const clipboard = new Clipboard("#wooescrow-recovery-copyButton", {
      text: () => mnemonic,
    });

    clipboard.on("success", () => {
      setCopyMessage("Copied!");
      setTimeout(() => setCopyMessage(""), 2000); // Clear message after 2 seconds
    });

    clipboard.on("error", (err) => {
      console.error("Failed to copy text:", err);
      alert("Failed to copy text");
    });

    return () => clipboard.destroy(); // Clean up Clipboard.js instance
  }, [mnemonic]);

  const downloadFile = () => {
    try {
      const blob = new Blob([mnemonic], { type: "text/plain;charset=utf-8" });
      const link = document.createElement("a");
      link.href = window.URL.createObjectURL(blob);
      link.download = "recovery-phrase.txt";
      link.click();
      setDownloaded(true); // Update state to show "Proceed to Next Step" button
    } catch (err) {
      console.error("Failed to download file:", err);
      alert("Failed to download file");
    }
  };

  const handleProceedClick = () => {
    if (downloaded) {
      if (onProceedToNextStep) {
        onProceedToNextStep();
      } else {
        console.error("onProceedToNextStep is not defined");
      }
    } else {
      alert("Please download the recovery phrase before proceeding.");
    }
  };

  return (
    <div className="wooescrow-recovery-phrase">
      <div className="wooescrow-header-wrapper">
        <h1 className="wooescrow-title">Write down your recovery code</h1>
        <p className="wooescrow-text-para">
          You will need it in the next step!
        </p>
      </div>
      <ol className="wooescrow-generated-recovery-phrase">
        {mnemonic.split(" ").map((word, index) => (
          <li key={index}>{word}</li>
        ))}
      </ol>
      <div className="wooescrow-recovery-button-container">
        <button id="wooescrow-recovery-copyButton" className="wooescrow-button">
          Copy
        </button>
        {copyMessage && <span className="copy-message">{copyMessage}</span>}
        {!downloaded ? (
          <button
            className="wooescrow-button"
            id="wooescrow-recovery-downloadButton"
            onClick={downloadFile}
          >
            Download
          </button>
        ) : (
          <button
            className="wooescrow-button"
            id="wooescrow-recovery-proceedButton"
            onClick={handleProceedClick}
          >
            Proceed to Next Step
          </button>
        )}
      </div>
      <div className="wooescrow-recovery-info" style={{ display: "none" }}>
        <p className="wooescrow-text-para">
          <strong>Currency:</strong> {currency}
        </p>
        {address && (
          <p className="wooescrow-text-para">
            <strong>Wallet Address:</strong> {address}
          </p>
        )}
        <p
          className="wooescrow-text-para"
          style={{ display: publicKey ? "block" : "none" }}
        >
          <strong>Public Key:</strong> {publicKey}
        </p>
        <p
          className="wooescrow-text-para"
          style={{ display: privateKey ? "block" : "none" }}
        >
          <strong>Private Key:</strong> {privateKey}
        </p>
      </div>
    </div>
  );
};

export default RecoveryPhrase;
