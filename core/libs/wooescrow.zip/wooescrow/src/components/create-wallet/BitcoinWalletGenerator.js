import React, { useEffect, useState } from "react";
import * as bitcoin from "bitcoinjs-lib";
import * as bip32 from "bip32";
import * as bip39 from "bip39";

const BitcoinWalletGenerator = ({ onMnemonicGenerated }) => {
  const [mnemonic, setMnemonic] = useState("");
  const [address, setAddress] = useState("");
  const [privateKey, setPrivateKey] = useState("");

  useEffect(() => {
    generateWallet();
  }, []);

  const generateWallet = async () => {
    try {
      // Generate a random mnemonic (12-word phrase)
      const newMnemonic = bip39.generateMnemonic();
      setMnemonic(newMnemonic);
      const seed = await bip39.mnemonicToSeed(mnemonic);

      // Create an HD wallet from the seed using BIP32
      const root = bip32.fromSeed(seed);
      const child = root.derivePath("m/44'/0'/0'/0/0"); // BIP44 path for Bitcoin

      // Get the private key in WIF (Wallet Import Format)
      const privateKeyWif = child.toWIF();

      // Generate the Bitcoin address from the public key
      const { address } = bitcoin.payments.p2pkh({ pubkey: child.publicKey });

      // Set the state with the generated private key and address
      setPrivateKey(privateKeyWif);
      setAddress(address);

      // Call the callback with the generated values

      onMnemonicGenerated(newMnemonic, {
        privateKey: privateKeyWif,
        address: address,
      });

      // Log the results to the console
      console.log("Generated Mnemonic:", mnemonic);
      console.log("Generated Address:", address);
      console.log("Generated Private Key (WIF):", privateKeyWif);
    } catch (error) {
      console.error("Error generating wallet:", error);
    }
  };

  return null;
};

export default BitcoinWalletGenerator;
