import React, { useState } from "react";
import EnterSeedPhrase from "./EnterSeedPhrase";
import EnterPrivateKey from "./EnterPrivateKey";
import BackButton from "../wallet-includes/BackButton";

const ImportWallet = ({ onBack, userEmail }) => {
  const [view, setView] = useState("importOptions"); // Manage view state
  const [walletData] = useState(null); // State to store wallet data
  console.log(userEmail);
  const handleShowSeedPhraseInput = () => {
    setView("seedPhraseInput"); // Set view to Seed Phrase Input
  };

  const handleShowPrivateKeyInput = () => {
    setView("privateKeyInput"); // Set view to Private Key Input
  };

  const handleBack = () => {
    if (
      view === "seedPhraseInput" ||
      view === "privateKeyInput" ||
      view === "passwordForm"
    ) {
      setView("importOptions"); // Go back to Import Options
    } else {
      onBack(); // Call parent back function if in Import Options
    }
  };

  return (
    <div className="wooescrow-setup-section">
      <BackButton onBack={handleBack} />
      {/* Always show BackButton */}

      {view === "importOptions" && (
        <div className="wooescrow-setup-wrapper">
          <div className="wooescrow-container">
            <div className="wooescrow-header-wrapper">
              <div className="wooescrow-header">
                <h1 className="wooescrow-title">Choose your import method</h1>
              </div>
            </div>
            <div className="wooescrow-setup-content-wrapper">
              <button
                type="button"
                className="wooescrow-button wooescrow-enter-seed-phrase-button"
                onClick={handleShowSeedPhraseInput}
              >
                <img
                  src="/wp-content/plugins/wooescrow/wooescrow-public/img/seed-phrase.svg"
                  alt="Enter Seed Phrase"
                />
                <span className="wooescrow-button-text">Enter Seed Phrase</span>
              </button>
              <button
                type="button"
                className="wooescrow-button wooescrow-enter-private-key-button"
                onClick={handleShowPrivateKeyInput}
              >
                <img
                  src="/wp-content/plugins/wooescrow/wooescrow-public/img/private-key.svg"
                  alt="Enter Private Key"
                />
                <span className="wooescrow-button-text">Enter Private Key</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {view === "seedPhraseInput" && (
        <EnterSeedPhrase onBack={handleBack} userEmail={userEmail} />
      )}
      {/* Show Seed Phrase input with back button */}

      {view === "privateKeyInput" && (
        <EnterPrivateKey onBack={handleBack} userEmail={userEmail} />
      )}
    </div>
  );
};

export default ImportWallet;
