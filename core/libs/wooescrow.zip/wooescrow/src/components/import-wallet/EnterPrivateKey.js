import React, { useState } from "react";
import { ethers } from "ethers"; // For Ethereum
import bs58 from "bs58"; // For Solana (base58 encoding check)
import PasswordForm from "../wallet-includes/PasswordForm"; // Import PasswordForm component
import { createWallet } from "../wallet-includes/api";

const EnterPrivateKey = ({ onImport, userEmail }) => {
  const [privateKey, setPrivateKey] = useState("");
  const [error, setError] = useState(null);
  const [walletInfo, setWalletInfo] = useState(null);
  const [showPasswordForm, setShowPasswordForm] = useState(false); // New state

  const handlePrivateKeyChange = (e) => {
    setPrivateKey(e.target.value);
  };

  const handlePasteKey = async (e) => {
    e.preventDefault();
    setError(null); // Clear any previous errors

    try {
      // Check if Clipboard API is available
      if (
        navigator.clipboard &&
        typeof navigator.clipboard.readText === "function"
      ) {
        const text = await navigator.clipboard.readText();
        console.log("Pasted text:", text);
        setPrivateKey(text);
      } else {
        // Fallback for unsupported browsers or contexts
        throw new Error("Clipboard API is not supported or unavailable.");
      }
    } catch (err) {
      console.error("Clipboard access failed:", err);
      setError(
        "Clipboard access is not supported in this browser or context. Please paste the key manually."
      );
    }
  };

  const determineCurrency = (address) => {
    if (address.startsWith("0x") && address.length === 42) {
      return "ETH";
    } else if (/^(1|3|bc1)/.test(address)) {
      return "BTC";
    } else if (address.length === 44 && bs58.decode(address).length === 32) {
      return "SOL";
    } else {
      return "Unknown";
    }
  };

  const handleImport = async (e) => {
    e.preventDefault();
    setError(null);
    setWalletInfo(null);

    if (!privateKey) {
      setError("Private key cannot be empty.");
      return;
    }

    try {
      // Process private key
      const key = privateKey.startsWith("0x")
        ? privateKey.slice(2)
        : privateKey;
      console.log("Processed key:", key);

      if (key.length !== 64 || !/^[0-9a-fA-F]{64}$/.test(key)) {
        throw new Error("Invalid private key format.");
      }

      // Create Ethereum wallet
      const ethWallet = new ethers.Wallet(key);
      const address = ethWallet.address;

      // Determine the currency based on the address format
      const currency = determineCurrency(address);

      console.log("Wallet address:", address);
      console.log("Currency:", currency);

      // Update the wallet information state to display on UI
      setWalletInfo({ address, currency, userEmail });
      setShowPasswordForm(true); // Show password form

      // Pass the address and currency to the parent component if needed
      if (typeof onImport === "function") {
        onImport(address, currency);
      }
    } catch (err) {
      setError("Failed to import wallet. Please check the private key.");
      console.error(err);
    }
  };

  const handleImportPasswordSubmit = async (password) => {
    if (!walletInfo) return;

    try {
      console.log("Password submitted:", password);

      // Encrypt the password
      // const encryptedPassword = encryptPassword(password);

      // Create wallet data to be submitted
      const walletData = {
        email: walletInfo.userEmail,
        password: password,
        wallet_address: walletInfo.address,
        currency: walletInfo.currency,
      };

      // Attempt to create the wallet
      await createWallet(walletData);

      console.log("Wallet Imported successfully");

      window.location.reload();
      // Further handling or actions can be performed here if needed
    } catch (error) {
      console.error("Error during wallet creation or meta update:", error);
    }
  };

  return (
    <div className="wooescrow-existing-wallet-section">
      <div className="wooescrow-existing-wallet-wrapper">
        <div className="wooescrow-container">
          <div className="wooescrow-header-wrapper">
            <div className="wooescrow-header">
              <h1 className="wooescrow-title">Add your existing wallet</h1>
            </div>
            <p className="wooescrow-text-para">
              Import your wallet on WooEscrow with a recovery private key
            </p>
          </div>
          <div className="wooescrow-existing-wallet-content-wrapper">
            {!showPasswordForm ? (
              <form className="wooescrow-form wooescrow-existing-wallet-form">
                <div className="wooescrow-form-group wooescrow-existing-wallet-form-group">
                  <label
                    htmlFor="wooescrow-existing-wallet-private-key"
                    className="wooescrow-label"
                  >
                    <span className="wooescrow-label-text">
                      Enter private key
                    </span>
                  </label>
                  <input
                    type="text"
                    id="wooescrow-existing-wallet-private-key"
                    className="wooescrow-input"
                    value={privateKey}
                    onChange={handlePrivateKeyChange}
                  />
                </div>
                <div className="wooescrow-form-group wooescrow-existing-wallet-form-group wooescrow-existing-wallet-button-group">
                  <button
                    id="wooescrow-existing-wallet-paste-key"
                    className="wooescrow-button wooescrow-gray"
                    onClick={handlePasteKey}
                  >
                    Paste Key
                  </button>
                  <button
                    id="wooescrow-existing-wallet-import"
                    className="wooescrow-button"
                    onClick={handleImport}
                  >
                    Import
                  </button>
                </div>
                {error && <p className="wooescrow-error-message">{error}</p>}
                {walletInfo && (
                  <div className="wooescrow-wallet-info">
                    <p>Wallet Address: {walletInfo.address}</p>
                    <p>Currency: {walletInfo.currency}</p>
                  </div>
                )}
              </form>
            ) : (
              <PasswordForm onPasswordSubmit={handleImportPasswordSubmit} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnterPrivateKey;
