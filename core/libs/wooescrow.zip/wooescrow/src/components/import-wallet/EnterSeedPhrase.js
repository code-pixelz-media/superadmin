import React, { useState } from "react";
import { Keypair as SolanaKeypair } from "@solana/web3.js"; // For Solana
import * as bitcoin from "bitcoinjs-lib"; // For Bitcoin
import * as bip39 from "bip39"; // For mnemonic to seed conversion
import * as bip32 from "bip32"; // For Bitcoin HD wallet derivation
import { HDNode } from "@ethersproject/hdnode"; // For Ethereum
import bs58 from "bs58"; // Base58 for Solana
import * as ed25519HdKey from "ed25519-hd-key"; // For Solana derivation

const EnterSeedPhrase = () => {
  const initialPhrases = Array(12).fill({ value: "", show: false });
  const [recoveryPhrase, setRecoveryPhrase] = useState(initialPhrases);
  const [error, setError] = useState(null);
  const [walletInfo, setWalletInfo] = useState([]);

  const handleChange = (index, value) => {
    setRecoveryPhrase((prevPhrases) =>
      prevPhrases.map((phrase, i) =>
        i === index ? { ...phrase, value: value } : phrase
      )
    );
  };

  const handlePaste = (event) => {
    const pastedText = event.clipboardData.getData("text");
    const words = pastedText.trim().split(/\s+/);

    if (words.length === 12) {
      setRecoveryPhrase((prevPhrases) =>
        prevPhrases.map((phrase, i) => ({
          ...phrase,
          value: words[i] || "",
        }))
      );
      setError(null);
    } else {
      setError("Please paste exactly 12 words.");
    }

    event.preventDefault();
  };

  const toggleShowPassword = (index) => {
    setRecoveryPhrase((prevPhrases) =>
      prevPhrases.map((phrase, i) =>
        i === index ? { ...phrase, show: !phrase.show } : phrase
      )
    );
  };

  const generateWallets = async (seed) => {
    const wallets = [];

    // Ethereum
    try {
      const ethHdNode = HDNode.fromSeed(seed);
      const ethDerivationPath = "m/44'/60'/0'/0/0";
      const ethWallet = ethHdNode.derivePath(ethDerivationPath);
      wallets.push({
        currency: "Ethereum",
        address: ethWallet.address,
        privateKey: ethWallet.privateKey,
        publicKey: ethWallet.publicKey,
      });
    } catch (err) {
      console.error("Ethereum error: ", err);
    }

    // Bitcoin
    try {
      const btcHdNode = bip32.fromSeed(seed);
      const btcDerivationPath = "m/44'/0'/0'/0/0";
      const btcKeyPair = btcHdNode.derivePath(btcDerivationPath);
      const btcAddress = bitcoin.payments.p2pkh({
        pubkey: btcKeyPair.publicKey,
      }).address;
      wallets.push({
        currency: "Bitcoin",
        address: btcAddress,
        privateKey: btcKeyPair.toWIF(),
        publicKey: btcKeyPair.publicKey.toString("hex"),
      });
    } catch (err) {
      console.error("Bitcoin error: ", err);
    }

    // Solana
    try {
      const solDerivationPath = "m/44'/501'/0'/0'";
      const { key } = ed25519HdKey.derivePath(
        solDerivationPath,
        seed.toString("hex")
      );
      const solKeypair = SolanaKeypair.fromSeed(key);
      wallets.push({
        currency: "Solana",
        address: solKeypair.publicKey.toBase58(),
        privateKey: bs58.encode(solKeypair.secretKey),
        publicKey: solKeypair.publicKey.toBase58(),
      });
    } catch (err) {
      console.error("Solana error: ", err);
    }

    return wallets;
  };

  const handleImport = async () => {
    const phrase = recoveryPhrase
      .map((item) => item.value)
      .join(" ")
      .trim();

    if (bip39.validateMnemonic(phrase)) {
      try {
        const seed = await bip39.mnemonicToSeed(phrase);

        // Generate addresses for all supported blockchains
        const wallets = await generateWallets(seed);

        if (wallets.length > 0) {
          setWalletInfo(wallets);
          setError(null);
        } else {
          setError("Failed to derive any wallet address");
        }
      } catch (err) {
        setError("Failed to derive wallet address");
        console.error(err);
      }
    } else {
      setError("Invalid recovery phrase");
    }
  };

  return (
    <div className="wooescrow-wallet-secret-recovery-phrase">
      <h1 className="wooescrow-title">Secret Recovery Phrase</h1>
      <p className="wooescrow-text-para">
        Import an existing wallet with your Secret Recovery Phrase.
      </p>

      <div className="wooescrow-wallet-message-box">
        <span>
          <i className="fa-solid fa-circle-info"></i>
        </span>
        <p className="wooescrow-text-para">
          You're able to copy and paste your complete secret recovery phrase
          into any available field.
        </p>
      </div>

      <div className="wooescrow-wallet-secret-code-structure">
        <div className="wooescrow-wallet-secret-code-input-wrapper">
          {recoveryPhrase.map((phrase, index) => (
            <div
              key={index}
              id={`wooescrow-pw-${index + 1}`}
              className="wooescrow-wallet-secret-code-input-container"
            >
              <span
                id={`wooescrow-placeholder-${index + 1}`}
                attr={`${index + 1}.`}
                className="wooescrow-code-placeholder"
              >
                {index + 1}.
              </span>
              <input
                type={phrase.show ? "text" : "password"}
                className="wooescrow-wallet-secret-code-passwordField"
                placeholder=""
                value={phrase.value}
                onChange={(e) => handleChange(index, e.target.value)}
                onPaste={handlePaste}
              />
              <span
                className="wooescrow-wallet-secret-code-togglePassword wooescrow-eye-icon"
                onClick={() => toggleShowPassword(index)}
              >
                <i
                  className={`fas ${phrase.show ? "fa-eye" : "fa-eye-slash"}`}
                ></i>
              </span>
            </div>
          ))}
        </div>
        <div className="wooescrow-wallet-secret-code-button-container wooescrow-text-center">
          <button
            id="wooescrow-wallet-secret-code-import-button"
            className="wooescrow-button"
            onClick={handleImport}
          >
            Import Wallet
          </button>
        </div>

        {/* Display wallet info or error messages */}
        {walletInfo.length > 0 && (
          <div className="wooescrow-wallet-info wooescrow-text-center">
            {walletInfo.map((wallet, index) => (
              <p key={index}>
                Currency: {wallet.currency}
                <br />
                Address: {wallet.address}
                <br />
                Private Key: {wallet.privateKey}
                {wallet.publicKey && (
                  <>
                    <br />
                    Public Key: {wallet.publicKey}
                  </>
                )}
              </p>
            ))}
          </div>
        )}

        {error && (
          <div className="wooescrow-wallet-error-messages wooescrow-text-center">
            <p>{error}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default EnterSeedPhrase;
