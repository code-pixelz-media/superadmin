// src/index.js
import React from "react";
import ReactDOM from "react-dom";
import WooEscrowWalletMainComponent from "./components/WooEscrowWallet.js";
import "./components/wallet-includes/polyfills";

document.addEventListener("DOMContentLoaded", () => {
  const element = document.getElementById("wooescrow-wallet");
  if (element) {
    ReactDOM.render(<WooEscrowWalletMainComponent />, element);
  }
});
