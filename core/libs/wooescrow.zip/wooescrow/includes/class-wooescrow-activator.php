<?php

/**
 * Fired during plugin activation
 *
 * @link       https://https://codepixelzmedia.com/
 * @since      1.0.0
 *
 * @package    Wooescrow
 * @subpackage Wooescrow/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wooescrow
 * @subpackage Wooescrow/includes
 * @author     Code Pixelz X Pwn Bot <dev@codepixelzmedia.com.np>
 */
class Wooescrow_Activator
{

	/**
	 * Fired during plugin activation.
	 *
	 * This method creates a page called "Wooescrow Wallet" and adds the shortcode to its content.
	 *
	 * @since    1.0.0
	 */
	public static function activate()
	{
		$page_title = 'Wooescrow Wallet';
		$page_content = '[wooescrow-wallet]';
		// Check if the page already exists by title
		$page = get_page_by_title($page_title);

		if ($page) {
			// If the page exists, delete it permanently
			wp_delete_post($page->ID, true);
		}

		// Create the page
		wp_insert_post(array(
			'post_title'   => $page_title,
			'post_content' => $page_content,
			'post_status'  => 'publish',
			'post_type'    => 'page',
		));
	}
}
