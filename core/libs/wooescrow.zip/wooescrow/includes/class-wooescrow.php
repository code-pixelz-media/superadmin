<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://https://codepixelzmedia.com/
 * @since      1.0.0
 *
 * @package    Wooescrow
 * @subpackage Wooescrow/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Wooescrow
 * @subpackage Wooescrow/includes
 * @author     Code Pixelz X Pwn Bot <dev@codepixelzmedia.com.np>
 */
class Wooescrow
{

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Wooescrow_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;
	
	
	/**
	 * Update status
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $update;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct()
	{
		if (defined('WOOESCROW_VERSION')) {
			$this->version = WOOESCROW_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'wooescrow';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

		add_filter('body_class', [$this, 'wooescrow_wallet_body_class']);
		add_action('init', array($this, 'add_wallet_endpoint'));
		add_filter('woocommerce_get_endpoint_url', array($this, 'wooescrow_menu_item_url'), 10, 2);
		add_filter('woocommerce_account_menu_items', array($this, 'add_wallet_menu_item'), 20);
	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Wooescrow_Loader. Orchestrates the hooks of the plugin.
	 * - Wooescrow_i18n. Defines internationalization functionality.
	 * - Wooescrow_Admin. Defines all hooks for the admin area.
	 * - Wooescrow_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies()
	{

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-wooescrow-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-wooescrow-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'wooescrow-admin/class-wooescrow-admin.php';
		/**
		 * The class responsible for settings page
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'wooescrow-admin/class-wooescrow-settings.php';
		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'wooescrow-public/class-wooescrow-public.php';
		/**
		 * This class responsible for plugin update
		 */
         require_once plugin_dir_path(dirname(__FILE__)) . 'wooescrow-admin/class-wooescrow-plugin-update.php';

		$this->loader = new Wooescrow_Loader();
		
		$this->update = new Wooescrow_Plugin_Update();
	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Wooescrow_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale()
	{

		$plugin_i18n = new Wooescrow_i18n();

		$this->loader->add_action('plugins_loaded', $plugin_i18n, 'load_plugin_textdomain');
	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks()
	{

		$plugin_admin = new Wooescrow_Admin($this->get_plugin_name(), $this->get_version());
		

		$this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
		$this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts');
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks()
	{

		$plugin_public = new Wooescrow_Public($this->get_plugin_name(), $this->get_version());

		$this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_styles');
		$this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_scripts');
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run()
	{
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name()
	{
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Wooescrow_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader()
	{
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version()
	{
		return $this->version;
	}

	// Hook into the 'body_class' filter to add a custom class


	public function wooescrow_wallet_body_class($classes)
	{
		// Add a custom class to the body tag
		$classes[] = 'wooescrow-wallet-active';
		return $classes;
	}



	/* Woocommerce Wallet Menu MY-Account page */
	/**
	 * Add the Wallet endpoint to WooCommerce My Account page.
	 *
	 * @since    1.0.0
	 */
	public static function add_wallet_endpoint()
	{
		add_rewrite_endpoint('wooescrow', EP_ROOT | EP_PAGES);
	}

	/**
	 * Add the Wallet menu item to the My Account menu.
	 *
	 * @param array $items The existing menu items.
	 * @return array Modified menu items.
	 */


	/**
	 * Add the Wallet menu item to the My Account menu.
	 *
	 * @param array $items The existing menu items.
	 * @return array Modified menu items.
	 */
	/**
	 * Add the Wallet menu item to the My Account menu.
	 *
	 * @param array $items The existing menu items.
	 * @return array Modified menu items.
	 */
	public function add_wallet_menu_item($items)
	{
		// Get the Wooescrow Wallet page
		$wooescrow_wallet_page = get_page_by_title('Wooescrow Wallet');

		if ($wooescrow_wallet_page && $wooescrow_wallet_page->ID) {
			// Create a new item for the menu
			$new_items = array();

			// Iterate through existing items
			foreach ($items as $endpoint => $label) {
				// Add existing items to the new array
				$new_items[$endpoint] = $label;

				// Insert 'wooescrow' after 'orders'
				if ($endpoint === 'orders') {
					$new_items['wooescrow'] = 'WooEscrow';
				}
			}

			// In case 'orders' was not found, add 'wooescrow' at the end
			if (!array_key_exists('wooescrow', $new_items)) {
				$new_items['wooescrow'] = 'WooEscrow';
			}

			return $new_items;
		}

		return $items;
	}


	/**
	 * Add custom URL to the Wooescrow menu item.
	 *
	 * @param string $url The URL of the menu item.
	 * @param string $endpoint The endpoint slug.
	 * @return string Modified URL.
	 */
	public function wooescrow_menu_item_url($url, $endpoint)
	{
		if ($endpoint === 'wooescrow') {
			$wooescrow_wallet_page = get_page_by_title('Wooescrow Wallet');
			if ($wooescrow_wallet_page && $wooescrow_wallet_page->ID) {
				$url = get_permalink($wooescrow_wallet_page->ID);
			}
		}
		return $url;
	}
}
