<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://https://codepixelzmedia.com/
 * @since      1.0.0
 *
 * @package    Wooescrow
 * @subpackage Wooescrow/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Wooescrow
 * @subpackage Wooescrow/includes
 * @author     Code Pixelz X Pwn Bot <dev@codepixelzmedia.com.np>
 */
class Wooescrow_Deactivator
{

	/**
	 * Fired during plugin deactivation.
	 *
	 * This method deletes the page called "Wooescrow Wallet" if it exists.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate()
	{
		$page_title = 'Wooescrow Wallet';

		// Get the page by title
		$page = get_page_by_title($page_title);

		if ($page) {
			// Delete the page permanently
			wp_delete_post($page->ID, true);
		}
	}
}
