<?php

/**
 * Class Register_Rest_Routes
 *
 * This class is responsible for registering REST routes for the plugin.
 */
// File: includes/class-register-rest-routes.php

class Register_Rest_Routes
{
    public function __construct()
    {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes()
    {
        register_rest_route('wooescrow-wallet/v1', '/user-status', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_user_status'),
            'permission_callback' => '__return_true',
        ));

        // Register route for updating user meta
        register_rest_route('wooescrow-wallet/v1', '/update-user-meta', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'wooescrow_wallet_update_user_meta'),
            'permission_callback' => array($this, 'permission_check'),
        ));

        // Register route for getting user meta
        register_rest_route('wooescrow-wallet/v1', '/get-user-meta', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'wooescrow_wallet_get_user_meta'),
            'permission_callback' => '__return_true',
        ));

        //regisrtet route for storing securotyu level data

        register_rest_route('wooescrow-wallet/v1', '/generate_totp_secret', [
            'methods' => 'POST',
            'callback' => array($this, 'wooescrow_generate_totp_secret'),
            'permission_callback' => array($this, 'permission_check'),
        ]);

        register_rest_route('wooescrow-wallet/v1', '/verify_totp', [
            'methods' => 'POST',
            'callback' => array($this, 'wooescrow_verify_totp'),
            'permission_callback' => array($this, 'permission_check'),
        ]);
    }

    public function get_user_status(WP_REST_Request $request)
    {
        $nonce = $request->get_header('X-WP-Nonce');

        if (!$nonce || !wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('rest_forbidden', esc_html__('You cannot view this resource.'), array('status' => 401));
        }

        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            $roles = $current_user->roles;
            // Convert roles array to a comma-separated string
            $get_role = implode(', ', $roles);

            return array(
                'ID'       => $current_user->ID,
                'email'    => $current_user->user_email,
                'username' => $current_user->user_login,
                'role'     => $get_role,
            );
        } else {
            return new WP_Error('no_user', 'User not logged in', array('status' => 401));
        }
    }

    public function wooescrow_wallet_update_user_meta(WP_REST_Request $request)
    {
        $user_id = get_current_user_id();
        if ($user_id === 0) {
            return new WP_Error('not_logged_in', 'You must be logged in to update user meta.', array('status' => 401));
        }

        // Get the parameters from the request
        $meta_key = $request->get_param('meta_key');
        $meta_value = $request->get_param('meta_value');

        // Sanitize the input values
        $meta_key = sanitize_text_field($meta_key);
        $meta_value = sanitize_text_field($meta_value);

        $updated = update_user_meta($user_id, $meta_key, $meta_value);

        if ($updated) {
            return rest_ensure_response(array(
                'status'  => 'success',
                'message' => 'User meta updated successfully.'
            ));
        } else {
            return new WP_Error('update_failed', 'Failed to update user meta.', array('status' => 500));
        }
    }

    public function wooescrow_wallet_get_user_meta(WP_REST_Request $request)
    {
        $user_id = get_current_user_id();
        if ($user_id === 0) {
            return new WP_Error('not_logged_in', 'You must be logged in to view user meta.', array('status' => 401));
        }

        // Get the meta key from the request
        $meta_key = $request->get_param('meta_key');

        // if (!$meta_key) {
        //     return new WP_Error('missing_meta_key', 'Meta key is required.', array('status' => 400));
        // }

        if (!$meta_key) {
            return new WP_Error('no_meta_key', 'Meta key is missing', array('status' => 400));
        }

        $meta_value = get_user_meta($user_id, $meta_key, true);

        return rest_ensure_response(array('meta_value' => $meta_value));
    }


    public function wooescrow_generate_totp_secret(WP_REST_Request $request)
    {
        $user_id = get_current_user_id();
        $secret = $request->get_param('secret_key');
        update_user_meta($user_id, '_wooescrow_user_totp_secret', $secret);
        return new WP_REST_Response([
            'secret' => $secret,
            'qr_code_url' => $this->wooescrow_generate_totp_qr_code_url($secret),
        ], 200);
    }
    public function wooescrow_generate_totp_qr_code_url($secret)
    {
        $user = wp_get_current_user();
        $issuer = 'WooEscrow';
        $label = urlencode($user->user_email);
        return "otpauth://totp/{$issuer}:{$label}?secret={$secret}&issuer={$issuer}";
    }

    public function permission_check($request)
    {
        if (!is_user_logged_in()) {
            return new WP_Error('rest_forbidden_wooescrow', 'You must be logged in to access this endpoint.', array('status' => 403));
        }
        return true;
    }
}

new Register_Rest_Routes();
