const webpack = require("webpack");

module.exports = {
  // Your entry point and output configuration
  entry: "./src/index.js", // Adjust this path to your actual entry file
  output: {
    path: __dirname + "/dist",
    filename: "bundle.js",
  },

  // Resolve fallback for Node.js modules
  resolve: {
    fallback: {
      stream: require.resolve("stream-browserify"),
      buffer: require.resolve("buffer/"),
      crypto: require.resolve("crypto-browserify"),
      process: require.resolve("process/browser"),
      // Include other necessary polyfills here
    },
  },

  plugins: [
    new webpack.ProvidePlugin({
      Buffer: ["buffer", "Buffer"],
      process: "process/browser",
    }),
  ],

  // Other configurations like loaders, etc.
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: "babel-loader",
      },
      // Add other loaders if necessary
    ],
  },

  // Optional: set mode to development for easier debugging
  mode: "development",
};
