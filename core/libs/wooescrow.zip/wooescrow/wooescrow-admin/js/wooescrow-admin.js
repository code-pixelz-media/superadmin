(function ($) {
  "use strict";
  $(document).ready(function () {
    var activeTab = $(".wooescrow-nav-tab-active").attr("href");
    var tabParam = new URLSearchParams(activeTab).get("tab");

    function fetch_users(page = 1) {
      $("#user-list-spinner").show();
      $("#user-list-table").addClass("wooescrow-blur");
      // $('#user-pagination').hide();

      $.ajax({
        url: adminScript.ajaxUrl,
        method: "POST",
        data: { action: "wooescrow_fetch_users_with_pagination", page: page },
        success: function (response) {
          $("#user-list-spinner").hide();
          $("#user-list-table").removeClass("wooescrow-blur");

          if (response.success && response.data.users.length > 0) {
            var tbody = $("#user-list-table tbody");
            tbody.empty();

            $.each(response.data.users, function (index, user) {
              var wallets = "";
              $.each(user.wallet_addresses, function (i, wallet) {
                var shortAddress =
                  wallet.address.slice(0, 7) + "..." + wallet.address.slice(-6);
                wallets +=
                  '<div class="wooescrow-wallet-details">' +
                  '<span class="wooescrow-wallet-currency">' +
                  wallet.network +
                  "</span>" +
                  '<span class="wooescrow-wallet-address">' +
                  shortAddress +
                  '<button class="wooescrow-wallet-copy" data-address="' +
                  wallet.address +
                  '" data-tooltip="Copy" style="visibility: visible;">' +
                  '<i class="fa-regular fa-copy"></i>' +
                  "</button>" +
                  "</span>" +
                  "</div>";
              });

              tbody.append(
                "<tr>" +
                  "<td>" +
                  user.id +
                  "</td>" +
                  "<td>" +
                  user.email +
                  "</td>" +
                  "<td>" +
                  user.role +
                  "</td>" +
                  '<td><div class="wooescrow-wallet-details-wrap">' +
                  wallets +
                  "</div></td>" +
                  "</tr>"
              );
            });

            $("#user-pagination").html(response.data.pagination).show();
          } else {
            var tbody = $("#user-list-table tbody");
            tbody.empty();
            tbody.append(
              '<tr><td colspan="4"><?php esc_html_e("No users found.", "wooescrow"); ?></td></tr>'
            );
          }
        },
        error: function () {
          $("#user-list-spinner").hide();
          $("#user-list-table").removeClass("wooescrow-blur");
          var tbody = $("#user-list-table tbody");
          tbody.empty();
          tbody.append(
            '<tr><td colspan="4"><?php esc_html_e("Error fetching data.", "wooescrow"); ?></td></tr>'
          );
        },
      });
    }

    function fetch_withdrawals(page = 1) {
      $("#withdrawal-request-spinner").show();
      $("#withdrawal-request-table").addClass("wooescrow-blur");
      // $('#withdrawal-pagination').hide();
      $.ajax({
        url: adminScript.ajaxUrl,
        method: "POST",
        data: {
          action: "wooescrow_fetch_withdrawal_requests_with_pagination",
          page: page,
        },
        success: function (response) {
          $("#withdrawal-request-spinner").hide();
          $("#withdrawal-request-table").removeClass("wooescrow-blur");

          if (response.success && response.data.withdrawals.length > 0) {
            var tbody = $("#withdrawal-request-table tbody");
            tbody.empty();

            $.each(response.data.withdrawals, function (index, withdrawal) {
              tbody.append(
                "<tr>" +
                  "<td>" +
                  withdrawal.id +
                  "</td>" +
                  "<td>" +
                  withdrawal.amount +
                  "</td>" +
                  "<td>" +
                  withdrawal.currency +
                  "</td>" +
                  "<td>" +
                  withdrawal.created_at +
                  "</td>" +
                  "</tr>"
              );
            });

            $("#withdrawal-pagination").html(response.data.pagination).show();
          } else {
            var tbody = $("#withdrawal-request-table tbody");
            tbody.empty();
            tbody.append(
              '<tr><td colspan="4"><?php esc_html_e("No withdrawal requests found.", "wooescrow"); ?></td></tr>'
            );
          }
        },
        error: function () {
          $("#withdrawal-request-spinner").hide();
          $("#withdrawal-request-table").removeClass("wooescrow-blur");
          var tbody = $("#withdrawal-request-table tbody");
          tbody.empty();
          tbody.append(
            '<tr><td colspan="4"><?php esc_html_e("Error fetching data.", "wooescrow"); ?></td></tr>'
          );
        },
      });
    }

    function fetch_wallet_list(page = 1) {
      $("#wallet-list-spinner").show();
      $("#wallet-list-table").addClass("wooescrow-blur");
      $.ajax({
        url: adminScript.ajaxUrl,
        method: "POST",
        data: { action: "wooescrow_wallet_lists", page: page },
        success: function (response) {
          $("#wallet-list-spinner").hide();
          $("#wallet-list-table").removeClass("wooescrow-blur");
          if (response.success && response.data.wallets.length > 0) {
            console.log("success", response);
            var tbody = $("#wallet-list-table tbody");
            tbody.empty();

            $.each(response.data.wallets, function (index, wallet) {
              tbody.append(
                "<tr>" +
                  "<td>" +
                  wallet.wallet_addresses[index].id +
                  "</td>" +
                  "<td>" +
                  wallet.wallet_addresses[index].user_id +
                  "</td>" +
                  "<td>" +
                  wallet.wallet_addresses[index].address +
                  "</td>" +
                  '<td><div class="wooescrow-wallet-details-wrap">' +
                  wallet.wallet_addresses[index].network +
                  "</div></td>" +
                  "<td>" +
                  wallet.wallet_addresses[index].created_at +
                  "</td>" +
                  "</tr>"
              );
            });

            $("#wallet-pagination").html(response.data.pagination).show();
          }
        },
        error: function () {},
      });
    }

    $(document).on("click", ".wooescrow-pagination a", function (e) {
      e.preventDefault();

      var page = $(this).data("page");
      if (tabParam == "wooescrow-list-users") {
        fetch_users(page);
      } else if ((tabParam = "wooescrow-withdrawl-request")) {
        fetch_withdrawals(page);
      } else if (tabParam == "wooescrow-wallet-list") {
        fetch_wallet_list(page);
      }
    });

    if (tabParam == "wooescrow-list-users") {
      fetch_users();
    } else if (tabParam == "wooescrow-withdrawl-request") {
      fetch_withdrawals();
    } else if (tabParam == "wooescrow-wallet-list") {
      fetch_wallet_list();
    }
  });

  $(document).on("click", ".wooescrow-wallet-copy", function (e) {
    e.preventDefault();
    let copyElm = $(this).data("address");
    let $button = $(this);
    let $icon = $button.find("i");

    // Check if clipboard and writeText are supported
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard
        .writeText(copyElm)
        .then(function () {
          $button.attr("data-tooltip", "Copied");

          $icon.removeClass("fa-copy").addClass("fa-solid fa-check");

          setTimeout(function () {
            $icon.addClass("fade-out");
          }, 500);

          setTimeout(function () {
            $icon.removeClass("fa-solid fa-check fade-out").addClass("fa-copy");
            $button.attr("data-tooltip", "Copy");
          }, 1000);
        })
        .catch(function (err) {
          console.error("Could not copy text: ", err);
        });
    } else {
      // Fallback if clipboard API is not supported
      let tempInput = $("<input>");
      $("body").append(tempInput);
      tempInput.val(copyElm).select();
      document.execCommand("copy");
      tempInput.remove();

      $button.attr("data-tooltip", "Copied");

      $icon.removeClass("fa-copy").addClass("fa-solid fa-check");

      setTimeout(function () {
        $icon.addClass("fade-out");
      }, 500);

      setTimeout(function () {
        $icon.removeClass("fa-solid fa-check fade-out").addClass("fa-copy");
        $button.attr("data-tooltip", "Copy");
      }, 1000);
    }
  });
})(jQuery);

jQuery(document).ready(function () {
  jQuery('#wooescrow-deactivate-lisence-button').hide();
  var loader_src = woooescrowAdmin.pluginUrl;
  activateLisenceKey();

  // Function to check if both fields have values and run AJAX if they do
  function activateLisenceKey() {
    var lisence_email = jQuery(
      'input[name="wooescrow-integrations[wooescrow-email-address]"]'
    ).val();
    var lisence_key = jQuery(
      'input[name="wooescrow-integrations[wooescrow-lisence-key]"]'
    ).val();

    if (lisence_email && lisence_key) {
      jQuery.ajax({
        url: adminajax.ajaxUrl, // Using the localized URL
        method: "POST",
        data: {
          action: "lisence_activation_call",
          lisence_email: lisence_email,
          lisence_key: lisence_key,
        },
        beforeSend: function () {
          jQuery(
            'input[name="wooescrow-integrations[wooescrow-email-address]"]'
          ).after(
            '<img src="' +
              loader_src +
              'loading.png" alt="loader" class="wooescrow-email-verify-loader-image">'
          );
          jQuery(
            'input[name="wooescrow-integrations[wooescrow-lisence-key]"]'
          ).after(
            '<img src="' +
              loader_src +
              'loading.png" alt="loader" class="wooescrow-lisence-verify-loader-image">'
          );
        },
        success: function (response) {
          if (response.success) {
            jQuery(
              ".wooescrow-email-verify-loader-image,.wooescrow-lisence-verify-loader-image"
            ).remove();
            jQuery(
              'input[name="wooescrow-integrations[wooescrow-email-address]"]'
            ).after(
              '<img src="' +
                loader_src +
                'check.png" alt="loader" class="wooescrow-email-verify-loader-image">'
            );
            jQuery(
              'input[name="wooescrow-integrations[wooescrow-lisence-key]"]'
            ).after(
              '<img src="' +
                loader_src +
                'check.png" alt="loader" class="wooescrow-lisence-verify-loader-image">'
            );
            jQuery('#wooescrow-activate-lisence-button').parent().parent().hide();
            jQuery('#wooescrow-deactivate-lisence-button').show();
            jQuery('input[name="wooescrow-integrations[wooescrow-email-address]"]').prop('disabled', true);
            jQuery('input[name="wooescrow-integrations[wooescrow-lisence-key]"]').prop('disabled', true);
          } else {
            jQuery(
              ".wooescrow-email-verify-loader-image,.wooescrow-lisence-verify-loader-image"
            ).remove();
            jQuery(
              'input[name="wooescrow-integrations[wooescrow-email-address]"]'
            ).after(
              '<img src="' +
                loader_src +
                'remove.png" alt="loader" class="wooescrow-email-verify-loader-image">'
            );
            jQuery(
              'input[name="wooescrow-integrations[wooescrow-lisence-key]"]'
            ).after(
              '<img src="' +
                loader_src +
                'remove.png" alt="loader" class="wooescrow-lisence-verify-loader-image">'
            );
          }
        },
        complete: function (response) {},
        error: function (xhr, status, error) {
          console.log("Error:", status, error);
        },
      });
    }
  }

  function deactivateLisenceKey() {
    var lisence_email = jQuery(
      'input[name="wooescrow-integrations[wooescrow-email-address]"]'
    ).val();
    var lisence_key = jQuery(
      'input[name="wooescrow-integrations[wooescrow-lisence-key]"]'
    ).val();

    if (lisence_email && lisence_key) {
      jQuery.ajax({
        url: adminajax.ajaxUrl, // Using the localized URL
        method: "POST",
        data: {
          action: "lisence_deactivation_call",
          lisence_email: lisence_email,
          lisence_key: lisence_key,
        },
        beforeSend: function () {
        },
        success: function (response) {
          console.log(response);
          if (response.success) {
            location.reload();
          }
        },
        complete: function (response) {},
        error: function (xhr, status, error) {
          console.log("Error:", status, error);
        },
      });
    }
  }

  jQuery(document).on(
    "click",
    "#wooescrow-activate-lisence-button",
    function () {
      activateLisenceKey();
    }
  );
  jQuery(document).on(
    "click",
    "#wooescrow-deactivate-lisence-button",
    function () {
      deactivateLisenceKey();
    }
  );
});
