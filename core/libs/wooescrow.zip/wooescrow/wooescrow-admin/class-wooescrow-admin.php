<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://https://codepixelzmedia.com/
 * @since      1.0.0
 *
 * @package    Wooescrow
 * @subpackage Wooescrow/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wooescrow
 * @subpackage Wooescrow/admin
 * @author     Code Pixelz X Pwn Bot <dev@codepixelzmedia.com.np>
 */
class Wooescrow_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wooescrow_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wooescrow_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wooescrow-admin.css', array(), $this->version, 'all' );
		wp_enqueue_style(
			'wooescrow-admin-fontawesome-all',
			plugin_dir_url(__FILE__) . '../wooescrow-public/assets/fontawesome/css/all.css',
			array(),
			'1.0.0',
			'all'
		);
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wooescrow_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wooescrow_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wooescrow-admin.js', array( 'jquery' ), $this->version, false );
		wp_add_inline_script( $this->plugin_name, 'const adminScript = ' . json_encode( array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
		) ), 'before' );
		wp_localize_script( $this->plugin_name,'adminajax', array('ajaxUrl' => admin_url( 'admin-ajax.php' ),) );
		wp_localize_script($this->plugin_name, 'woooescrowAdmin', array('pluginUrl' => plugins_url('/img/', __FILE__)));
	}

}
