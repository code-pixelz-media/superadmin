<?php

if (!defined('ABSPATH')) exit;

/**
 * All plugin settings are managed from this class
 */
class WooEscrow_Settings
{

    public $settings_config = [];

    public $transaction_config  = [];


    public function __construct()
    {
        $this->init_config();

        add_action('admin_menu', [$this, 'add_settings_page']);

        add_action('admin_init', [$this, 'register_settings']);

        add_action('wp_ajax_wooescrow_fetch_users_with_pagination', [$this, 'wooescrow_ajax_list_users']);
        add_action('wp_ajax_wooescrow_wallet_lists', [$this, 'wooescrow_wallet_lists']);

        add_action('wp_ajax_wooescrow_fetch_withdrawal_requests_with_pagination', [$this, 'wooescrow_ajax_list_withdrawls']);

        add_action('wp_ajax_lisence_activation_call', [$this, 'lisence_activation_call']);
        add_action('wp_ajax_lisence_deactivation_call', [$this, 'lisence_deactivation_call']);

        do_action('wooescrow_after_constructor', $this);
    }



    /**
     * Configurations array of all settings fields 
     *
     * @return void
     */
    public function init_config()
    {
        $this->settings_config = apply_filters('wooescrow_settings_config', [
            'tabs' => [
                'wooescrow-integrations' => [
                    'title' => __('Integrations', 'wooescrow'),
                    'sections' => [
                        'wooescrow-lisence-key' => [
                            'title' => __('Licence Details', 'wooescrow'),
                            'fields' => [
                                'wooescrow-email-address' => [
                                    'type' => 'text',
                                    'label' => __('Email address', 'wooescrow'),
                                    'default' => '',
                                    'description' => __('Enter email address', 'wooescrow'),
                                    'id' => 'wooescrow-email-address', // Add ID here
                                ],
                                'wooescrow-lisence-key' => [
                                    'type' => 'text',
                                    'label' => __('Licence key', 'wooescrow'),
                                    'default' => '',
                                    'description' => __('Enter Licence Key', 'wooescrow'),
                                ],
                                'wooescrow-activate-lisence' => [
                                    'type' => 'link',
                                    'text' => __('Activate Licence', 'wooescrow'),
                                    'id' => 'wooescrow-activate-lisence-button', // Add ID here
                                ],
                                'wooescrow-deactivate-lisence' => [
                                    'type' => 'link',
                                    'text' => __('Deactivate Licence', 'wooescrow'),
                                    'id' => 'wooescrow-deactivate-lisence-button', // Add ID here
                                ],
                            ],
                        ],
                        'wooescrow-wallet-api-url' => [
                            'title' => __('Wallet API URL', 'wooescrow'),
                            'fields' => [
                                'wooescrow-wallet-api-url' => [
                                    'type' => 'text',
                                    'label' => __('Wallet Api', 'wooescrow'),
                                    'default' => '',
                                    'description' => __('Enter wallet API URL', 'wooescrow'),
                                ],
                            ],
                        ],
                        'wooescrow_integration_section' => [
                            'title' => 'Twilo Api Credentials',
                            'fields' => [
                                'wooescrow-twilo-sid' => [
                                    'type' => 'text',
                                    'label' => __('Account SID', 'wooescrow'),
                                    'default' => '',
                                    'description' => __('Enter Twilo Account SID ', 'wooescrow'),
                                ],
                                'wooescrow-twilo-auth-token' => [
                                    'type' => 'text',
                                    'label' => __('Authentication Token', 'wooescrow'),
                                    'default' => '',
                                    'description' => __('Enter Twilo Authentication ID', 'wooescrow'),
                                ],
                                'wooescrow-twilo-service-id' => [
                                    'type' => 'text',
                                    'label' => __('Twilo Service Id', 'wooescrow'),
                                    'default' => '',
                                    'description' => __('Enter Twilo Service ID', 'wooescrow'),
                                ],
                            ],
                        ],
                        'wooescrow-2fa-config' => [
                            'title' => __('2FA Configuration', 'wooescrow'),
                            'fields' => [
                                'wooescrow-2fa-config' => [
                                    'type' => 'checkbox',
                                    'label' => __('Enable 2FA', 'wooescrow'),
                                    'default' => '',
                                    'description' => __('Check to Enable 2FA', 'wooescrow'),
                                ],
                            ],
                        ],
                    ],
                ],
                'wooescrow-list-users' => [
                    'title' => __('List Users', 'wooescrow'),
                    'sections' => [
                        'wooescrow-list-users-section' => [
                            'title' => null,
                            'fields' => [
                                'custom_html' => [
                                    'type' => 'html',
                                    'callback' => [$this, 'wooescrow_list_user_custom_html_callback'],
                                ],
                            ],
                        ],
                    ],
                ],
                'wooescrow-withdrawl-request' => [
                    'title' => __('Withdrawal Request', 'wooescrow'),
                    'sections' => [
                        'wooescrow-withdrawl-request-section' => [
                            'title' => null,
                            'fields' => [
                                'custom_html' => [
                                    'type' => 'html',
                                    'callback' => [$this, 'wooescrow_withdrawal_request_custom_html_callback'],
                                ],
                            ],
                        ],
                    ],
                ],
                'wooescrow-wallet-list' => [
                    'title' => __('Wallets List', 'wooescrow'),
                    'sections' => [
                        'wooescrow-wallet-list-section' => [
                            'title' => null,
                            'fields' => [
                                'custom_html' => [
                                    'type' => 'html',
                                    'callback' => [$this, 'wooescrow_wallet_list_custom_html_callback'],
                                ],
                            ],
                        ],
                    ],
                ],
            ],
        ]);

        $this->transaction_config = apply_filters('wooescrow_transaction_config', [
            'tabs' => [
                'wooescrow-transaction-list' => [
                    'title' => __('Transaction List', 'wooescrow'),
                    'sections' => [
                        'wooescrow-transaction-list-section' => [
                            'title' => null,
                            'fields' => [
                                'custom_html' => [
                                    'type' => 'html',
                                    'callback' => [$this, 'wooescrow_transaction_list_custom_html_callback'],
                                ],
                            ],
                        ],
                    ],
                ],
                'wooescrow-request-list' => [
                    'title' => __('Request List', 'wooescrow'),
                    'sections' => [
                        'wooescrow-request-list-section' => [
                            'title' => null,
                            'fields' => [
                                'custom_html' => [
                                    'type' => 'html',
                                    'callback' => [$this, 'wooescrow_request_list_custom_html_callback'],
                                ],
                            ],
                        ],
                    ],
                ],
            ],
        ]);
    }
    /**
     * Adds Dashboard menu
     *
     * @return void
     */
    public function add_settings_page()
    {
        $menu_slug = apply_filters('wooescrow_settings_menu_slug', 'wooescrow_settings');

        do_action('wooescrow_before_add_menu');

        add_menu_page(
            'WooEscrow Settings',
            'WooEscrow',
            'manage_options',
            $menu_slug,
            [$this, 'render_settings_page'],
            '',
            99
        );
        add_submenu_page(
            $menu_slug,
            'Transaction',
            'Transaction',
            'manage_options',
            'wooescrow-payout',
            array($this, 'wooescrow_transaction_submenu_custom_html_callback')
        );

        do_action('wooescrow_after_add_menu');
    }
    /**
     * Register all fields required for admin settings fields and sections
     *
     * @return void
     */
    public function register_settings()
    {
        foreach ($this->settings_config['tabs'] as $tab_slug => $tab_data) {

            foreach ($tab_data['sections'] as $section_slug => $section_data) {

                $section_slug = apply_filters('wooescrow_section_slug', $section_slug, $tab_data);

                $section_data = apply_filters('wooescrow_section_data', $section_data, $section_slug);

                register_setting('wooescrow_settings_' . $tab_slug, $tab_slug, ['sanitize_callback' => [$this, 'sanitize_settings']]);

                add_settings_section(
                    $section_slug,
                    $section_data['title'],
                    null,
                    $tab_slug
                );

                foreach ($section_data['fields'] as $field_slug => $field_data) {

                    $field_slug = apply_filters('wooescrow_field_slug', $field_slug, $field_data);

                    $field_data = apply_filters('wooescrow_field_data', $field_data, $field_slug);

                    $label = isset($field_data['label']) ? $field_data['label'] : '';

                    add_settings_field(
                        $field_slug,
                        $label,
                        [$this, 'render_field'],
                        $tab_slug,
                        $section_slug,
                        ['field' => $field_data, 'name' => $field_slug, 'tab' => $tab_slug]
                    );
                }
            }
        }
    }
    /**
     * Renders tabs , settings fields required for wooescrow settings page
     *
     * @return void
     */
    public function render_settings_page()
    {


        $current_tab = isset($_GET['tab']) ? $_GET['tab'] : array_key_first($this->settings_config['tabs']);

        do_action('wooescrow_before_render_settings_page', $current_tab);
        $is_license_active = get_option('is_license_active');

?>
        <div class="wooescrow-settings-page-wrap <?php echo esc_attr($current_tab); ?>-container">
            <?php if (!$is_license_active) {
                echo '<span class="license_activation_notice notice is-dismissible error">License not activated.</span>';
            } ?>
            <h2><?php echo esc_html(get_admin_page_title()); ?></h2>
            <ul class="wooescrow-navigation-wrapper">
                <?php foreach ($this->settings_config['tabs'] as $tab_slug => $tab_data): ?>
                    <li class="wooescrow-nav-tab-item">
                        <a href="?page=wooescrow_settings&tab=<?php echo esc_attr($tab_slug); ?>" class="wooescrow-nav-tab <?php echo $current_tab === $tab_slug ? 'wooescrow-nav-tab-active' : ''; ?>">
                            <?php echo esc_html($tab_data['title']); ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
            <form method="post" action="options.php" class="wooescrow-admin-settings-page <?php echo esc_attr($current_tab); ?>-contents">
                <?php

                $has_custom_html = false;

                foreach ($this->settings_config['tabs'][$current_tab]['sections'] as $section_slug => $section_data) {

                    foreach ($section_data['fields'] as $field_data) {

                        if ($field_data['type'] === 'html') {

                            $has_custom_html = true;

                            if (isset($field_data['callback']) && is_callable($field_data['callback'])) {

                                call_user_func($field_data['callback'], $section_slug, '');
                            }
                        }
                    }
                }

                if (!$has_custom_html) {

                    settings_fields('wooescrow_settings_' . $current_tab);

                    do_settings_sections($current_tab);

                    submit_button();
                }
                ?>
            </form>
        </div>
    <?php

        do_action('wooescrow_after_render_settings_page', $current_tab);
    }

    /**
     * Creates All settings fields 
     *
     * @param array $args
     * @return void
     */
    public function render_field($args)
    {
        $field = apply_filters('wooescrow_render_field_data', $args['field'], $args['name']);

        $name = apply_filters('wooescrow_render_field_name', $args['name']);
        $label = $args['field']['text'] ?? '';
        $id = $args['field']['id'] ?? '';

        $tab_slug = $args['tab'];

        if ($field['type'] === 'html') {
            if (isset($field['callback']) && is_callable($field['callback'])) {
                call_user_func($field['callback'], $name, '');
            }
            return;
        }

        $options = get_option($tab_slug, []);

        $value = isset($options[$name]) ? $options[$name] : (isset($field['default']) ? $field['default'] : '');
        // $is_disabled = '';

        // if($name === 'wooescrow-email-address' || $name === 'wooescrow-lisence-key'){
        //     if(!empty($value)){
        //         $is_disabled = 'disabled';
        //     }
        // }

        switch ($field['type']) {

            case 'text':
                printf(
                    '<input class="regular-text wooescrow-text-field" type="text" name="%1$s[%2$s]" value="%3$s"/>',
                    esc_attr($tab_slug),
                    esc_attr($name),
                    esc_attr($value),
                    // esc_attr($is_disabled),
                );
                break;

            case 'checkbox':
                printf(
                    '<input type="checkbox" name="%1$s[%2$s]" value="1" %3$s />',
                    esc_attr($tab_slug),
                    esc_attr($name),
                    checked(1, $value, false)
                );
                break;
            case 'link':
                printf(
                    '<a href="#" id="%2$s">%1$s</a>',
                    esc_attr($label),
                    esc_attr($id),
                    esc_attr($value),
                );
                break;
        }

        if (isset($field['description'])) {

            printf('<p class="description">%s</p>', esc_html($field['description']));
        }

        do_action('wooescrow_after_render_field', $name, $field);
    }

    /**
     * Sanitization of data
     *
     * @param object $input
     * @return void
     */
    public function sanitize_settings($input)
    {
        $sanitized_input = [];

        foreach ($input as $key => $value) {

            $sanitized_input[$key] = sanitize_text_field($value);
        }
        return $sanitized_input;
    }

    /**
     * Callback function for listing all users 
     *
     * @param string $name
     * @param string $value
     * @return void
     */
    public function wooescrow_list_user_custom_html_callback($name, $value)
    {
    ?>
        <h3><?php esc_html_e('User List', 'wooescrow'); ?></h3>

        <div id="user-list-wrapper" style="position: relative;">
            <div id="user-list-spinner" class="wooescrow-spinner" style="display: none;">
                <img src="<?php echo esc_url(admin_url('images/spinner.gif')); ?>" alt="<?php esc_attr_e('Loading...', 'wooescrow'); ?>" />
            </div>

            <table id="user-list-table" class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('User ID', 'wooescrow'); ?></th>
                        <th><?php esc_html_e('Email', 'wooescrow'); ?></th>
                        <th><?php esc_html_e('Role', 'wooescrow'); ?></th>
                        <th><?php esc_html_e('Wallet Addresses', 'wooescrow'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Data injected via AJAX -->
                </tbody>
            </table>

            <div id="user-pagination" style="text-align: center;"></div>
        </div>
    <?php
    }


    public function wooescrow_withdrawal_request_custom_html_callback($name, $value)
    {
    ?>
        <h3><?php esc_html_e('Withdrawal Requests', 'wooescrow'); ?></h3>

        <div id="withdrawal-request-wrapper" style="position: relative;">
            <div id="withdrawal-request-spinner" class="wooescrow-spinner" style="display: none;">
                <img src="<?php echo esc_url(admin_url('images/spinner.gif')); ?>" alt="<?php esc_attr_e('Loading...', 'wooescrow'); ?>" />
            </div>

            <table id="withdrawal-request-table" class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('ID', 'wooescrow'); ?></th>
                        <th><?php esc_html_e('Amount', 'wooescrow'); ?></th>
                        <th><?php esc_html_e('Currency', 'wooescrow'); ?></th>
                        <th><?php esc_html_e('Date', 'wooescrow'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Data injected via AJAX -->
                </tbody>
            </table>

            <div id="withdrawal-pagination" style="text-align: center;"></div>
        </div>

    <?php
    }
    public function wooescrow_wallet_list_custom_html_callback($name, $value)
    {
    ?>
        <h3><?php esc_html_e('Wallet List', 'wooescrow'); ?></h3>
        <div id="wallet-list-wrapper" style="position: relative;">
            <div id="wallet-list-spinner" class="wooescrow-spinner" style="display: none;">
                <img src="<?php echo esc_url(admin_url('images/spinner.gif')); ?>" alt="<?php esc_attr_e('Loading...', 'wooescrow'); ?>" />
            </div>

            <table id="wallet-list-table" class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('ID', 'wooescrow'); ?></th>
                        <th><?php esc_html_e('User ID', 'wooescrow'); ?></th>
                        <th><?php esc_html_e('Address', 'wooescrow'); ?></th>
                        <th><?php esc_html_e('Network', 'wooescrow'); ?></th>
                        <th><?php esc_html_e('Created at', 'wooescrow'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Data injected via AJAX -->
                </tbody>
            </table>

            <div id="wallet-pagination" style="text-align: center;"></div>
        </div>

    <?php
    }

    /**
     * AJAX handler for fetching user's listing with pagination from api
     *
     * @return json|Array
     */
    public function wooescrow_ajax_list_users()
    {
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $limit = wp_is_mobile() ? 20 : 10;
        $base_url = get_option('wooescrow-integrations');
        $api_url = $base_url['wooescrow-wallet-api-url'] . "public/users?limit=$limit&offset=" . (($page - 1) * $limit);

        $response = wp_remote_get($api_url);

        if (is_wp_error($response)) {
            wp_send_json_error(['message' => __('Unable to fetch users.', 'wooescrow')]);
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if ($data['status'] != 200) {
            wp_send_json_error(['message' => __('Invalid response from API.', 'wooescrow')]);
        }

        $users = $data['data'];
        $total_pages = $data['pagination']['total_pages'];
        $pagination = $this->wooescrow_generate_pagination($total_pages, $page, 3);

        wp_send_json_success([
            'users' => $users,
            'pagination' => $pagination,
        ]);
    }


    public function wooescrow_wallet_lists()
    {
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $limit = wp_is_mobile() ? 20 : 10;

        $base_url = get_option('wooescrow-integrations');
        $api_url = $base_url['wooescrow-wallet-api-url'] . "public/users?limit=$limit&offset=" . (($page - 1) * $limit);

        $response = wp_remote_get($api_url);

        if (is_wp_error($response)) {
            wp_send_json_error(['message' => __('Unable to fetch users.', 'wooescrow')]);
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if ($data['status'] != 200) {
            wp_send_json_error(['message' => __('Invalid response from API.', 'wooescrow')]);
        }

        $wallets = $data['data'];
        $total_pages = $data['pagination']['total_pages'];
        $pagination = $this->wooescrow_generate_pagination($total_pages, $page, 3);
        wp_send_json_success([
            'wallets' => $wallets,
            'pagination' => $pagination,
        ]);
    }


    /**
     * AJAX handler for fetching withdrawal requests with pagination
     *
     * @return json|Array
     */
    public function wooescrow_ajax_list_withdrawls()
    {
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;

        $limit = wp_is_mobile() ? 20 : 10;

        $base_url = get_option('wooescrow-integrations');
        $api_url = $base_url['wooescrow-wallet-api-url'] . "withdrawal-requests-list/?limit=$limit&offset=" . (($page - 1) * $limit);

        //static token need to change 
        $auth_token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJlbWFpbCI6ImNoYWtyYUBnbWFpbC5jb20iLCJleHAiOjE3Mjk1OTE0NTEsImlhdCI6MTcyOTU4Nzg1MSwidG9rZW5fdHlwZSI6ImFjY2VzcyJ9.jlJMB8W3XRsKDapnwg_9Njukf3etck3vH5Q9fFbtdAk';

        // Setting the headers including the Authorization token
        $args = array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $auth_token,
            ),
        );
        $response = wp_remote_get($api_url, $args);

        if (is_wp_error($response)) {

            wp_send_json_error(['message' => __('Unable to fetch withdrawal requests.', 'wooescrow')]);
        }

        $body = wp_remote_retrieve_body($response);

        $data = json_decode($body, true);

        if (!isset($data['withdrawals'])) {
            wp_send_json_error(['message' => __('Invalid response from API.', 'wooescrow')]);
        }

        $withdrawals = $data['withdrawals'];

        $total_items = count($data['withdrawals']);

        $total_pages = ceil($total_items / $limit);

        $pagination = $this->wooescrow_generate_pagination($total_pages, $page, 3);

        wp_send_json_success([
            'withdrawals' => $withdrawals,
            'pagination' => $pagination,
        ]);
    }

    /**
     * Pagination for tables
     *
     * @param string|integer $total_pages
     * @param string|integer $current_page
     * @param integer $range
     * @return void
     */
    public function wooescrow_generate_pagination($total_pages, $current_page, $range = 3)
    {
        if ($total_pages <= 1) {
            return '';
        }

        $pagination_html = '<div class="wooescrow-pagination">';

        if ($current_page > 1) {
            $pagination_html .= '<a href="#" data-page="' . ($current_page - 1) . '"><span class="wooescrow-icon wooescrow-prev-icon"><i class="fa-solid fa-chevron-left"></i></span> ' . __('Previous', 'wooescrow') . '</a>';
        } else {
            $pagination_html .= '<span class="disabled"><span class="wooescrow-icon wooescrow-prev-icon"><i class="fa-solid fa-chevron-left"></i></span>' . __('Previous', 'wooescrow') . '</span>';
        }

        if ($total_pages > ($range * 2 + 4)) {

            if ($current_page > $range + 2) {
                $pagination_html .= '<a href="#" data-page="1">1</a>';
                if ($current_page > $range + 3) {
                    $pagination_html .= '<span class="dots">...</span>';
                }
            }

            for ($i = max(1, $current_page - $range); $i <= min($total_pages, $current_page + $range); $i++) {
                if ($i == $current_page) {
                    $pagination_html .= '<span class="current">' . $i . '</span>';
                } else {
                    $pagination_html .= '<a href="#" data-page="' . $i . '">' . $i . '</a>';
                }
            }


            if ($current_page < $total_pages - $range - 1) {
                if ($current_page < $total_pages - $range - 2) {
                    $pagination_html .= '<span class="dots">...</span>';
                }
                $pagination_html .= '<a href="#" data-page="' . $total_pages . '">' . $total_pages . '</a>';
            }
        } else {

            for ($i = 1; $i <= $total_pages; $i++) {
                if ($i == $current_page) {
                    $pagination_html .= '<span class="current">' . $i . '</span>';
                } else {
                    $pagination_html .= '<a href="#" data-page="' . $i . '">' . $i . '</a>';
                }
            }
        }


        if ($current_page < $total_pages) {
            $pagination_html .= '<a href="#" data-page="' . ($current_page + 1) . '">' . __('Next', 'wooescrow') . '<span class="wooescrow-icon wooescrow-next-icon"><i class="fa-solid fa-chevron-right"></i></span></a>';
        } else {
            $pagination_html .= '<span class="disabled">' . __('Next', 'wooescrow') . '<span class="wooescrow-icon wooescrow-next-icon"><i class="fa-solid fa-chevron-right"></i></span></span>';
        }

        $pagination_html .= '</div>';

        return $pagination_html;
    }
    public function wooescrow_transaction_submenu_custom_html_callback()
    {
        $current_tab = isset($_GET['tab']) ? $_GET['tab'] : array_key_first($this->transaction_config['tabs']);

        do_action('wooescrow_before_render_transaction_page', $current_tab);
    ?>
        <div class="wooescrow-settings-page-wrap">
            <h2><?php echo esc_html(get_admin_page_title()); ?></h2>
            <ul class="wooescrow-navigation-wrapper">
                <?php foreach ($this->transaction_config['tabs'] as $tab_slug => $tab_data): ?>
                    <li class="wooescrow-nav-tab-item">
                        <a href="?page=wooescrow-payout&tab=<?php echo esc_attr($tab_slug); ?>" class="wooescrow-nav-tab <?php echo $current_tab === $tab_slug ? 'wooescrow-nav-tab-active' : ''; ?>">
                            <?php echo esc_html($tab_data['title']); ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
            <form method="post" action="options.php" class="wooescrow-admin-settings-page <?php echo esc_attr($current_tab); ?>-contents">
                <?php

                $has_custom_html = false;

                foreach ($this->transaction_config['tabs'][$current_tab]['sections'] as $section_slug => $section_data) {

                    foreach ($section_data['fields'] as $field_data) {

                        if ($field_data['type'] === 'html') {

                            $has_custom_html = true;

                            if (isset($field_data['callback']) && is_callable($field_data['callback'])) {

                                call_user_func($field_data['callback'], $section_slug, '');
                            }
                        }
                    }
                }

                if (!$has_custom_html) {

                    settings_fields('wooescrow_settings_' . $current_tab);

                    do_settings_sections($current_tab);

                    submit_button();
                }
                ?>
            </form>
        </div>
    <?php
    }

    public function wooescrow_transaction_list_custom_html_callback()
    {
    ?>
        <h3><?php esc_html_e('Transaction List', 'wooescrow'); ?></h3>

        <div id="user-list-wrapper" style="position: relative;">
            <div id="user-list-spinner" class="wooescrow-spinner" style="display: none;">
                <img src="<?php echo esc_url(admin_url('images/spinner.gif')); ?>" alt="<?php esc_attr_e('Loading...', 'wooescrow'); ?>" />
            </div>

            <table id="user-list-table" class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Transaction ID', 'wooescrow'); ?></th>
                        <th><?php esc_html_e('User ID', 'wooescrow'); ?></th>
                        <th><?php esc_html_e('Wallet ID', 'wooescrow'); ?></th>
                        <th><?php esc_html_e('Created at', 'wooescrow'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Data injected via AJAX -->
                </tbody>
            </table>

            <div id="user-pagination" style="text-align: center;"></div>
        </div>
    <?php
    }

    public function wooescrow_request_list_custom_html_callback()
    {
    ?>
        <h3><?php esc_html_e('Request List', 'wooescrow'); ?></h3>

        <div id="user-list-wrapper" style="position: relative;">
            <div id="user-list-spinner" class="wooescrow-spinner" style="display: none;">
                <img src="<?php echo esc_url(admin_url('images/spinner.gif')); ?>" alt="<?php esc_attr_e('Loading...', 'wooescrow'); ?>" />
            </div>

            <table id="user-list-table" class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Request ID', 'wooescrow'); ?></th>
                        <th><?php esc_html_e('User ID', 'wooescrow'); ?></th>
                        <th><?php esc_html_e('Wallet ID', 'wooescrow'); ?></th>
                        <th><?php esc_html_e('Created at', 'wooescrow'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Data injected via AJAX -->
                </tbody>
            </table>

            <div id="user-pagination" style="text-align: center;"></div>
        </div>
<?php
    }



    public function lisence_activation_call()
    {
        $email = sanitize_email($_POST['lisence_email']);
        $license_key = sanitize_text_field($_POST['lisence_key']);


        $api_url = 'https://superadmin-wooescrow.codepixelz.tech/core/api/license/verify';


        $body = [
            'email' => $email,
            'license_key' => $license_key,
        ];


        $args = [
            'body'    => json_encode($body),
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'method'  => 'POST',
            'timeout' => 120,
        ];


        $response = wp_remote_post($api_url, $args);

        if (is_wp_error($response)) {
            return [
                'status' => 'error',
                'message' => 'Request failed: ' . $response->get_error_message(),
            ];
        }


        $response_body = json_decode(wp_remote_retrieve_body($response), true);

        // print_r($response_body['status']);

        if (isset($response_body['status']) && $response_body['status'] === 'success') {
            update_option('is_license_active', true);
            wp_send_json_success([
                'status' => 'success',
                'data'   => $response_body['data'],
            ]);
        } elseif (isset($response_body['status']) && $response_body['status'] === 'error') {
            update_option('is_license_active', false);
            wp_send_json_error([
                'status'  => 'error',
                'message' => $response_body['data']['message'],
            ]);
        } else {
            update_option('is_license_active', false);
            wp_send_json_error([
                'status'  => 'error',
                'message' => 'Unexpected response from the server.',
            ]);
        }

        // Ensure that the function stops execution after sending a response
        wp_die();
    }

    public function lisence_deactivation_call()
    {
        $email = sanitize_email($_POST['lisence_email']);
        $license_key = sanitize_text_field($_POST['lisence_key']);


        $api_url = 'https://superadmin-wooescrow.codepixelz.tech/core/api/license/delete/';


        $body = [
            'email' => $email,
            'key'  => $license_key
        ];


        $args = [
            'body'    => json_encode($body),
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'method'  => 'DELETE',
        ];


        $response = wp_remote_post($api_url, $args);

        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        if (isset($response_body['status']) && $response_body['status'] === 'success') {
            update_option('is_license_active', false);
            wp_send_json_success([
                'status' => 'success',
                'data'   => $response_body['data'],
            ]);
        }
        wp_die();
    }
}

new WooEscrow_Settings();
