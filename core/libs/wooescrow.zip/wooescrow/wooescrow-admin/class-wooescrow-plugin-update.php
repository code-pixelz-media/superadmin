<?php 

class Wooescrow_Plugin_Update {
    
    private $plugin_slug = 'wooescrow';
    private $plugin_file = 'wooescrow/wooescrow.php';
    private $info_url = 'https://superadmin-wooescrow.codepixelz.tech/core/plugin-info.json';

    public function __construct() {
        add_filter('site_transient_update_plugins', [$this, 'wooescrow_modify_update_plugins'], 9999);
    }

    /**
     * Modify plugin update information in the site_transient_update_plugins.
     *
     * @param object $transient The plugin update transient.
     * @return object The modified transient.
     */
    public function wooescrow_modify_update_plugins($transient) {
        if (empty($transient->response)) {
            $transient->response = [];
        }
    
        $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $this->plugin_file);
        $changelog = $this->wooescrow_fetch_plugin_info();
    
        if ($changelog && version_compare($plugin_data['Version'], $changelog->version, '<')) {
            // Fetch the package URL via POST request
            $license_key = get_option('your_license_key_option'); // Adjust this to your saved license key option name
            $email_address =  get_option('your_license_key_option');
            $package_url = $this->wooescrow_fetch_secure_package_url($license_key, $email_address);
            if ($package_url) {
                $transient->response[$this->plugin_file] = (object) [
                    'slug' => $this->plugin_slug,
                    'new_version' => $changelog->version,
                    'url' => $plugin_data['PluginURI'],
                    'package' => $package_url,
                ];
            }
        }
    
        return $transient;
    }

    /**
     * Fetch plugin version and download link information from the custom JSON endpoint.
     *
     * @return object|null The decoded JSON response or null if request fails.
     */
    private function wooescrow_fetch_plugin_info() {
        $response = wp_remote_get($this->info_url, [
            'timeout' => 10,
            'headers' => ['Accept' => 'application/json']
        ]);

        if (!is_wp_error($response) && 200 === wp_remote_retrieve_response_code($response)) {
            return json_decode(wp_remote_retrieve_body($response));
        }

        return null;
    }
    
    /**
     * Fetch plugin update files
     *
     */
    
    private function wooescrow_fetch_secure_package_url($license_key,$email_address) {
        $response = wp_remote_post('https://superadmin-wooescrow.codepixelz.tech/core/update.php', [
            'body' => [
                'license_key' => $license_key,
                'email_address' => $email_address,
            ],
            'timeout' => 20,
        ]);
    
        if (is_wp_error($response)) {
            return false;
        }
    
        // Check for a successful response
        if (wp_remote_retrieve_response_code($response) === 200) {
            return wp_remote_retrieve_body($response); 
        }
    
        return false;
    }
}


